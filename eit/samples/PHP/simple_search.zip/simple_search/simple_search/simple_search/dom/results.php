<?php
/**
* This file will display the results of a search.
*
* The DataService interface uses cURL to connect to the EIT and request
* the XML file.  See 'service.php'.
*
* PHP version 5
*
* LICENSE: This source file is subject to version 3.01 of the PHP license
* that is available through the world-wide-web at the following URI:
* http://www.php.net/license/3_01.txt.  If you did not receive a copy of
* the PHP License and are unable to obtain it through the web, please
* send a note to license@php.net so we can mail you a copy immediately.
*
* @category  Simple_Search
* @package   PackageName
* @author    EBSCO Publishing's <author@example.com>
* @author    Persistent System Limited <minal@persistent.co.in>
* @copyright 1997-2005 The PHP Group
* @license   http://www.php.net/license/3_01.txt  PHP License 3.01
* @link      http://pear.php.net/package/PackageName
*/	

// Error reporting to all
error_reporting(E_ALL);
require "../profile.php"; // Profile Information
require "../rest.php";    // DataService Class
require "functions.php";  // Misc. Functions


// Execute search query and return results.

// Search Terms
$s1 = $_GET["s1"];
$s2 = $_GET["s2"];
$s3 = $_GET["s3"];
$s4 = $_GET["s4"]; 

// Delimiters
$d1 = $_GET["d1"];
$d2 = $_GET["d2"];
$d3 = $_GET["d3"];
$d4='';
// Tags
$t1 = $_GET["t1"];
$t2 = $_GET["t2"];
$t3 = $_GET["t3"];
$t4 = $_GET["t4"];

// Other
//Selected DB
$db = $_GET["db"];
//Selected sort option
$sort = $_GET["sort"];
//Records start to be displayed
$start = (isset($_GET["start"]) ? $_GET["start"] : 1);
//whether to display full text
$ft = isset($_GET["ft"]) ? true : false;

// No search terms, go back to select DB
if (!$s1 && !$s2 && !$s3 && !$s4 || !$db) {
    die(header("Location: search.php?db=" . $db));
}
// The link for 'next' and 'previous' pages
$link = 'results.php?db=' . $db . '&sort=' . $sort . '&s1='
        . $s1 . '&s2' . $s2 . '&s3=' . $s3 . '&s4=' . $s4 . '&t1=' 
        . $t1 . '&t2=' . $t2 . '&t3=' . $t3 . '&t4=' . $t4 . '&d1=' 
        . $d1 . '&d2=' . $d2 . '&d3=' . $d3 . '&ft=' . $ft;
    
    
// Query Build Algorithm
//if the term to be searched is not null check for the Tag of the catergory else keep it null
$s1 = str_replace(" ", "+", $s1);
$s1 = ($s1 != null) ? ('(' . $t1 . ($t1 != '' ? '+(' : '') . $s1 . ')' . ($t1 != '' ? ')' : '')) : null;

$s2 = str_replace(" ", "+", $s2);
$s2 = ($s2 != null) ? ('(' . $t2 . ($t2 != '' ? '+(' : '') . $s2 . ')' . ($t2 != '' ? ')' : '')) : null;

$s3 = str_replace(" ", "+", $s3);
$s3 = ($s3 != null) ? ('(' . $t3 . ($t3 != '' ? '+(' : '') . $s3 . ')' . ($t3 != '' ? ')' : '')) : null;

$s4 = str_replace(" ", "+", $s4);
$s4 = ($s4 != null) ? ('(' . $t4 . ($t4 != '' ? '+(' : '') . $s4 . ')' . ($t4 != '' ? ')' : '')) : null;
        
//if trem to be searched is not null append database name and connecting term

     
     
$q='';     
//if not null append to query
if($s1!='') {
$q.=$s1;
}
//if second term not null append connector and term to query else just the term
if($s2!='' && $q!='') {
$q.='+'.$d1.'+'.$s2;
} else {
$q.=$s2;
}

if($s3!='' && $q!='') {
$q.='+'.$d2.'+'.$s3;
} else {
$q.=$s3;
}

if($s4!='' && $q!='') {
$q.='+'.$d3.'+'.$s4;
} else {
$q.=$s4;
}          
     
     
//format query with brackets and check for full text display     
$q = str_replace(")(", ")+AND+(", $q);
if (!preg_match('/\+AND\+FT\+Y/', $q) && $ft) {
    $q .= '+AND+FT+Y';
}
// The query to be sent to the EIT is formatted in $q

// Display HTML header
eit_header();
echo '
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=9" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="content-language" content="en-us" /></head>
<body>';	
//Create class object to request web service for the response
$xmlDoc = new DataService;
$xmlDoc->connect("http://eit.ebscohost.com/Services/SearchService.asmx/");

// Build Parameters
$params = array(
    "prof" 		=> $profile,
    "pwd"		=> $password,
    "query" 	=> $q,
    "startrec" 	=> $start,
    "db" 		=> $db,
    "sort" 		=> $sort
);

$xmlDoc->send("Search", $params);
$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML($xml);

// Get all of the XML elements by tag name "rec".  These are all of the
// result records.
$records = $xmlObj->getElementsByTagName("rec");

// Returns the number of search hits
   
$hits=$xmlObj->getElementsByTagName("Hits")->item(0)->nodeValue;

// Top result is the highest result on the current page.
$top_result = $start + 9;
if ($top_result > $hits) {
    $top_result = $hits;	
}    
                
// Building the next and previous page controls
$page_controls = '';
//Set the start record for Prev link
if ($start > 1) {
    $page_controls .= ' <a href="' . $link . '&start='
        . ($start - 10) . '">Prev</a> ';
} else {
    $page_controls .= ' Prev ';
}

$page_controls .= ' | ';
//Set the start record for Prev link
if ($start < ($hits - 9)) {
    $page_controls .= ' <a href="' . $link . '&start='
        . ($start + 10) . '">Next</a> ';
} else {
    $page_controls .= ' Next ';
}

// Output the page controls
echo '
<div class="search_area_right" style="background-color: #CCE0FF;">
<div id="box_search_right" style="background-color: #FFFFFF;">
<table>
    <tr>
        <td  style="vertical-align: top;">
            <img src="../images/logoEhost.gif" style="float:left" alt="" />
        </td>
        <td  style="vertical-align: top;">
            <p style="height: 17px;
                font-weight: bold;"><br/><br/>
            EBSCO Integration Toolkit (EIT) Web Services:  Simple Search Results
            </p>
        </td>
    </tr>
</table>
<p class="title"> </p>
<table width="700px">
<tr>
<td align="left">
<a href="search.php?db=' . $db . '">Refine Search</a>
</td>
<td align="right">


<form action="results.php" method="GET">
New Search :
        <input type="hidden" name="db" value="'.$db.'"/>
        <input name="s1" type="text"  value=""/>
        
        <input type="hidden" name="t1" value="'.$t1.'"/>
        <input type="hidden" name="d1" value="'.$d1.'"/>
        
        <input type="hidden" name="s2" value="'.$_GET["s2"].'"/>
        <input type="hidden" name="t2" value="'.$t2.'"/>
        <input type="hidden" name="d2" value="'.$d2.'"/>
        
        <input type="hidden" name="s3" value="'.$s3.'"/>
        <input type="hidden" name="t3" value="'.$t3.'"/>
        <input type="hidden" name="d3" value="'.$d3.'"/>
        
        <input type="hidden" name="s4" value="'.$s4.'"/>
        <input type="hidden" name="t4" value="'.$t4.'"/>
        <input type="hidden" name="d4" value="'.$d4.'"/>
        
        <input type="hidden" name="sort" value="'.$sort.'"/>
        <input type="hidden" name="ft" value="'.$ft.'"/>
        
            
           <input type="submit" value="Search" />
 
</form>
</td>
</tr>
</table>
<table border="0" width="700px">
<tr class="title" style="text-align: center;">
    <th class="search_result" colspan="2">
        Search Results for: ' . $q . '<br/><br/>
        Results ' . $start . ' - ' . $top_result . ' of '
         . $hits . ' Total Results<br/>' . $page_controls . '
    </th>
</tr>

';

// Display each record
foreach ($records as $record) {
    // info_str is the string of author/journal information.
    $info_str = '';
    
    // List each author, if there are any.
    $authors = $record->getElementsByTagName("au");
    if (isset($authors->item(0)->nodeValue)) {
        $info_str .= "By: ";
        foreach ($authors as $author) {
            $info_str .= $author->nodeValue . '; ';
        }
    }
    
    // Append Journal Title and Date
    $info_str .= $record->getElementsByTagName("jtl")->item(0)->nodeValue . ', ';
    $info_str .= $record->getElementsByTagName("dt")->item(0)->nodeValue . ', ';
    
    // Output all of this information into a row.
    echo '<tr>
    <td valign="top" style="padding-top: 5px;padding-bottom: 5px;">'.$record->getAttribute("recordID").'</td>
    <td class="search_result"><font style="font-weight: bold;"><a href="'
      . $record->getElementsByTagName("plink")->item(0)->nodeValue . '">'
      . $record->getElementsByTagName("atl")->item(0)->nodeValue
      . '</a></font><br/><i>' . $info_str . '</i>';
    
    // Retrieve the subjects
    $subjects = $record->getElementsByTagName("su");
    
    // Only display the subjects if there are any.
    if (isset($subjects->item(0)->nodeValue)) {
        echo '<br/><br/>Subjects: <br/>';
        
        foreach ($subjects as $subject) {
            echo $subject->nodeValue . ', ';
        }
    }
    echo '<br /><br />';
    echo "</td></tr>";
}	

    
    echo '<tr>
    <td class="search_result" colspan="2" style="text-align:center;">
    Results ' . $start . ' - ' . $top_result . ' of '
         . $hits . ' Total Results<br/>' . $page_controls . '
    </td>
    </tr>';
echo '</table>
</div>
<a href="http://support.ebscohost.com/eit/" style="text-align:center;text-decoration: underline;color:#104E8B;font-size: 10px;">Return to EBSCOhost Integration Toolkit Home</a>
</div>\n';
eit_footer();	  
?>