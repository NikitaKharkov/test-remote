<?php 
/**
* Define HTML header/footer
* 
* PHP version 5
*
* LICENSE: This source file is subject to version 3.01 of the PHP license
* that is available through the world-wide-web at the following URI:
* http://www.php.net/license/3_01.txt.  If you did not receive a copy of
* the PHP License and are unable to obtain it through the web, please
* send a note to license@php.net so we can mail you a copy immediately.
*
* @category  Simple_Search
* @package   PackageName
* @author    EBSCO Publishing's <author@example.com>
* @author    Persistent System Limited <minal@persistent.co.in>
* @copyright 1997-2005 The PHP Group
* @license   http://www.php.net/license/3_01.txt  PHP License 3.01
* @link      http://pear.php.net/package/PackageName
*/	

/**
* Output an HTML header
*
* @return Specify HTML header
*
*/ 
function eit_header()
{
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 1.0 Strict//EN"
"http://www.w3.org/TR/html1/DTD/html1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">';
    echo "<html>";
    echo "<head>";
    echo "<title>Search EBSCOhost</title>";
    echo "<link rel='stylesheet' href='../style.css' type='text/css' />";
    echo '<meta http-equiv="X-UA-Compatible" content="IE=9" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="en-us" />';
}

/**
* Output an HTML footer
*
* @return Specify HTML footer
*
*/ 

function eit_footer()
{
    echo "</body>\n";
    echo "</html>\n";
}

?>