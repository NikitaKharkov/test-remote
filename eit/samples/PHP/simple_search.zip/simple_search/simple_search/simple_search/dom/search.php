<?php
/**
* This file will display a search screen for a specific database.  Each database
* has different indexes and tags, which can be found by using the Info method of
* the SearchService.

* The DataService interface uses cURL to connect to the EIT and request
* the XML file.  See 'service.php'.
*
* PHP version 5
*
* LICENSE: This source file is subject to version 3.01 of the PHP license
* that is available through the world-wide-web at the following URI:
* http://www.php.net/license/3_01.txt.  If you did not receive a copy of
* the PHP License and are unable to obtain it through the web, please
* send a note to license@php.net so we can mail you a copy immediately.
*
* @category  Simple_Search
* @package   PackageName
* @author    EBSCO Publishing's <author@example.com>
* @author    Persistent System Limited <minal@persistent.co.in>
* @copyright 1997-2005 The PHP Group
* @license   http://www.php.net/license/3_01.txt  PHP License 3.01
* @link      http://pear.php.net/package/PackageName
*/	

// Error reporting to all
error_reporting(E_ALL);

require "../profile.php"; // Profile Information
require "../rest.php";    // DataService Class
require "functions.php";  // Misc. Functions

// Setup profile parameters
$params = array(
    "prof" => $profile,
    "pwd"  => $password 
); 
// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
$xmlDoc->send("Info", $params);

//XML response received from the web service call
$xml = $xmlDoc->recieve();
// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML($xml);

// Get all 'db' elements from the XML document.
$databases = $xmlObj->getElementsByTagName("db");

$db_found = false;
$db_short='';
$db_name='';
$index_options = '';
$tag_options = '';
$sort_options = '';
// Cycle through the databases available until
// we've found the one the user requested.
foreach ($databases as $database) {
if(isset($_GET["db"])) {		
    if ($database->getAttribute("shortName") == $_GET["db"]) {
        // Correct database.
        $db_found = true;
        $db_name = $database->getAttribute("longName");
        $db_short = $_GET["db"];
        
        // Here we are going to build the select boxes with the tag and
        // index options.  Note: the authorities (xsi:type="Authority") also
        // have tags and indices. In order to avoid listing those, we are only
        // going to list the first appearence of tags and indices.
        $index_options = '';
        $tag_options = '';
        $sort_options = '';
        
        // Get all of the indices
        $dbIndex = $database->getElementsByTagName("dbIndices");
        
        // Only use the first set of indices, as all others belong to authority databases.
        $dbIndex = $dbIndex->item(0);
        $dbIndex = $dbIndex->getElementsByTagName("dbIndex");
        foreach ($dbIndex as $index) {
            $index_options .= '<option value="' . $index->getAttribute("name")
                . '">' . $index->getAttribute("description") . '</option>';
        }
        
        // Tags
        $dbTag = $database->getElementsByTagName("dbTags");
        $dbTag = $dbTag->item(0);
        $dbTag = $dbTag->getElementsByTagName("dbTag");
        foreach ($dbTag as $tag) {
            $tag_options .= '<option value="' . $tag->getAttribute("name")
                . '">' . $tag->getAttribute("description") . '</option>';
        }
        
        // Sorting
        $sortOption = $database->getElementsByTagName("sortOptions");
        $sortOption = $sortOption->item(0);
        $sortOption = $sortOption->getElementsByTagName("sort");
        foreach ($sortOption as $sort) {
            $sort_options .= '<option value="' . $sort->getAttribute("id")
                . '">' . $sort->getAttribute("name") . '</option>';
        }
        // We have the all the database information necessary to render
        // the search interface.
    }
}
}

// If there was no DB found, go back to the index.
/*if (!$db_found) {
    die(header("Location: index.php"));
} */   

// Output HTML Headers
eit_header();

// Display the Database Select Page
echo '
</head>
<body>
<div class="search_area_right">
<table>
    <tr>
        <td  style="vertical-align: top;">
            <img src="../images/logoEhost.gif" style="float:left" alt="" />
        </td>
        <td  style="vertical-align: top;">
            <p style="height: 17px;
                font-weight: bold;"><br/>
            EBSCO Integration Toolkit (EIT) Web Services:<br/>  
            Simple Search Search and browse the EBSCOhost Databases using the EIT Web Service. <br/>
            </p>
        </td>
    </tr>
</table>
<div id="box_search_right">
Database: ' . $db_name . '
<div id="container">
<table class="main_table">

<tr class="content_holder">
<td>
<p class="title">
Select a Database:
</p>
<br/>
<table>
    <tr>
        <td width="200px" class="search_page">
        Please choose a Database:
        </td>
        <td class="search_page">        
        <select name="db" ONCHANGE="window.location.href=this.options[this.selectedIndex].value">';
        if(!isset($db_name)){
        echo '<option value="search.php?db=" selected="selected">';
        } else {
        echo '<option value="search.php?db=">';
        }
        echo 'Select Database</option>';
        
        foreach ($databases as $database) {
                    // Only display databases that aren't authority databases.  Authority
                    // databases have an 'xsi:type' attribute to identify them.
                    if ($database->getAttribute("xsi:type") != "DatabaseWithAuth") {
                        if (strcmp($database->getAttribute("longName"),$db_name))
                        {
                        echo '<option value="search.php?db='. $database->getAttribute("shortName").'">';
                        }
                        else {
                        echo '<option value="search.php?db='. $database->getAttribute("shortName").'"selected="selected">';
                        }
                        echo $database->getAttribute("longName").'</option>' ;
                    }           
                }
        
        
        echo '</select>
        
        
        </td>
        </tr>
        <tr><td></td>
        <td>
        *(Please select a database if not already selected)
        </td>
    </tr>
</table>
<br/>
</td>
</tr>




<tr class="content_holder">
<td>
<p class="title">
Standard Search:
</p>
<br />
<form action="results.php" method="GET" name="search">
<input type="hidden" name="db" value="' . $db_short . '"/>
<table>
    <tr>
        <td width="100px" class="search_page">
            Find:
        </td>
        <td class="search_page" colspan="2">
            <input type="text" name="s1" style="width:195px;"/>
        </td>
        <td class="search_page">
            in <select name="t1"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
        </td>
    </tr>
    <tr>
        <td></td>
        <td class="search_page">
            <select name="d1" style="width: 50px; margin: 5px 0pt;">
                <option value="AND">AND</option>
                <option value="OR">OR</option>
                <option value="NOT">NOT</option>
            </select>
        </td>
        <td class="search_page">
            <input type="text" name="s2">
        </td>
        <td class="search_page">
            in <select name="t2"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
        </td>
    </tr>
    <tr style="display:none;">
        <td class="search_page">
            <select name="d2">
                <option value="AND">AND</option>
                <option value="OR">OR</option>
                <option value="NOT">NOT</option>
            </select>
        </td>
        <td class="search_page">
            <input type="text" name="s3">
        </td>
        <td class="search_page">
            in  <select name="t3"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
        </td>
    </tr>
    <tr style="display:none;">
        <td class="search_page">
            <select name="d3">
                <option value="AND">AND</option>
                <option value="OR">OR</option>
                <option value="NOT">NOT</option>
            </select>
        </td>
        <td class="search_page">
            <input type="text" name="s4">
        </td>
        <td class="search_page">
            in  <select name="t4"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
        </td>
    </tr>
    </table>
    <table>
    <tr>
        <td class="search_page" width="100px">
            Sort By:
        </td>
        <td align="left" class="search_page">
             <select name="sort" style="width:100px;margin:5px 0 5px 0;">' . $sort_options . '</select>
        </td>
        <td class="search_page">
            Full Text <input type="checkbox" name="ft" value="1" checked="true" />
        </td>
    </tr>
    <tr><td></td>
        <td colspan="1" align="left">
            <input type="submit" value="Search"/>
        </td>
    </tr>
</table>
</form>
</td>
</tr>


<tr class="content_holder">
<td>
<p class="title">
Alternative Index Browse:
</p>
<form action="browse.php" method="get">
<input type="hidden" name="db" value="' . $_GET["db"] . '" />
<table>
<tr>
    <td width="100px" class="search_page">
        Index:
    </td>
    <td class="search_page">
        <select name="index" style="width:100px;margin:5px 0 5px 0;">
            ' . $index_options . '</select>
    </td>
</tr>
<tr>
    <td class="search_page">
        Browse for:
    </td>
    <td>
        <input type="text" name="browse"/><br/>
    </td>
</tr>
</tr>
    <tr><td></td>
        <td colspan="1" align="left">
<input type="submit" value="Browse"/>
 </td>
    </tr>
</table>
</form>
</td>
</tr>


</table>
</div>
</div>
<a href="http://support.ebscohost.com/eit/" style="text-align:center;text-decoration: underline;color:#104E8B;font-size: 10px;">Return to EBSCOhost Integration Toolkit Home</a>
</div>
';
//Display HTML Information
eit_footer();

?>