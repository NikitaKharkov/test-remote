<?php
/**
* Displays the browse functionality.
* 
* PHP version 5
*
* LICENSE: This source file is subject to version 3.01 of the PHP license
* that is available through the world-wide-web at the following URI:
* http://www.php.net/license/3_01.txt.  If you did not receive a copy of
* the PHP License and are unable to obtain it through the web, please
* send a note to license@php.net so we can mail you a copy immediately.
*
* @category  Simple_Search
* @package   PackageName
* @author    EBSCO Publishing's <author@example.com>
* @author    Persistent System Limited <minal@persistent.co.in>
* @copyright 1997-2005 The PHP Group
* @license   http://www.php.net/license/3_01.txt  PHP License 3.01
* @link      http://pear.php.net/package/PackageName
*/		   	 

require "../profile.php" ;  // Profile Information
require "../rest.php" ;     // DataService Class
require "functions.php" ;   // Misc. Functions

$db=(isset($_GET['db']))?$_GET['db']:null;
$index=(isset($_GET['index']))?$_GET['index']:null;
$browse=(isset($_GET['browse']))?$_GET['browse']:null;
if(!$index || !$browse || !$db) {
    die(header("Location: search.php?db=" . $db));
}
// Setup profile parameters
$params = array(
    "prof" => $profile,
    "pwd"  => $password,
    "index" => $_GET['index'],
    "term" => str_replace(" ", "+", $_GET['browse']),
    "db" => $_GET['db']
);

// Request Database Information through Browse Method
$xmlDoc = new DataService;
$xmlDoc->connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
$xmlDoc->send("Browse", $params);
//save the response obtained  XML form in $xml
$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML($xml);

// Get all 'rec' elements from the XML document.
$records = $xmlObj->getElementsByTagName("rec");

$table = "<table><tr class='title'><th>Name</th><th>Records Count</th></tr>\n";
foreach ( $records as $record ) {
    $table .= "<tr>\n";
    //Get all the Browse terms
    $browseTerm = $record->getElementsByTagName("browseTerms")->item(0);
    //Replace the search term to be searched with the new term to be searched.
    $table .= "<td width='500px'>\n<a href='browse.php?db=" . $_GET['db'] . "&index=" . $_GET['index']
           . "&browse=" . str_replace(" ", "+", $browseTerm->getAttribute("searchKey"))
           . "'>" . $browseTerm->getAttribute("searchKey") . "</a>\n</td>\n";
           
    $table .= "<td width='200px'>\n<a href='browse.php?db=" . $_GET['db'] . "&index=" . $_GET['index']
           . "&browse=" . str_replace(" ", "+", $browseTerm->getAttribute("searchKey"))
           . "'>" . $browseTerm->getAttribute("count") . "</a>\n</td>\n";
           
    $table .= "</tr>\n";
}
$table .= "</table>";
eit_header();
echo '
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="X-UA-Compatible" content="IE=9" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="content-language" content="en-us" />
</head>
<body>
<div class="search_area_right" style="background-color: #CCE0FF;">
<div id="box_search_right" style="background-color: #FFFFFF;">
<table>
    <tr>
        <td  style="vertical-align: top;">
            <img src="../images/logoEhost.gif" style="float:left" alt="" />
        </td>
        <td  style="vertical-align: top;">
            <p style="height: 17px;
                font-weight: bold;"><br/><br/>
            EBSCO Integration Toolkit (EIT) Web Services:  Simple Search Results
            </p>
        </td>
    </tr>
</table>
<p class="title"> </p>
<table width="700px">
<tr>
<td align="left">
<a href="search.php?db=' . $_GET['db'] . '">Refine Search</a>
</td>
<td align="right">

<form action="browse.php" method="GET">
<form action="browse.php" method="GET">
New Search :
        <input type="hidden" name="db" value="'.$db.'">
        </input>
        
        <input name="browse" type="text"  value=""/>
        
            <input name="index" type="text" value="'.$index.'"style="display:none;">
            
        </input>
        <input type="submit" value="Search" />
        </form>
</td>
</tr>
</table>

';
echo $table;
echo '</div>
<a href="http://support.ebscohost.com/eit/" style="text-align:center;text-decoration: underline;color:#104E8B;font-size: 10px;">Return to EBSCOhost Integration Toolkit Home</a>
</div>
</body>\n';
echo "</html>\n";

?>
