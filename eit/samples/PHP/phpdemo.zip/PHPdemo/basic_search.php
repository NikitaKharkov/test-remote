<?php
include('app/app.php');

render('basic_search.html', 'layout.html');
?>