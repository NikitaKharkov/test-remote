#!/bin/sh

# EBSCO module installer
#
# I. How to run this script
#
# 1. In console run
# chmod +x install.sh
# 2. In console run
# ./install.sh /path/to/vufind
# e.g. ./install.sh /usr/local/vufind
# Use a user that has write permission for the VuFind directory structure.
#
# II. What the script will do
#
# 1. It will create an [EBSCO] entry in VuFind config.ini file
# 2. It will copy all the module files into the VuFind directories


# Variables
VUFIND_HOME=$1
CURRENT_PATH=`pwd`


# Copy all module files to VuFind directories
copy_module () {
    source_dir="$CURRENT_PATH/web"
    if [ -d "$source_dir" ]; then
        destination_dir=$VUFIND_HOME
        cp -r $source_dir $destination_dir
        echo "Copied files from $source_dir to $destination_dir"
    fi
    source_dir="$CURRENT_PATH/tests"
    if [ -d "$source_dir" ]; then
        destination_dir=$VUFIND_HOME
        cp -r $source_dir $destination_dir
        echo "Copied $source_dir directory to $destination_dir"
    fi
}


# Update VuFind settings with the module settings
setup_module () {
    configuration_file="$VUFIND_HOME/web/conf/config.ini"
    backup_file="$VUFIND_HOME/web/conf/config.ini.ebsco"
    count=`grep -c "EBSCO = ebsco\.ini" $configuration_file`
    if [ $count -eq 0 ]; then
        sed -e "s!^theme[ ]*=\([^\n]*\)!theme = EBSCO,\1!" $configuration_file > $backup_file
        sed -i "s!\(\[Extra_Config\]\)!\1\nEBSCO = ebsco.ini!" $backup_file
        mv $backup_file $configuration_file
        echo "Updated $configuration_file"
    fi
}


# Main
if [ ${#1} -gt 0 ]; then
    echo ""
    copy_module
    setup_module
    echo "" ; echo "The EBSCO module was successfully installed." ; echo ""
else
    echo "" ; echo "You did not provide any parameter. Run the script like this : ./install.sh /path/to/vufind" ; echo ""
fi