<?php
/**
 * Initialize API action for EBSCO module
 */
require_once 'Base.php';



/**
 * Initialize API action for EBSCO module
 */
class InitApi extends Base
{
    /**
     * Initialize the API Authentication and Session tokens and 
     * store in $_SESSION the Info data retrieved from EBSCO server
     * This action is hidden and should not output something, even in case of errors
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        $this->searchObject->init();
        $this->searchObject->processInfo();
        return;
    }
}

?>