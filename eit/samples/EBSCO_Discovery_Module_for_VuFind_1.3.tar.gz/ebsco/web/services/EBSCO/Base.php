<?php
/**
 * Base class for EBSCO module actions.
 *
 * PHP version 5
 *
 */
require_once 'Action.php';
require_once 'sys/EBSCOAPI.php';

/**
 * Base class for EBSCO module actions.
 */
class Base extends Action
{
    protected $searchObject;

    /**
     * Constructor
     *
     * @access public
     */
    public function __construct()
    {
        global $interface;

        $this->searchObject = SearchObjectFactory::initSearchObject('EBSCO');

        // Assign some variables
        $interface->assign('currentTab', 'EBSCO');
        $interface->assign(
            'basicSearchTypes',
            is_object($this->searchObject) ? $this->searchObject->getBasicTypes() : array()
        );
    }
}

?>