<?php
/**
 * Record action for EBSCO module
 */
require_once 'Base.php';


/**
 * Record action for Record module
 */
class PDF extends Base
{
    private   $_ebsco;     // EBSCO API Interface
    protected $recordDriver;

    /**
     * Process incoming parameters and display the page.
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        global $interface;
        global $configArray;
        $is_xhr = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest';

        $errorMsg = null;
        $id = $_REQUEST['id'];
        list($an, $db) = explode('|', $id);

        $this->_ebsco = new EBSCOAPI();
        $record = $this->_ebsco->apiRetrieve($an, $db);
        if (PEAR::isError($record)) {
            $interface->setTemplate('view.tpl');
            $error = $record->getMessage();
            if ($error) {
                $error = "Unable to process query.<br />" . $error;
                $interface->assign('errorMsg', $error);
            }
            $interface->display('layout.tpl');
        } else if (isset($record['errors'])) {
            $interface->setTemplate('view.tpl');
            $error = "Unable to process the record.<br />" . $record['errors'];
            $interface->assign('errorMsg', $error);
            $interface->display('layout.tpl');
        } else {
            header("location: {$record['FullText']['Links']['pdflink']}");
        }
    }
}

?>