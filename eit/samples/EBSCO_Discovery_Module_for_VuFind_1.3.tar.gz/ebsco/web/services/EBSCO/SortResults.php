<?php
/**
 * SortResults action for EBSCO module
 */
require_once 'Action.php';

/**
 * This action only exists to allow sorting behavior to work when Javascript is
 * disabled.  Normally, Javascript reads the new sort URL and redirects accordingly.
 * If Javascript is unavailable, the user has to submit the sort URL to this page,
 * which will do a server-side redirect to achieve the same effect.
 */
class SortResults extends Action
{
    /**
     * Process incoming parameters and perform a redirect if appropriate.
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        if (isset($_REQUEST['sort'])) {
            header('Location: ' . $_REQUEST['sort']);
            die();
        } else if (isset($_REQUEST['amount'])) {
            header('Location: ' . $_REQUEST['amount']);
            die();
        } else if (isset($_REQUEST['mode'])) {
            header('Location: ' . $_REQUEST['mode']);
            die();
        }
    }
}

?>
