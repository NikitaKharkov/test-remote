<?php
/**
 * Search action for EBSCO module
 *
 * PHP version 5
 */
require_once 'Base.php';

require_once 'sys/Pager.php';


/**
 * Search action for EBSCO module
 */
class Search extends Base
{

    /**
     * Process incoming parameters and display the page.
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        global $interface;
        global $configArray;
        $is_xhr = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest');

        // Set Proxy URL
        // TODO: Needed ?
        if (isset($configArray['EZproxy']['host'])) {
            $interface->assign('proxy', $configArray['EZproxy']['host']);
        }

        // Initialise the Search object
        $this->searchObject->init();

        // Set Interface variables
        //   Those we can construct BEFORE the search is executed
        $displayQuery = $this->searchObject->displayQuery();
        $interface->setPageTitle(
            translate('Articles & More') .
            (empty($displayQuery) ? '' : ' - ' . htmlspecialchars($displayQuery))
        );
        $interface->assign('sortList', $this->searchObject->getSortList());
        $interface->assign('amountList', $this->searchObject->getAmountList(true));
        $interface->assign('modeList', $this->searchObject->getModeList(true));

        // Process Search
        $result = $this->searchObject->processSearch(true, false);
        if (PEAR::isError($result)) {
            PEAR::raiseError($result->getMessage());
        }

        // Process Info
        // Info data is always needed, and it's not related to search
        $info = $this->searchObject->processInfo();
        if (PEAR::isError($info)) {
            // TODO: Don't raise error ?
            PEAR::raiseError($info->getMessage());
        }

        // Some more variables
        //   Those we can construct AFTER the search is executed, but we need
        //   no matter whether there were any results
        $info = $this->searchObject->updateInfo($info);
        $limiterList = array_slice($info['limiters'], 0, 3);
        $interface->assign('limiterList', $limiterList);
        $interface->assign('expanderList', $info['expanders']);
        $interface->assign('paramList', $this->searchObject->getSearchUrlParams());

        //$interface->assign('qtime', round($this->searchObject->getQuerySpeed(), 2));
        if (isset($result['searchTime'])) {
            $interface->assign('qtime', round($result['searchTime'], 2));
        } else {
            $interface->assign('qtime', 0);
        }

        $interface->assign('searchType', $this->searchObject->getSearchType());
        $interface->assign('lookfor', $displayQuery);
        // Will assign null for an advanced search
        $interface->assign('searchIndex', $this->searchObject->getSearchIndex());

        // Current search filters
        $this->searchObject->setLimitersLabels($info['limiters']);
        $this->searchObject->setExpandersLabels($info['expanders']);

        $interface->assign('filterList', $this->searchObject->getFilterList(true));

        if ($this->searchObject->getResultTotal() < 1) {
            // No record found
            $interface->assign('recordCount', 0);

            // Was the empty result set due to an error?
            $error = $this->searchObject->getIndexError();
            if ($error !== false) {
                $error = "Unable to process query.<br />" . $error;
                $interface->assign('parseError', $error);
            }

        } else {

            // If the "jumpto" parameter is set, jump to the specified result index:
            $this->_processJumpto($result);

            // Assign interface variables
            $summary = $this->searchObject->getResultSummary();
            $interface->assign('recordCount', $summary['resultTotal']);
            $interface->assign('recordStart', $summary['startRecord']);
            $interface->assign('recordEnd',   $summary['endRecord']);

            // Big one - our results
            $interface->assign('recordSet', $result['response']['docs']);
            $facetList = $this->searchObject->updateFacetsList($result['response']['facets']);
            foreach($facetList as $key => $facet) {
                $facetList[$key]['Values'] = array_slice($facetList[$key]['Values'], 0, 20);
            }
            $interface->assign('facetList', $facetList);

            // Process Paging
            $link = $this->searchObject->renderLinkPageTemplate();
            $options = array('totalItems' => $summary['resultTotal'],
                             'fileName'   => $link,
                             'perPage'    => $summary['perPage']);
            $pager = new VuFindPager($options);
            $interface->assign('pageLinks', $pager->getLinks());
        }

        // 'Finish' the search... complete timers and log search history.
        $this->searchObject->close();

        $interface->assign('time', round($this->searchObject->getTotalSpeed(), 2));
         // Show the save/unsave code on screen
        // The ID won't exist until after the search has been put in the search
        //    history so this needs to occur after the close() on the searchObject
        $interface->assign('showSaved',   true);
        $interface->assign('savedSearch', $this->searchObject->isSavedSearch());
        $interface->assign('searchId',    $this->searchObject->getSearchId());

        // Save the URL of this search to the session so we can return to it easily:
        $_SESSION['lastSearchURL'] = $this->searchObject->renderSearchUrl();

        // Load the last limit from the request or session for initializing default
        // in search box:
        if (isset($_REQUEST['amount'])) {
            $interface->assign('lastAmount', $_REQUEST['amount']);
        } else if (isset($_SESSION['lastUserAmount'])) {
            $interface->assign('lastAmount', $_SESSION['lastUserAmount']);
        }

        // Load the last sort from the request or session for initializing default
        // in search box.  Note that this is not entirely ideal, since sort settings
        // will carry over from one module to another (i.e. WorldCat vs. Summon);
        // however, this is okay since the validation code will prevent errors and
        // simply revert to default sort when switching between modules.
        if (isset($_REQUEST['mode'])) {
            $interface->assign('lastMode', $_REQUEST['mode']);
        } else if (isset($_SESSION['lastUserMode'])) {
            $interface->assign('lastMode', $_SESSION['lastUserMode']);
        }
        $interface->assign('defaultMode', $this->searchObject->getDefaultMode());

        // initialize the search result scroller for this search
        $scroller = new ResultScroller();
        $scroller->init($this->searchObject, $result);

        // Done, display the page
        if($is_xhr) {
            $tpl = $this->searchObject->getResultTotal() < 1 ? 'list-combined-none' : 'list-combined';
            $interface->display("EBSCO/$tpl.tpl");
        } else {
            $tpl = 'list';
            $interface->setTemplate("$tpl.tpl");
            $interface->display('layout.tpl');
        }
    }


    /**
     * Process the "jumpto" parameter.
     *
     * @param array $result EBSCO result returned by this->searchObject
     *
     * @return void
     * @access private
     */
    private function _processJumpto($result)
    {
        if (isset($_REQUEST['jumpto']) && is_numeric($_REQUEST['jumpto'])) {
            $i = intval($_REQUEST['jumpto'] - 1);
            if (isset($result['response']['docs'][$i])) {
                $record = RecordDriverFactory::initRecordDriver(
                    $result['response']['docs'][$i]
                );
                $jumpUrl = '../Record?id=' . urlencode($record->getUniqueID());
                header('Location: ' . $jumpUrl);
                die();
            }
        }
    }
}

?>
