<?php
/**
 * Record action for EBSCO module
 */
require_once 'Base.php';
require_once 'Text/CAPTCHA.php';
require_once 'Cache/Lite.php';


/**
 * Captcha action for EBSCO module
 */
class Captcha extends Base
{
    /**
     * Process incoming parameters and display the page.
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        global $interface;

        if (isset($_POST['captcha_phrase'])) {
            if (isset($_POST['captcha_phrase']) && isset($_SESSION['EBSCO']['captcha_phrase']) &&
                strlen($_SESSION['EBSCO']['captcha_phrase']) > 0 &&
                $_POST['captcha_phrase'] === $_SESSION['EBSCO']['captcha_phrase']) {
                $url = isset($_POST['return']) && !empty($_POST['return']) ? $_POST['return'] : '/demo/EBSCO/Search';
                $identifier = $_SERVER['REMOTE_ADDR'];
                if ($identifier) {
                    $this->cache->save(time(), $identifier);
                }
                header('Location:' . $url);
                return;
            }
        }

        $interface->assign('return', $_REQUEST['return']);
        $interface->setTemplate('captcha.tpl');
        $interface->display('layout.tpl');
    }
}

?>