<?php
/**
 * Record action for EBSCO module
 */
require_once 'Base.php';
require_once 'Text/CAPTCHA.php';
require_once 'Cache/Lite.php';


/**
 * Captcha image / phrase action for EBSCO module
 */
class BuildCaptcha extends Base
{
    /**
     * Return a captcha image and setup the captcha phrase
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        global $interface;
        $theme_dir = $interface->template_dir[0];

        $captcha = Text_CAPTCHA::factory('Image');
        $options = array('font_size' => '24',
            'font_path' => "{$theme_dir}/css/",
            'font_file' => 'arial.ttf',
            'background_color' => '#666666');
        $captcha->init(150, 150, null, $options);

        $image = $captcha->getCAPTCHAAsPNG();
        $_SESSION['EBSCO']['captcha_phrase'] = $captcha->getPhrase();

        header("Content-type: image/png");
        echo $image;
    }
}

?>