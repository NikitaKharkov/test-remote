<?php
/**
 * Advanced search action for EBSCO module
 */
require_once 'Base.php';

/**
 * Advanced search action for EBSCO module
 */
class Advanced extends Base
{
    /**
     * Process incoming parameters and display the page.
     *
     * @return void
     * @access public
     */
    public function launch()
    {
        global $interface;

        // We don't want this search in the search history
        $this->searchObject->disableLogging();

        // Load a saved search, if any:
        $savedSearch = $this->_loadSavedSearch();

        if (!empty($savedSearch)) {
            $this->searchObject = $savedSearch;
        }

        // Process Info
        // Info data is always needed, and it's not related to search
        $info = $this->searchObject->processInfo();
        if (PEAR::isError($info)) {
            PEAR::raiseError($info->getMessage());
        }

        // Some more variables
        //   Those we can construct AFTER the search is executed, but we need
        //   no matter whether there were any results
        $this->searchObject->initFilters();
        $info = $this->searchObject->updateInfo($info);

        $interface->assign('limiterList', $info['limiters']);
        $interface->assign('expanderList', $info['expanders']);
        $interface->assign('modeList', $this->searchObject->getModeList(true));

        // Current search filters
        $this->searchObject->setLimitersLabels($info['limiters']);
        $this->searchObject->setExpandersLabels($info['expanders']);
        $interface->assign('filterList', $this->searchObject->getFilterList(true));

        // Send search type settings to the template
        $interface->assign('advSearchTypes', $this->searchObject->getAdvancedTypes());

        // If we found a saved search, let's assign some details to the interface:
        if ($savedSearch) {
            $interface->assign('searchDetails', $this->searchObject->getSearchTerms());
        }

        $interface->setPageTitle('Advanced Search');
        $interface->setTemplate('advanced.tpl');
        $interface->display('layout.tpl');
    }


    /**
     * Load a saved search, if appropriate and legal; assign an error to the
     * interface if necessary.
     *
     * @return mixed Search Object on successful load, false otherwise
     * @access private
     */
    private function _loadSavedSearch()
    {
        global $interface;

        // Are we editing an existing search?
        if (isset($_REQUEST['edit'])) {
            // Go find it
            $search = new SearchEntry();
            $search->id = $_REQUEST['edit'];

            if ($search->find(true)) {
                // Check permissions
                if ($search->session_id == session_id()
                    || $search->user_id == $user->id
                ) {
                    // Retrieve the search details
                    $minSO = unserialize($search->search_object);
                    $savedSearch = SearchObjectFactory::deminify($minSO);

                    // Make sure it's an advanced search
                    if ($savedSearch->getSearchType() == 'EBSCOAdvanced') {
                        // Activate facets so we get appropriate descriptions
                        // in the filter list:
                        // Handle standard filters:
                        return $savedSearch;
                    } else {
                        $interface->assign('editErr', 'notAdvanced');
                    }
                } else {
                    // No permissions
                    $interface->assign('editErr', 'noRights');
                }
            } else {
                // Not found
                $interface->assign('editErr', 'notFound');
            }
        }

        return false;
    }

}
?>