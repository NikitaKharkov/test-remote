<?php

/**
 * EBSCO API class
 *
 * PHP version 5
 *
 */

require_once 'sys/EBSCOConnector.php';
require_once 'sys/EBSCOResponse.php';


/**
 * EBSCO API class
 */
class EBSCOAPI
{
    /**
     * The authentication token used for API transactions
     * @global string
     */
    private $authenticationToken;


    /**
     * The session token for API transactions
     * @global string
     */
    private $sessionToken;


    /**
     * The EBSCOConnector object used for API transactions
     * @global object EBSCOConnector
     */
    private $connector;


    /**
     * VuFind search types mapped to EBSCO search types 
     * used for urls in search results / detailed result
     * @global array
     */
    private static $search_tags = array(
        ''          => 'TX',
        'AllFields' => 'TX',
        'Abstract'  => 'AB',
        'Author'    => 'AU',
        'Source'    => 'SO',
        'Subject'   => 'SU',
        'Title'     => 'TI'
    );


    /**
     * EBSCO sort options 
     * @global array
     */
    private static $sort_options = array(
        'relevance',
        'date',
        'date2',
        'source'
    );


    /**
     * VuFind sort types mapped to EBSCO sort types 
     * used for urls in Search results / Detailed view
     * @global array
     */
    private static $mapped_sort_options = array(
        'relevance'  => 'relevance',
        'subject'    => 'date',
        'year'       => 'date',
        'year asc'   => 'date2',
        'callnumber' => 'date',
        'author'     => 'author',
        'title'      => 'date'
    );


    /**
     * Setter / Getter for authentication token
     *
     * @param string     The authentication token
     *
     * @return string or none
     * @access public
     */
    public function authenticationToken($token = null)
    {
        if (empty($token)) {
            $token = $this->read_session('authenticationToken');
            return !empty($token) ? $token : $this->authenticationToken;
        } else {
            $this->authenticationToken = $token;
            $this->write_session('authenticationToken', $token);
        }
    }


    /**
     * Setter / Getter for session token
     *
     * @param string     The session token
     *
     * @return string or none
     * @access public
     */
    public function sessionToken($token = null)
    {
        if (empty($token)) {
            $token = $this->read_session('sessionToken');
            return !empty($token) ? $token : $this->sessionToken;
        } else {
            $this->sessionToken = $token;
            $this->write_session('sessionToken', $token);
        }
    }


    /**
     * Create a new EBSCOConnector object or reuse an existing one
     *
     * @param none
     *
     * @return EBSCOConnector object
     * @access public
     */
    public function connector()
    {
        if (empty($this->connector)) {
            $this->connector = new EBSCOConnector();
        }
        return $this->connector;
    }


    /**
     * Create a new EBSCOResponse object
     *
     * @param object $response
     *
     * @return EBSCOResponse object
     * @access public
     */
    public function response($response)
    {
        $responseObj = new EBSCOResponse($response);
        return $responseObj;
    }


    /**
     * Request authentication and session tokens, then send the API request.
     * Retry the request if authentication errors occur
     *
     * @param string  $action     The EBSCOConnector method name
     * @param array   $params     The parameters of the HTTP request
     * @param integer $attempts   The number of retries
     *
     * @return object             SimpleXml DOM or PEAR Error
     * @access protected
     */
    protected function request($action, $params = null, $attempts = 3)
    {
        $authenticationToken = $this->authenticationToken();
        $sessionToken = $this->sessionToken();

        // If authentication token is missing then the session token is missing too, so get both tokens
        // If session token is missing then the authentication token may be invalid, so get both tokens
        if (empty($authenticationToken) || empty($sessionToken)) {
            $result = $this->apiAuthenticationAndSessionToken();
            if (PEAR::isError($result)) {
                // Any error should terminate the request immediately
                // in order to prevent infinite recursion
                return $result;
            }
        }

        $headers = array(
            'x-authenticationToken' => $this->authenticationToken(),
            'x-sessionToken'        => $this->sessionToken()
        );

        $response = call_user_func_array(array($this->connector(), "request{$action}"), array($params, $headers));

        if (PEAR::isError($response)) {
            // Retry the request if there were authentication errors
            $code = $response->getCode();
            switch ($code) {
                // If authentication token is invalid then the session token is invalid too, so get both tokens
                // If session token is invalid then the authentication token may be invalid too, so get both tokens
                case EBSCOConnector::EDS_AUTH_TOKEN_INVALID:
                case EBSCOConnector::EDS_SESSION_TOKEN_INVALID:
                    $result = $this->apiAuthenticationAndSessionToken();
                    if (PEAR::isError($result)) {
                        // Any error should terminate the request immediately
                        // in order to prevent infinite recursion
                        return $result;
                    }
                    if ($attempts > 0) {
                        $result = $this->request($action, $params, $headers, --$attempts);
                    }
                    break;
                default:
                    $result = $this->handleError($response);
                    break;
            }
        } else {
            $result = $this->response($response)->result();
        }

        return $result;
    }


    /**
     * Wrapper for authentication API call
     *
     * @param none
     *
     * @access public
     */
    public function apiAuthenticationToken()
    {
        $response = $this->connector()->requestAuthenticationToken();

        // Raise the exception so that any code running this method should exit immediately
        if(PEAR::isError($response)) {
            return $response;
        } else {
            $result = $this->response($response)->result();
            return $result['authenticationToken'];
        }
    }


    /**
     * Wrapper for session API call
     *
     * @param none
     *
     * @access public
     */
    public function apiSessionToken()
    {
        // Add authentication tokens to headers
        $headers = array(
            'x-authenticationToken' => $this->authenticationToken()
        );

        $response = $this->connector()->requestSessionToken($headers);

        // Raise the exception so that any code running this method should exit immediately
        if(PEAR::isError($response)) {
            return $response;
        } else {
            $result = $this->response($response)->result();
            return $result;
        }
    }


    /**
     * Initialize the authentication and session tokens
     *
     * @param none
     *
     * @access public
     */
    public function apiAuthenticationAndSessionToken()
    {
        $authenticationToken = $this->apiAuthenticationToken();
        if (PEAR::isError($authenticationToken)) {
            // An authentication error should terminate the request immediately
            return $authenticationToken;
        }
        $this->authenticationToken($authenticationToken);

        $sessionToken = $this->apiSessionToken();
        if (PEAR::isError($sessionToken)) {
            // A session error should terminate the request immediately
            return $sessionToken;
        }
        $this->sessionToken($sessionToken);

        // We don't have to return anything, both tokens can be accessed using the getters
        return true;
    }


    /**
     * Wrapper for search API call
     *
     * @param array  $search      The search terms
     * @param array  $filters     The facet filters
     * @param string $start       The page to start with
     * @param string $limit       The number of records to return
     * @param string $sortBy      The value to be used by for sorting
     * @param string $amount      The amount of data to be returned
     * @param string $mode        The search mode
     *
     * @throws object             PEAR Error
     * @return array              An array of query results
     * @access public
     */
    public function apiSearch($search, $filters,
        $start = 1, $limit = 10, $sortBy = 'relevance', $amount = 'detailed', $mode = 'all'
    ) {
        $query = array();

        // Basic search
        if(!empty($search[0]['lookfor'])) {
            $lookfor = $search[0]['lookfor'];
            $type = isset($search[0]['index']) && !empty($search[0]['index']) ? $search[0]['index'] : 'AllFields';

            // strip all not allowed characters from lookfor term
            $term = str_replace(array(',', '-', '"', '.'), array('\,', '\-', '', '\.'), $lookfor);
            // replace multiple consecutive empty spaces with one empty space
            $term = preg_replace("/\s+/", ' ', $term);

            // search terms
            // Complex search term
            if (preg_match('/(.*) (AND|OR) (.*)/i', $term)) {
                $query['query'] = $term;
            } else {
                $tag = self::$search_tags[$type];
                $tag = empty($tag) ? 'TX' : $tag;
                $op = 'AND';
                $query_str = implode(',', array($op, $tag));
                $query_str = implode(':', array($query_str, $term));
                $query['query-1'] = $query_str;
            }

        // Advanced search
        } else if(!empty($search[0]['group'])) {

            $counter = 1;
            foreach ($search[0]['group'] as $group) {
                $type = $group['field'];
                $term = $group['lookfor'];
                $op = $group['bool'];
                $tag = $type && isset(self::$search_tags[$type]) ? self::$search_tags[$type] : '';

                // strip all not allowed characters from lookfor term
                $term = str_replace(array(',', '-', '"', '.'), array('\,', '\-', '', '\.'), $term);
                // replace multiple consecutive empty spaces with one empty space
                $term = preg_replace("/\s+/", ' ', $term);
                if (!empty($term)) {
                    $query_str = implode(',', array($op, $tag));
                    $query_str = implode(':', array($query_str, $term));
                    $query["query-$counter"] = $query_str;
                    $counter++;
                }
            }

        // No search term, return an empty array
        } else {
            $results = array(
                'recordCount' => 0,
                'response' => array(
                    'numFound' => 0,
                    'start'    => 0,
                    'docs'     => array(),
                    'facets'   => array()
                )
            );
            return $results;
        }

        // Add filters
        $limiters = array(); $expanders = array(); $facets = array();
        foreach ($filters as $filter) {
            if (preg_match('/addlimiter/', $filter)) {
                list($action, $str) = explode('(', $filter);
                $field_and_value = substr($str, 0, -1); // e.g. FT:y or GZ:Student Research, Projects and Publications
                list($field, $value) = explode(':', $field_and_value);
                $limiters[$field][] = str_replace(array(','), array('\,'), $value);
            } else if (preg_match('/addexpander/', $filter)) {
                list($action, $str) = explode('(', $filter);
                $field = substr($str, 0, -1); // expanders don't have value
                $expanders[] = $field;
            } else if (preg_match('/addfacetfilter/', $filter)) {
                list($action, $str) = explode('(', $filter);
                $field_and_value = substr($str, 0, -1); // e.g. ZG:FRANCE
                list($field, $value) = explode(':', $field_and_value);
                $facets[$field][] = str_replace(array(','), array('\,'), $field_and_value);
            }
        }
        if (!empty($limiters)) {
            foreach($limiters as $field => $limiter) {
                $query['limiter'][] = $field . ':' . implode(',', $limiter); // e.g. LA99:English,French,German
            }
        }
        if (!empty($expanders)) {
            $query['expander'] = implode(',', $expanders); // e.g. fulltext, thesaurus
        }
        if (!empty($facets)) {
            $groupId = 1;
            foreach($facets as $field => $facet) {
                $query['facetfilter'][] = $groupId . ',' . implode(',', $facet); // e.g. 1,DE:Math,DE:History
                $groupId += 1;
            }
        }

        // Add the sort option
        $sortBy = in_array($sortBy, self::$sort_options) ? $sortBy : self::$mapped_sort_options[$sortBy];

        // Add the HTTP query params
        $params = array(
            // Specifies the sort. Valid options are:
            // relevance, date, date2
            // date = Date descending
            // date2 = Date ascending
            'sort'           => $sortBy,
            // Specifies the search mode. Valid options are:
            // bool, any, all, smart
            'searchmode'     => $mode,
            // Specifies the amount of data to return with the response
            // Valid options are:
            // title: Title only
            // brief: Title + Source, Subjects
            // detailed: Brief + full abstract
            'view'           => $amount,
            /// Specifies whether or not to include facets
            'includefacets'  => 'y',
            'resultsperpage' => $limit,
            'pagenumber'     => $start,
            // Specifies whether or not to include highlighting in the search results
            'highlight'      => 'y'
        );

        $params = array_merge($params, $query);

        $result = $this->request('Search', $params);
        return $result;
    }


    /**
     * Wrapper for retrieve API call
     *
     * @param array  $an          The accession number
     * @param string $start       The short database name
     *
     * @throws object             PEAR Error
     * @return array              An associative array of data
     * @access public
     */
    public function apiRetrieve($an, $db)
    {
        // Add the HTTP query params
        $params = array(
            'an'        => $an,
            'dbid'      => $db,
            'highlight' => 'y'
        );

        $result = $this->request('Retrieve', $params);
        return $result;
    }


    /**
     * Wrapper for info API call
     *
     * @throws object             PEAR Error
     * @return array              An associative array of data
     * @access public
     */
    public function apiInfo()
    {
        if ($result = $this->read_session('info')) {
            return $result;
        }

        $result = $this->request('Info');
        if(!PEAR::isError($result)) {
            $this->write_session('info', $result);
        }
        return $result;
    }


    /**
     * Handle a PEAR_Error. Return : 
     * - if the error is critical : an associative array with the current error message
     * - if the error is not critical : the error message 
     *
     * @param Pear_Error $exception
     *
     * @return array or the Pear_Error exception
     * @access protected
     */
    private function handleError($error) {
        $errorCode = $error->getCode();
        switch($errorCode) {
            // This kind of error was generated by user , so display it to user
            case EBSCOConnector::EDS_INVALID_ARGUMENT_VALUE:
            case 126: // Temporary - limiter value error
                $errorMessage = $error->getMessage();
                break;
            // Any other errors are system errors, don't display them to user
            default:
                $errorMessage = 'An error occurred when getting the data.';
                break;
        }
        $result = array(
            'errors' => $errorMessage
        );
        return $result;
    }


    /**
     * Store the given object into session
     *
     * @param string $key    The key used for reading the value
     * @param object $value  The object stored in session
     *
     * @return none
     * @access protected
     */
    protected function write_session($key, $value)
    {
        if(!empty($key) && !empty($value)) {
            $_SESSION['EBSCO'][$key] = $value;
        }
    }


    /**
     * Read from session the object having the given key
     *
     * @param string $key    The key used for reading the object
     *
     * @return object
     * @access protected
     */
    protected function read_session($key)
    {
        $value = isset($_SESSION['EBSCO'][$key]) ? $_SESSION['EBSCO'][$key] : '';
        return $value;
    }

}


?>