<?php

require_once 'Log.php';
require_once 'HTTP/Request.php';
require_once 'sys/ConfigArray.php';

class EBSCOConnector
{
    const CRITICAL_ERROR = 1;

    /**
     * Error codes defined by EDS API
     *
     * @global integer EDS_UNKNOWN_PARAMETER  Unknown Parameter
     * @global integer EDS_INCORRECT_PARAMETER_FORMAT  Incorrect Parameter Format
     * @global integer EDS_INCORRECT_PARAMETER_FORMAT  Invalid Parameter Index
     * @global integer EDS_MISSING_PARAMETER  Missing Parameter
     * @global integer EDS_AUTH_TOKEN_INVALID  Auth Token Invalid
     */
    const EDS_UNKNOWN_PARAMETER          = 100;
    const EDS_INCORRECT_PARAMETER_FORMAT = 101;
    const EDS_INVALID_PARAMETER_INDEX    = 102;
    const EDS_MISSING_PARAMETER          = 103;
    const EDS_AUTH_TOKEN_INVALID         = 104;
    const EDS_INCORRECT_ARGUMENTS_NUMBER = 105;
    const EDS_UNKNOWN_ERROR              = 106;
    const EDS_AUTH_TOKEN_MISSING         = 107;
    const EDS_SESSION_TOKEN_MISSING      = 108;
    const EDS_SESSION_TOKEN_INVALID      = 109;
    const EDS_INVALID_RECORD_FORMAT      = 110;
    const EDS_UNKNOWN_ACTION             = 111;
    const EDS_INVALID_ARGUMENT_VALUE     = 112;
    const EDS_CREATE_SESSION_ERROR       = 113;
    const EDS_REQUIRED_DATA_MISSING      = 114;
    const EDS_TRANSACTION_LOGGING_ERROR  = 115;
    const EDS_DUPLICATE_PARAMETER        = 116;
    const EDS_UNABLE_TO_AUTHENTICATE     = 117;
    const EDS_SEARCH_ERROR               = 118;
    const EDS_INVALID_PAGE_SIZE          = 119;
    const EDS_SESSION_SAVE_ERROR         = 120;
    const EDS_SESSION_ENDING_ERROR       = 121;
    const EDS_CACHING_RESULTSET_ERROR    = 122;


    /**
     * HTTP status codes constants
     * http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html
     *
     * @global integer HTTP_OK        The request has succeeded
     * @global integer HTTP_NOT_FOUND The server has not found anything matching the Request-URI
     */
    const HTTP_OK                    = 200;
    const HTTP_BAD_REQUEST           = 400;
    const HTTP_NOT_FOUND             = 404;
    const HTTP_INTERNAL_SERVER_ERROR = 500;


    /**
     * The HTTP_Request object used for API transactions
     * @global object HTTP_Request
     */
    private $client;


    /**
     * The URL of the EBSCO API server
     * @global string
     */
    private static $end_point = 'http://eds-api.ebscohost.com/EDSAPI/rest';


    /**
     * The URL of the EBSCO API server
     * @global string
     */
    private static $authentication_end_point = 'https://eds-api.ebscohost.com/AuthService/rest';


    /**
     * The password used for API transactions
     * @global string
     */
    private $password;


    /**
     * The user id used for API transactions
     * @global string
     */
    private $userId;


    /**
     * The profile ID used for API transactions
     * @global string
     */
    private $profileId;


    /**
     * The interface ID used for API transactions
     * @global string
     */
    private $interfaceId;


    /**
     * The customer ID used for API transactions
     * @global string
     */
    private $orgId;


    /**
     * The isGuest used for API transactions
     * @global string 'y' or 'n'
     */
    private $isGuest;


    /*
     * You can log HTTP_Request requests using this option
     * @global bool logAPIRequests
     */
    private $logAPIRequests;


    /**
     * The logger object
     * @global object Logger
     */
    private $logger;


    /**
     * Constructor
     *
     * Sets up the EBSCO API settings
     *
     * @param none
     *
     * @access public
     */
    public function __construct()
    {
        $config = getExtraConfigArray('EBSCO'); // load conf/ebsco.ini
        $this->password = $config['Catalog']['Password'];
        $this->userId = $config['Catalog']['UserId'];
        $this->interfaceId = $config['Catalog']['InterfaceId'];
        $this->profileId = $config['Catalog']['ProfileId'];
        $this->orgId = $config['Catalog']['OrgId'];
        $this->isGuest = $config['Catalog']['IsGuest'];
        $this->logAPIRequests = ($config['Logging']['logAPIRequests'] == 1);
        if ($this->logAPIRequests) {
            $this->logger = new Logger();
        }
    }


    /**
     * Create an HTTP client
     *
     * @param none
     *
     * @return HTTP_Request object
     * @access public
     */
    public function client()
    {
        $this->client = new HTTP_Request(null, array('useBrackets' => false, 'timeout' => 30));
        return $this->client;
    }


    /**
     * Request the authentication token
     *
     * @param none
     *
     * @return object SimpleXml or PEAR_Error
     * @access public
     */
    public function requestAuthenticationToken()
    {
        $url = self::$authentication_end_point . '/UIDAuth';

        // Add the body of the request
        $params =<<<BODY
<UIDAuthRequestMessage xmlns="http://www.ebscohost.com/services/public/AuthService/Response/2012/06/01">
    <UserId>{$this->userId}</UserId>
    <Password>{$this->password}</Password>
    <InterfaceId>{$this->interfaceId}</InterfaceId>
</UIDAuthRequestMessage>
BODY;

        $response = $this->request($url, $params, null, HTTP_REQUEST_METHOD_POST);
        return $response;
    }


    /**
     * Request the session token
     *
     * @param array $headers  Authentication token
     *
     * @return object SimpleXml or PEAR_Error
     * @access public
     */
    public function requestSessionToken($headers)
    {
        $url = self::$end_point . '/CreateSession';

        // Add the HTTP query params
        $params = array(
            'profile' => $this->profileId,
            'org'     => $this->orgId,
            'guest'   => $this->isGuest
        );

        $response = $this->request($url, $params, $headers);
        return $response;
    }


    /**
     * Request the search records
     *
     * @param array $params Search specific parameters
     * @param array $headers Authentication and session tokens
     *
     * @return object SimpleXml or PEAR_Error
     * @access public
     */
    public function requestSearch($params, $headers)
    {
        $url = self::$end_point . '/Search';

        $response = $this->request($url, $params, $headers);
        return $response;
    }


    /**
     * Request a specific record
     *
     * @param array $params Retrieve specific parameters
     * @param array $headers Authentication and session tokens
     *
     * @return object SimpleXml or PEAR_Error
     * @access public
     */
    public function requestRetrieve($params, $headers)
    {
        $url = self::$end_point . '/Retrieve';

        $response = $this->request($url, $params, $headers);
        return $response;
    }


    /**
     * Request the info data
     *
     * @param null $params Not used
     * @param array $headers Authentication and session tokens
     *
     * @return object SimpleXml or PEAR_Error
     * @access public
     */
    public function requestInfo($params, $headers)
    {
        $url = self::$end_point . '/Info';

        $response = $this->request($url, $params, $headers);
        return $response;
    }


    /**
     * Send an HTTP request and inspect the response
     *
     * @param string $url         The url of the HTTP request
     * @param array  $params      The parameters of the HTTP request
     * @param array  $headers     The headers of the HTTP request
     * @param array  $body        The body of the HTTP request
     * @param string $method      The HTTP method, default is 'GET'
     *
     * @return object             SimpleXml or PEAR_Error
     * @access protected
     */
    protected function request($url, $params, $headers = null, $method = HTTP_REQUEST_METHOD_GET) 
    {
        $xml = false;
        $return = false;

        // Initialize the client
        $client = $this->client();
        $client->setURL($url);
        $client->setMethod($method);

        if (!empty($params)) {
            if (is_array($params)) {
                foreach ($params as $key => $value) {
                    $client->addQueryString($key, $value);
                }
                
            } else {
                $client->setBody($params);
                // Set the content type to 'application/xml'
                $headers = $headers === null ? array() : $headers;
                $headers = array_merge($headers, array(
                    'content-type'   => 'application/xml',
                    'content-length' => strlen($params)
                ));
            }
        }

        if (!empty($headers)) {
            foreach ($headers as $key => $value) {
                $client->addHeader($key, $value);
            }
        }

        // Send the request
        // Timeouts and Malformed responses are raised as exceptions by HTTP_Request
        $response = $client->sendRequest();
        if (PEAR::isError($response)) {
             $code = 0;
             $return = PEAR::raiseError($response, self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
        } else {
            $code = $client->getResponseCode();
            switch ($code) {
                case self::HTTP_OK:
                    $xml_str = $client->getResponseBody();
                    $xml = simplexml_load_string($xml_str);
                    if (PEAR::isError($xml)) {
                        $return = PEAR::raiseError($xml, self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                    } else {
                        $return = $xml;
                    }
                    break;
                case self::HTTP_BAD_REQUEST:
                    $xml_str = $client->getResponseBody();
                    $xml = simplexml_load_string($xml_str);
                    if (PEAR::isError($xml)) {
                        $return = PEAR::raiseError($xml, self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                    } else {
                        // If the response is an API error
                        $isError = isset($xml->ErrorNumber) || isset($xml->ErrorCode);
                        if ($isError) {
                            $error = ''; $code = 0;
                            if (isset($xml->DetailedErrorDescription) && !empty($xml->DetailedErrorDescription)) {
                                $error = (string) $xml->DetailedErrorDescription;
                            } else if (isset($xml->ErrorDescription)) {
                                $error = (string) $xml->ErrorDescription;
                            } else if (isset($xml->Reason)) {
                                $error = (string) $xml->Reason;
                            }
                            if (isset($xml->ErrorNumber)) {
                                $code = (integer) $xml->ErrorNumber;
                            } else if (isset($xml->ErrorCode)) {
                                $code = (integer) $xml->ErrorCode;
                            }
                            $return = PEAR::raiseError($error, $code, PEAR_ERROR_RETURN);
                        } else {
                            $return = PEAR::raiseError("HTTP {$code} : The request could not be understood by the server due to malformed syntax. Modify your search before retrying.", 
                                self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                        }
                    }
                    break;
                case self::HTTP_NOT_FOUND:
                    $return = PEAR::raiseError("HTTP {$code} : The resource you are looking for might have been removed, had its name changed, or is temporarily unavailable.", 
                        self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                    break;
                case self::HTTP_INTERNAL_SERVER_ERROR:
                    $return = PEAR::raiseError("HTTP {$code} : The server encountered an unexpected condition which prevented it from fulfilling the request.", 
                        self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                    break;
                // Other HTTP status codes
                default:
                    $return = PEAR::raiseError("HTTP {$code} : Unexpected HTTP error.", self::CRITICAL_ERROR, PEAR_ERROR_RETURN);
                    break;
            }
        }

        // Log any error
        if ($this->logAPIRequests) {
            // $client = both the HTTP request and response
            // $response = only the HTTP response
            $message = $this->toString($client); // or $this->toString($response)
            $code = defined('PEAR_LOG_ERR') ? PEAR_LOG_ERR : PEAR_LOG_ERROR;
            $this->logger->log($message, $code);
        }

        return $return;
    }


    /*
     * Capture the output of print_r into a string
     *
     * @param object Any object
     * @access private
     */
    private function toString($object)
    {
        ob_start();
        print_r($object);
        return ob_get_clean();
    }


}


?>