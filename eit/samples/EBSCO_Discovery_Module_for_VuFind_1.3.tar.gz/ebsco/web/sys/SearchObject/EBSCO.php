<?php
/**
 * A derivative of the Search Object for use with EBSCO.
 *
 * PHP version 5
 */
require_once 'sys/EBSCOAPI.php';
require_once 'sys/SearchObject/Base.php';

/**
 * A derivative of the Search Object for use with EBSCO.
 */
class SearchObject_EBSCO extends SearchObject_Base
{
    // OTHER VARIABLES
    private $_ebsco;        // API object
    private $_indexResult;  // API Search response
    private $_infoResult;   // API Info response

    // Limiters
    protected $limiterList = array();
    protected $limitersLabels = array();

    // Expanders
    protected $expanderList = array();
    protected $expandersLabels = array();

    // Amount of data
    protected $amount = 'detailed';
    protected $defaultAmount = 'detailed';
    protected $amountOptions;

    // Search modes
    protected $mode = 'all';
    protected $defaultMode = 'all';
    protected $modeOptions;

    // Sort options
    protected $_sortOptions;

    // Limit, set it to same number as default limit in config.ini
    protected $limit = 10;


    /**
     * Constructor
     *
     * @access public
     */
    public function __construct()
    {
        // Standard logic from parent class:
        parent::__construct();

        // Connect to EBSCO
        $this->_ebsco = new EBSCOAPI();

        // Load search preferences:
        $searchSettings = getExtraConfigArray('EBSCO');
        if (isset($searchSettings['General']['default_sort'])) {
            $this->defaultSort = $searchSettings['General']['default_sort'];
        } else {
            $this->defaultSort = 'relevance';
        }
        if (isset($searchSettings['General']['default_limit'])) {
            $this->defaultLimit = $searchSettings['General']['default_limit'];
        } else {
            $this->limit = $this->defaultLimit = 10;
        }
        if (isset($searchSettings['General']['default_mode'])) {
            $this->defaultMode = $searchSettings['General']['default_mode'];
        } else {
            $this->defaultMode = 'all';
        }

        // Load sort preferences (or defaults if none in .ini file):
        if (isset($searchSettings['Sorting'])) {
            $this->sortOptions = $searchSettings['Sorting'];
        } else {
            $this->sortOptions = array('relevance' => 'sort_relevance', 
                'year' => 'sort_year', 'year asc' => 'sort_year asc', 
                'author' => 'sort_author');
        }

        // Load limit preferences (or defaults if none in .ini file):
        if (isset($searchSettings['General']['limit_options'])) {
            $this->limitOptions
                = explode(",", $searchSettings['General']['limit_options']);
        } elseif (isset($searchSettings['General']['default_limit'])) {
            $this->limitOptions = array($this->defaultLimit);
        } else {
            $this->limitOptions = array(10);
        }

        // Load amount preferences (or defaults if none in .ini file):
        if (isset($searchSettings['Amount'])) {
            $this->amountOptions = $searchSettings['Amount'];
        } else {
            $this->amountOptions = array('detailed' => 'Detailed',
                'brief' => 'Brief', 'title' => 'Title');
        }

        // Load amount preferences (or defaults if none in .ini file):
        if (isset($searchSettings['Search_Modes'])) {
            $this->modeOptions = $searchSettings['Search_Modes'];
        } else {
            $this->modeOptions = array('bool' => 'Bool', 'any' => 'Any',
                'all' => 'All', 'smart' => 'Smart');
        }

        // Set up search options
        $this->basicTypes = $searchSettings['Basic_Searches'];
        if (isset($searchSettings['Advanced_Searches'])) {
            $this->advancedTypes = $searchSettings['Advanced_Searches'];
        }

        $this->searchType = $this->basicSearchType = 'EBSCO';
        $this->advancedSearchType = 'EBSCOAdvanced';
    }


    /**
     * Initialise the object from the global
     *  search parameters in $_REQUEST.
     *
     * @return boolean
     * @access public
     */
    public function init()
    {
        // Call the standard initialization routine in the parent:
        parent::init();

        //********************
        // Check if we have a saved search to restore -- if restored successfully,
        // our work here is done; if there is an error, we should report failure;
        // if restoreSavedSearch returns false, we should proceed as normal.
        $restored = $this->restoreSavedSearch();
        if ($restored === true) {
            return true;
        } else if (PEAR::isError($restored)) {
            return false;
        }

        $this->initView();
        $this->initPage();
        $this->initSort();
        $this->initFilters();
        $this->initLimit();
        $this->initAmount();
        $this->initMode();


        // Try to find a basic search first; check for advanced if no basic found.
        if (!$this->initBasicSearch()) {
            $this->initAdvancedSearch();
        }
        return true;
    }


    /**
     * Initialize the object's search settings for an advanced search found in the
     * $_REQUEST superglobal.  Advanced searches have numeric subscripts on the
     * lookfor and type parameters -- this is how they are distinguished from basic
     * searches.
     *
     * @return void
     * @access protected
     */
    protected function initAdvancedSearch()
    {
        //********************
        // Advanced Search logic
        //  'lookfor0[]' 'type0[]'
        //  'lookfor1[]' 'type1[]' ...
        $this->searchType = $this->advancedSearchType;

        $group = array();
        // Loop through each term inside the group
        for ($i = 0; $i < count($_REQUEST['lookfor0']); $i++) {
            // Ignore advanced search fields with no lookup
            if ($_REQUEST['lookfor0'][$i] != '') {
                // Use default fields if not set
                if (isset($_REQUEST['type0'][$i]) && $_REQUEST['type0'][$i] != '') {
                    $type = $_REQUEST['type0'][$i];
                } else {
                    $type = $this->defaultIndex;
                }

                // Add term to this group
                $group[] = array(
                    'field'   => $type,
                    'lookfor' => $_REQUEST['lookfor0'][$i],
                    'bool'    => $_REQUEST['bool0'][$i]
                );
            }
        }

        // Make sure we aren't adding groups that had no terms
        if (count($group) > 0) {
            // Add the completed group to the list
            $this->searchTerms[] = array(
                'group' => $group,
                'join'  => ''
            );
        }

        // Finally, if every advanced row was empty
        if (count($this->searchTerms) == 0) {
            // Treat it as an empty basic search
            $this->searchType = $this->basicSearchType;
            $this->searchTerms[] = array(
                'index'   => $this->defaultIndex,
                'lookfor' => ''
            );
        }
    }


    /**
     * Get a human-readable presentation version of the advanced search query
     * stored in the object.  This will not work if $this->searchType is not
     * 'advanced.'
     *
     * @return string
     * @access protected
     */
    protected function buildAdvancedDisplayQuery()
    {
        $output = '';
        foreach ($this->searchTerms as $search) {
            $thisGroup = array();
            // Process each search group
            foreach ($search['group'] as $key => $group) {
                $field = $this->getHumanReadableFieldName($group['field']);
                $lookfor = $group['lookfor'];
                $bool = $key == 0 ? '' : " {$group['bool']} ";
                $output .= "{$bool}{$field}:{$lookfor}";
            }
        }

        return $output;
    }


    /**
     * Process and submit the apiSearch
     *
     * @param bool $returnIndexErrors Should we die inside the index code if we
     * encounter an error (false) or return it for access via the getIndexError()
     * method (true)?
     * @param bool $recommendations   Should we process recommendations along with
     * the search itself?
     *
     * @return object 
     * @access public
     */
    public function processSearch($returnIndexErrors = false,
        $recommendations = false) 
    {
        $this->_indexResult = array(
            'responseHeader' => array(
                'start' => 0
            ),
            'recordCount' => 0,
            'response' => array(
                'numFound' => 0,
                'start'    => 0,
                'maxScore' => 1,
                'docs'     => array(),
                'facets'   => array()
            )
        );

        // Get time before the query
        $this->startQueryTimer();

        $this->_indexResult = $this->_ebsco->apiSearch($this->searchTerms, $this->filterList,
            $this->page, $this->limit, $this->sort, $this->amount, $this->mode);
        if (PEAR::isError($this->_indexResult)) {
            PEAR::raiseError($this->_indexResult);
        }

        // Get time after the query
        $this->stopQueryTimer();

        // Store relevant details from the search results:
        $this->resultsTotal = isset($this->_indexResult['recordCount']) ? 
            $this->_indexResult['recordCount'] : 0;

        // Return the associative array with results
        return $this->_indexResult;
    }


    /**
     * Process and submit the apiInfo
     *
     * @return object 
     * @access public
     */
    public function processInfo()
    {
        $this->_infoResult = array(
            'sort'      => array(),
            'tags'      => array(),
            'expanders' => array(),
            'limiters'  => array()
        );

        $this->_infoResult = $this->_ebsco->apiInfo();
        if (PEAR::isError($this->_infoResult)) {
            PEAR::raiseError($this->_infoResult);
        }

        // Return the associate array of data
        return $this->_infoResult;
    }


    /**
     * Get error message from index response, if any.  This will only work if
     * processSearch was called with $returnIndexErrors set to true!
     *
     * @return mixed false if no error, error string otherwise.
     * @access public
     */
    public function getIndexError()
    {
        return isset($this->_indexResult['errors']) ?
            $this->_indexResult['errors'] : false;
    }


    /**
     * Turn the list of spelling suggestions into an array of urls
     *   for on-screen use to implement the suggestions.
     *
     * @return array Spelling suggestion data arrays
     * @access public
     */
    public function getSpellingSuggestions()
    {
        // Not currently supported.
        return array();
    }


    /**
     * Take a filter string and add it into the protected
     *   array checking for duplicates.
     *
     * @param string $newFilter A filter string from url : "addfacetfilter(field:value)"
     * or "addlimiter(FT:y) or addexpander(thesaurus)"
     *
     * @return void
     * @access public
     */
    public function addFilter($newFilter = null)
    {
        // Check for duplicates -- if it's not in the array, we can add it
        if (empty($this->filterList[$newFilter])) {
            $this->filterList[] = $newFilter;
        }
    }


    /**
     * Add filters to the object based on values found in the $_REQUEST superglobal.
     *
     * @return void
     * @access protected
     */
    public function initFilters()
    {
        // $_REQUEST['filter'] : Search page
        // $this->filterList : Advanced search page
        $filters = isset($_REQUEST['filter']) ? $_REQUEST['filter'] : $this->filterList;
        // Handle standard filters:
        if (!empty($filters)) {
            $filters = is_array($filters) ? $filters : array($filters);
            foreach ($filters as $filter) {
                if (preg_match('/^addfacetfilter/', $filter)) {
                    $this->addFilter($filter);
                } else if (preg_match('/^addlimiter/', $filter)) {
                    $this->addLimiter($filter);
                    $this->addFilter($filter);
                } else if (preg_match('/^addexpander/', $filter)) {
                    $this->addExpander($filter);
                    $this->addFilter($filter);
                }
            }
        }
    }


    /**
     * Add limiters labels to the object
     *
     * @return void
     * @access public
     */
    public function setLimitersLabels($limiters) {
        foreach($limiters as $limiter) {
            $this->limitersLabels[$limiter['Id']] = $limiter['Label'];
        }
    }


    /**
     * Add expanders labels to the object
     *
     * @return void
     * @access public
     */
    public function setExpandersLabels($expanders) {
        foreach($expanders as $expander) {
            $this->expandersLabels[$expander['Id']] = $expander['Label'];
        }
    }


    /**
     * Return an array structure containing all current filters
     *    and urls to remove them.
     *
     * @param bool $excludeCheckboxFilters Should we exclude checkbox filters from
     * the list (to be used as a complement to getCheckboxFacets()).
     *
     * @return array                       Field, values, actions and removal urls
     * @access public
     */
    public function getFilterList($excludeCheckboxFilters = false)
    {
        $list = array();
        if (!empty($this->filterList)) {
            foreach($this->filterList as $filter) {
                // prevent PHP warning in Search History
                if (empty($filter) || strpos($filter, '(') === false) {
                    continue;
                }
                // The filter string can have multiple forms like
                // example1: "addfacetfilter(Subject:value)"
                // example2: "addlimiter(FT:y)" (Full Text)
                // example3: addexpander(thesaurus)"

                // First get the action part from the filter string
                // action => "addfacetfilter" or "addlimiter" or "addexpander"
                list($action, $str) = explode('(', $filter);

                // Then get the field, value parts from the filter string
                // example1: field => "Subject", value => "value"
                // example2: field => "FT", value => "y"
                // example3: field => "thesaurus", value => null
                // But first remove the last ")" character
                $field_value = substr($str, 0, -1);
                if (strpos($field_value, ':') === false) {
                    $field_value .= ':'; // prevent PHP warning
                }
                list($field, $value) = explode(':', $field_value);
                $display = $value;

                // Limiters and expanders are using keywords for fields
                // Make them human-readable using the limitersLabels and expandersLabels
                switch($action) {
                    case 'addlimiter':
                        $label = $this->toHumanReadableLabel($field, 'limiter');
                        if (preg_match('/\d+\-\d+\/\d+\-\d+/', $value)) {
                            list($display, $str) = explode('-', $value); // explode by first '-'
                        }
                        break;
                    case 'addexpander':
                        $label = $this->toHumanReadableLabel($field, 'expander');
                        break;
                    default:
                        $label = $field;
                        break;
                }

                $list[$label][] = array(
                    'value'      => $value,   // raw value for use
                    'display'    => $display, // value to be displayed to user
                    'field'      => $field,
                    'action'     => $action,
                    'removalUrl' => $this->renderLinkWithoutFilter($filter)
                );
            }
        }

        return $list;
    }


    /**
     * Remove from facets any applied facet filter
     *
     * @param array $facets  The original array of facets
     *
     * @return array $facets The array of facets without applied facets
     * @access public
     */
    public function updateFacetsList($facets) {
        foreach($facets as $key => $facet) {
            foreach($facet['Values'] as $k => $v) {
                if (in_array($v['Action'], $this->filterList)) {
                    unset($facets[$key]['Values'][$k]);
                }
            }
        }

        return $facets;
    }


    /**
     * Return a human readable string
     *
     * @param string $label  The raw string
     * @param string $action Identifies the type of label : limiter or expander
     *
     * @return string
     * @access public
     */
    public function toHumanReadableLabel($label, $type) {
        if ($type == 'limiter') {
            if(isset($this->limitersLabels[$label])) {
                $label = 'Limiter: ' . $this->limitersLabels[$label];
            }
        } else if ($type == 'expander') {
            if (isset($this->expandersLabels[$label])) {
                $label = 'Expander: ' . $this->expandersLabels[$label];
            }
        }

        return $label;
    }


    /**
     * Return a url for the current search without several of the current filters
     * It overrides the parent class method
     *
     * @param array $filters The filters to remove from the search url
     *
     * @return string        URL of a new search
     * @access public
     */
    public function renderLinkWithoutFilters($filters)
    {
        // Stash our old data for a minute
        $oldFilterList = $this->filterList;
        $oldPage       = $this->page;

        // Remove the old filter
        foreach ($filters as $oldFilter) {
            $this->removeFilter($oldFilter);
        }
        // Remove page number
        $this->page = 1;
        // Get the new url
        $url = $this->renderSearchUrl();
        // Restore the old data
        $this->filterList = $oldFilterList;
        $this->page       = $oldPage;
        // Return the URL
        return $url;
    }


    /**
     * Get a user-friendly string to describe the provided facet field.
     * It overrides the parent class method
     *
     * @param string $field Facet field name.
     *
     * @return string       Human-readable description of field.
     * @access public
     */
    public function getFacetLabel($tag)
    {
        return $tag;
    }


    /**
     * Remove a filter from the list.
     * It overrides the parent class method
     *
     * @param string $oldFilter A filter string from url : "field:value"
     *
     * @return void
     * @access public
     */
    public function removeFilter($oldFilter)
    {
        for ($i = 0; $i < count($this->filterList); $i++) {
            // Does it contain the value we don't want?
            if ($this->filterList[$i] == $oldFilter) {
                // If so remove it.
                unset($this->filterList[$i]);
            }
        }
    }


    /**
     * Update the info data structure with a 'selected' entry,
     * based on currently applied limiters and expanders, 
     * because we use checkboxes to display them
     *
     * @return array The info array updated with 'selected' info
     * @access public
     */
    public function updateInfo($info)
    {
        // Update limiters
        $limiters = $info['limiters'];
        foreach($limiters as $key_limiter => $limiter) {
            // select limiters
            if (empty($limiter['Values'])) {
                $action = str_replace('value', 'y', $limiter['Action']);
                // Limiters of type ymrange have to be checked separately
                if ($limiter['Type'] == 'ymrange') {
                    foreach($this->limiterList as $appliedLimiter) {
                        list($limiter_and_field, $value) = explode(':', $appliedLimiter);
                        if ($limiter_and_field == "addlimiter({$limiter['Id']}") {
                            $value = str_replace(')', '', $value);
                            $info['limiters'][$key_limiter]['selected'] = $value;
                        }
                    }
                } else if (in_array($action, $this->limiterList)) {
                    $info['limiters'][$key_limiter]['selected'] = true;
                }
            // multi select limiters
            } else {
                foreach($limiter['Values'] as $key_option => $option) {
                    $action = $option['Action'];
                    if (in_array($action, $this->limiterList)) {
                        $info['limiters'][$key_limiter]['Values'][$key_option]['selected'] = true;
                    }
                }
            }
        }

        // Update expanders
        $expanders = $info['expanders'];
        foreach($expanders as $key => $expander) {
            $action = $expander['Action'];
            if (in_array($action, $this->expanderList)) {
                $info['expanders'][$key]['selected'] = true;
            }
        }

        return $info;
    }


    /**
     * Get an array of params to be used for submitting the "Update" action
     *
     * @return array Array of URL parameters (key=url_encoded_value format)
     * @access public
     */
    public function getSearchUrlParams()
    {
        list($base, $query) = explode('?', $this->renderSearchUrl());
        parse_str($query, $params);

        foreach($params as $name => $param) {
            if (is_array($param)) {
                foreach($param as $key => $value) {
                    if (in_array($value, $this->limiterList) || in_array($value, $this->expanderList)) {
                        unset($params[$name][$key]);
                    }
                }
            } else if (in_array($param, $this->limiterList) || in_array($param, $this->expanderList)) {
                unset($params[$name]);
            } else if ($name == 'mode') {
                unset($params[$name]);
            }
        }

        return $params;
    }


    /**
     * Take a limiter string and add it into the protected
     *   array checking for duplicates.
     *
     * @param string $newFilter A filter string from url : "field:value"
     *
     * @return void
     * @access public
     */
    public function addLimiter($newLimiter)
    {
        if (empty($this->limiterList[$newLimiter])) {
            $this->limiterList[] = $newLimiter;
        }
    }


    /**
     * Take an expander string and add it into the protected
     *   array checking for duplicates.
     *
     * @param string $newFilter A filter string from url : "field:value"
     *
     * @return void
     * @access public
     */
    public function addExpander($newExpander)
    {
        if (empty($this->expanderList[$newExpander])) {
            $this->expanderList[] = $newExpander;
        }
    }


    /**
     * Get an array of strings to attach to a base URL in order to reproduce the
     * current search.
     *
     * @return array Array of URL parameters (key=url_encoded_value format)
     * @access protected
     */
    protected function getSearchParams()
    {
        $params = array();
        switch ($this->searchType) {
        // Advanced search
        case $this->advancedSearchType:
            for ($i = 0; $i < count($this->searchTerms); $i++) {
                for ($j = 0; $j < count($this->searchTerms[$i]['group']); $j++) {
                    $params[] = urlencode("bool{$i}[]") . "=" .
                        urlencode($this->searchTerms[$i]['group'][$j]['bool']);
                    $params[] = urlencode("lookfor{$i}[]") . "=" .
                        urlencode($this->searchTerms[$i]['group'][$j]['lookfor']);
                    $params[] = urlencode("type{$i}[]") . "=" .
                        urlencode($this->searchTerms[$i]['group'][$j]['field']);
                }
            }
            break;
        // Basic search
        default:
            if (isset($this->searchTerms[0]['lookfor'])) {
                $params[] = "lookfor=" . urlencode($this->searchTerms[0]['lookfor']);
            }
            if (isset($this->searchTerms[0]['index'])) {
                $params[] = "type="    . urlencode($this->searchTerms[0]['index']);
            }
            break;
        }
        return $params;
    }



    /**
     * Build a url for the current search
     * It overrides the parent class method
     *
     * @access  public
     * @return  string   URL of a search
     */
    public function renderSearchUrl()
    {
        // Get the base URL and initialize the parameters attached to it:
        $url = $this->getBaseUrl();
        $params = $this->getSearchParams();

        // Add any filters
        if (count($this->filterList) > 0) {
            foreach ($this->filterList as $field => $filter) {
                $filter = is_array($filter) ? $filter : array($filter);
                foreach ($filter as $value) {
                    $params[] = 'filter[]=' . urlencode($value);
                }
            }
        }

        // Sorting
        if ($this->sort != null && $this->sort != $this->defaultSort) {
            $params[] = 'sort=' . urlencode($this->sort);
        }

        // Amount
        if ($this->amount != null && $this->amount != $this->defaultAmount) {
            $params[] = 'amount=' . urlencode($this->amount);
        }

        // Mode
        if ($this->mode != null && $this->mode != $this->defaultMode) {
            $params[] = 'mode=' . urlencode($this->mode);
        }

        // Page number
        if ($this->page != 1) {
            // Don't url encode if it's the paging template
            if ($this->page == '%d') {
                $params[] = 'page=' . $this->page;
            // Otherwise... encode to prevent XSS.
            } else {
                $params[] = 'page=' . urlencode($this->page);
            }
        }

        // View
        if ($this->view != null) {
            $params[] = 'view=' . urlencode($this->view);
        }

        // Join all parameters with an escaped ampersand,
        //   add to the base url and return
        return $url . join("&", $params);
    }


    /**
     * Get the base URL for search results (including ? parameter prefix).
     * It overrides the parent class method
     *
     * @return string Base URL
     * @access protected
     */
    protected function getBaseUrl()
    {
        return $this->serverUrl."/EBSCO/Search?";
    }


    /**
     * Getter for the array of amount search options
     *
     * @access public
     * @return array
     */
    public function getAmountOptions()
    {
        return $this->amountOptions;
    }


    /**
     * Getter for the array of search mode options
     *
     * @access public
     * @return array
     */
    public function getModeOptions()
    {
        return $this->modeOptions;
    }


    /**
     * Add search amount to the object based on the $_REQUEST superglobal.
     *
     * @return void
     * @access protected
     */
    protected function initAmount()
    {
        // Validate and assign the amount value:
        $valid = array_keys($this->getAmountOptions());
        if (isset($_REQUEST['amount']) && in_array($_REQUEST['amount'], $valid)) {
            $this->amount = $_REQUEST['amount'];
            $_SESSION['lastUserAmount'] = $this->amount;
        } else {
            $this->amount = $this->defaultAmount;
            $_SESSION['lastUserAmount'] = null;
        }
    }


    /**
     * Add search mode to the object based on the $_REQUEST superglobal.
     *
     * @return void
     * @access protected
     */
    protected function initMode()
    {
        // Validate and assign the amount value:
        $valid = array_keys($this->getModeOptions());
        if (isset($_REQUEST['mode']) && in_array($_REQUEST['mode'], $valid)) {
            $this->mode = $_REQUEST['mode'];
            $_SESSION['lastUserMode'] = $this->mode;
        } else {
            $this->mode = $this->defaultMode;
            $_SESSION['lastUserMode'] = null;
        }
    }


    /**
     * Return a list of urls for sorting, along with which option
     *    should be currently selected.
     *
     * @return array Amount search urls, descriptions and selected flags
     * @access public
     */
    public function getAmountList()
    {
        $valid = $this->getAmountOptions();
        $list = array();
        foreach ($valid as $amount => $desc) {
            $list[$amount] = array(
                'amountUrl' => $this->renderLinkWithAmount($amount),
                'desc'      => $desc,
                'selected'  => ($amount == $this->amount)
            );
        }
        return $list;
    }


    /**
     * Getter for the default search mode
     *
     * @return string
     * @access public
     */
    public function getDefaultMode()
    {
        return $this->defaultMode;
    }


    /**
     * Return a list of urls for sorting, along with which option
     *    should be currently selected.
     *
     * @return array Search mode urls, descriptions and selected flags
     * @access public
     */
    public function getModeList()
    {
        // Loop through all the current filter fields
        $valid = $this->getModeOptions();
        $list = array();
        foreach ($valid as $mode => $desc) {
            $list[$mode] = array(
                'modeUrl'  => $mode,
                'desc'     => $desc,
                'selected' => ($mode == $this->mode)
            );
        }
        return $list;
    }



    /**
     * Return a url for the current search with a new amount search
     *
     * @param string $newSort A field to specify the amount of search
     *
     * @return string         URL of a new search
     * @access public
     */
    public function renderLinkWithAmount($newAmount)
    {
        // Stash our old data for a minute
        $oldAmount = $this->amount;
        // Add the new amount
        $this->amount = $newAmount;
        // Get the new url
        $url = $this->renderSearchUrl();
        // Restore the old data
        $this->amount = $oldAmount;
        // Return the URL
        return $url;
    }


    /**
     * Return a url for the current search with a new search mode
     *
     * @param string $newSort A field to specify the search mode
     *
     * @return string         URL of a new search
     * @access public
     */
    public function renderLinkWithMode($newMode)
    {
        // Stash our old data for a minute
        $oldMode = $this->mode;
        // Add the new mode
        $this->mode = $newMode;
        // Get the new url
        $url = $this->renderSearchUrl();
        // Restore the old data
        $this->mode = $oldMode;
        // Return the URL
        return $url;
    }

}
?>