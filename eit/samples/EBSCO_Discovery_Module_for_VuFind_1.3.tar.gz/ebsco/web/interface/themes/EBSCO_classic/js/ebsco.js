/*
 * The EBSCO module javascript
 **/
var EBSCO = function() {

    var Y = YAHOO.util,
        slider = null;


    // the returned object members will be publicly available
    return {

        /*
         * Initialize all event handlers
         **/
        initEventHandlers: function () {
            // EBSCO/Search : "jump menu" select boxes
            Y.Event.on(Y.Selector.query('select.jumpMenu'), 'change', function (event) { 
                Y.Dom.getAncestorByTagName(event.currentTarget, 'form').submit();
            });

            // EBSCO/Search : Less facets
            Y.Event.on(Y.Selector.query('._less_facets'), 'click', function (event) {
                var element = new Y.Element(event.currentTarget),
                    id = element.get('id').replace('less-facets-',''),
                    dl = Y.Dom.get('facet-' + id),
                    span = Y.Dom.getLastChild(Y.Dom.getLastChild(dl)),
                    group = new Y.Element(document.getElementById("narrowGroupHidden_" + id));
                if (span) {
                    span = new Y.Element(span);
                    if (span.hasClass('collapsed')) {
                        group.removeClass('offscreen');
                        span.removeClass('collapsed');
                        span.addClass('expanded');
                    } else if (span.hasClass('expanded')) {
                        group.addClass('offscreen');
                        span.removeClass('expanded');
                        span.addClass('collapsed');
                    }
                }
            });

            // EBSCO/Search : Collapse / expand facets
            Y.Event.on(Y.Selector.query('dl.narrowList.navmenu.expandable'), 'click', function (event) {
                var element = new Y.Element(event.currentTarget),
                    span = Y.Dom.getLastChild(Y.Dom.getLastChild(element)),
                    id = element.get('id').replace('facet-', ''),
                    group = new Y.Element(document.getElementById("narrowGroupHidden_" + id));
                if (span) {
                    span = new Y.Element(span);
                    if (span.hasClass('collapsed')) {
                        group.removeClass('offscreen');
                        span.removeClass('collapsed');
                        span.addClass('expanded');
                    } else if (span.hasClass('expanded')) {
                        group.addClass('offscreen');
                        span.removeClass('expanded');
                        span.addClass('collapsed');
                    }
                }
            });

            // Search : Ajax request the Record action
            Y.Event.delegate('toptabcontent', 'click', function (event, element) {
                var url = new Y.Element(element).get('href'),
                    spinner = new Y.Element(Y.Selector.query('#spinner', null, true));

                Y.Event.stopEvent(event);

                spinner.setStyle('left', (event.pageX - 18) + 'px');
                spinner.setStyle('top', (event.pageY - 18) + 'px');
                spinner.setStyle('display', 'block');

                var callback = {
                    success: function(data) {
                        new Y.Element(Y.Selector.query('#toptab', null, true)).setStyle('display', 'none');
                        Y.Selector.query('#toptabcontent', null, true).innerHTML = data.responseText;
                        spinner.setStyle('display', 'none');
                    }
                };
                Y.Connect.asyncRequest('GET', url, callback, null);
            }, '._record_link');

            // Advanced Search : Add a new search term
            Y.Event.delegate('toptabcontent', 'click', function (event) {
                Y.Event.stopEvent(event);
                var html = Y.Dom.get('advRowTemplate').innerHTML,
                    rows = Y.Selector.query('#group0SearchHolder .advRow');
                if (rows) {
                    // Find the index of the next row
                    var index = rows.length + 1;
                    // Replace NN string with the index number
                    html = html.replace(/NN/g, index);

                    var node = document.createElement('div');
                    node.innerHTML = html;
                    var element = Y.Dom.get('group0SearchHolder').appendChild(Y.Dom.getFirstChild(node));
                }
            }, '#advSearchForm-ebsco ._add_row');

            // Advanced Search : Delete an advanced search row
            Y.Event.delegate('toptabcontent', 'click', function (event, element) {
                Y.Event.stopEvent(event);
                var parent = Y.Dom.getAncestorByClassName(element, 'advRow');
                parent.parentNode.removeChild(parent);
            }, '#advSearchForm-ebsco ._delete_row');

            // Advanced Search : Reset the form fields to default values
            Y.Event.on(Y.Selector.query('#advSearchForm-ebsco .advSearchContent input[name="reset"]'), 'click', function (event) {
                Y.Event.stopEvent(event);
                var elements = Y.Selector.query('#searchHolder input, #searchHolder select');
                for (var i = 0, length = elements.length; i < length; i++) {
                    var item = new Y.Element(elements[i]),
                        type = item.get('type');
                    switch(type) {
                        case 'text':
                            item.set('value', '');
                            break;
                        case 'checkbox':
                            item.set('checked', '');
                            break;
                        case 'select-multiple':
                            var options =  Y.Selector.query('option', elements[i]);
                            for (var j = 0, l = options.length; j < l; j++) {
                                new Y.Element(options[j]).set('selected', '');
                            }
                            break;
                        case 'select-one':
                            var options = Y.Selector.query('option', elements[i]);
                            for (var j = 0, l = options.length; j < l; j++) {
                                var option = new Y.Element(options[j]);
                                option.set('selected', '');
                            }
                            // for IE
                            new Y.Element(options[0]).set('selected', 'selected');
                            break;
                        case 'radio':
                            item.set('checked', '');
                            var options = Y.Selector.query('input[type="radio"]', elements[i].parentNode);
                            new Y.Element(options[0]).set('checked', 'checked');
                            break;
                    }
                }
            });

            var width = new Y.Element(Y.Dom.get('DT1Slider')).getStyle('width'),
                max = parseInt(width.replace('px', '')),
                value = parseInt(new Y.Element(Y.Dom.get('DT1')).get('value'));
            slider = YAHOO.widget.Slider.getHorizSlider("DT1Slider", "hsliderthumb", 0, max),
            slider.setValue((value - 1000)/10);
            slider.subscribe('change', function (value) {
                value = value * 10 + 1000;
                new Y.Element(Y.Dom.get('DT1')).set('value', value);
                if(value == 1000) {
                    new Y.Element(Y.Dom.get('DT1limiter')).set('value', '');
                } else {
                    new Y.Element(Y.Dom.get('DT1limiter')).set('value', 'addlimiter(DT1:' + value + '-1/2501-1)');
                }
            });

            // when user enters values into the boxes
            // the slider needs to be updated too
            Y.Event.on(Y.Dom.get('DT1'), 'change', function (event) {
                var value = parseInt(new Y.Element(Y.Dom.get('DT1')).get('value'));
                slider.setValue((value - 1000)/10);
            });

        },

        init: function() {
            Y.Event.onDOMReady(this.initEventHandlers);
        }
    }

}();

EBSCO.init();