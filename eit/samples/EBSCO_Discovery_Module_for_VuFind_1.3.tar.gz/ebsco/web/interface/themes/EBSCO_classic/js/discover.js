/*
  The Discover module javascript
**/

var Discover = function() {

    var Y = YAHOO.util;

    // the returned object members will be publicly available
    return {

        // Return the error from HTML string
        parseError: function (html) {
            if (html.match('An error has occurred')) {
                start = html.indexOf('<div class="error fatalError">');
                end = html.length - 1;
                html = html.substring(start, end);
                end = html.indexOf('</div>');
                html = html.substring(0, end);
            }
            return html;
        },

        //we'll use this handler for onDOMReady:
        initEventHandlers: function (message) {

            // Home page : Modify submit action based on selected radio
            // "path" is a global javascript variable initialised in layout.tpl
             Y.Event.on(Y.Selector.query('.searchHomeForm input[type="submit"]'), 'click', function (event) {
                Y.Event.stopEvent(event);
                var form = Y.Dom.getAncestorByTagName(event.currentTarget, 'form');
                var radio = new Y.Element(Y.Selector.query('input[name="service"]:checked', form, true));
                switch(radio.get('id')) {
                    case 'service-combined':
                        new Y.Element(form).set('action', path + '/Discover/EBSCO');
                        break;
                    case 'service-catalog':
                        new Y.Element(form).set('action', path + '/Search/Results');
                        break;
                    case 'service-articles':
                        new Y.Element(form).set('action', path + '/EBSCO/Search');
                        break;
                }
                form.submit();
                return true;
            });

            // Combined Search : ajax call the /EBSCO/Search action
            var tab1 = Y.Selector.query('#toptab ul li:nth-child(1)')[0],
                tab2 = Y.Selector.query('#toptab ul li:nth-child(2)')[0],
                tab3 = Y.Selector.query('#toptab ul li:nth-child(3)')[0],
                active_tab = Y.Selector.query('#toptab ul li.active')[0];

            if(active_tab == tab1) {
                var url = new Y.Element(Y.Dom.getLastChild(tab3)).get('href');
                if (url) {
                    var callback = {
                        success: function(data) {
                            var html = Discover.parseError(data.responseText);
                            var articles_container = Y.Selector.query('.combined-column-right .combined-table-cell-content', null, true);
                            articles_container.innerHTML = html;
                            if (data.responseText.match('<ul class="recordSet">')) {
                                new Y.Element(Y.Selector.query('.combined-column-right .combined-more a')).removeClass('hide');
                            }
                        }
                    };
                    Y.Connect.asyncRequest('GET', url, callback, null);
                }
            }
        },

        init: function() {
            Y.Event.onDOMReady(this.initEventHandlers);
        }

    }

}();


Discover.init();