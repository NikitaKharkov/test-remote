/*
 * The EBSCO module javascript
 **/
$(document).ready(function () {

    // 
    var updatePublishDateSlider = function () {
        var from = parseInt($('#DT1').val());
        var min = 1000;

        if (!from || from < min) {
            from = min;
        }

        // and keep the max at 1 years from now
        var max = (new Date()).getFullYear() + 1;
        var to = max;

        // update the slider with the new min/max/values
        $('#DT1Slider').slider('option', {
            min: min, max: max, values: [from, to]
        });
    };

    /*
     * Self executing function
     **/
    var onLoad = function () {
        // EBSCO/Search : Expand limiters
        $('._more_limiters').live('click', function (event) {
            $("#moreLimiters").hide();
            $("#limitersHidden").removeClass("offscreen");
        });

        // Search : Collapse limiters
        $('._less_limiters').live('click', function (event) {
            $("#moreLimiters").show();
            $("#limitersHidden").addClass("offscreen");
        });

        // EBSCO/Search : Collapse / expand facets
        $('dl.narrowList.navmenu.expandable').live('click', function (event) {
            var span = $(this).find('dt span'),
                id = $(this).attr('id').replace('facet-','');
            if (span.length > 0) {
                if (span.hasClass('collapsed')) {
                    moreFacets(id);
                    span.removeClass('collapsed');
                    span.addClass('expanded');
                } else if (span.hasClass('expanded')) {
                    lessFacets(id);
                    span.removeClass('expanded');
                    span.addClass('collapsed');
                }
            }
        });

        // EBSCO/Search : Less facets
        $('._less_facets').live('click', function (event) {
            var id = $(this).attr('id').replace('less-facets-','');
            var dl = $('#facet-' + id);
            dl.trigger('click');
        });

        // Search : Ajax request the Record action
        $('._record_link').live('click', function (event) {
            var element = $(this);
            var position = element.position();
            event.preventDefault();
            $('#spinner').show();
            $("#spinner").offset({left:event.pageX - 18,top:event.pageY - 18});

            $.get(element.attr('href'), function (data) {
                $('#toptab').hide();
                $('#toptabcontent').html(data);
                $('#spinner').hide();
            });
        });

        // Advanced Search : Add a new search term
        $('#advSearchForm-ebsco ._add_row').live('click', function (event) {
            event.preventDefault();
            var newSearch = $('#advRowTemplate').html();
            var rows = $('#group0SearchHolder .advRow');
            if (rows) {
                // Find the index of the next row
                var index = rows.length + 1;
                // Replace NN string with the index number
                newSearch = newSearch.replace(/NN/g, index);
                $('#group0SearchHolder').append(newSearch);
            }
        });

        // Advanced Search : Delete an advanced search row
        $('#advSearchForm-ebsco ._delete_row').live('click', function (event) {
            event.preventDefault();
            $(this).parents('.advRow').remove();
        });

        // Advanced Search : Reset the form fields to default values
        $('#advSearchForm-ebsco .advSearchContent input[name="reset"]').live('click', function (event) {
            event.preventDefault();
            $('#searchHolder').find('input, select').each(function (index) {
                var type = $(this).attr('type');
                switch(type) {
                    case 'text':
                        $(this).val('');
                        break;
                    case 'checkbox':
                        $(this).attr('checked', '');
                        break;
                    case 'select-multiple':
                        $(this).children('option').each(function (index) {
                            $(this).attr('selected', '');
                        });
                        break;
                    case 'select-one':
                        $(this).children('option').each(function (index) {
                            $(this).attr('selected', '');
                        });
                        // for IE
                        $(this).children('option:first').attr('selected', 'selected');
                        break;
                    case 'radio':
                        $(this).attr('checked', '');
                        $(this).siblings().filter(":first").attr('checked', 'checked');
                        break;
                }
            });
        });

        // Advanced Search, Results : handle 'Date Published from' limiter
        // Create the UI slider
        $('#DT1Slider').slider({
            range: true,
            min: 0, max: 9999, values: [0, 9999],
            slide: function (event, ui) {
                $('#DT1').val(ui.values[0]);
                if(ui.values[0] == 1000) {
                    $('#DT1limiter').val('');
                } else {
                    $('#DT1limiter').val('addlimiter(DT1:' + ui.values[0] + '-1/2013-1)');
                }
            }
        });

        // initialize the slider with the original values
        // in the text boxes
        updatePublishDateSlider();

        // when user enters values into the boxes
        // the slider needs to be updated too
        $('#DT1').change(function(){
            updatePublishDateSlider();
        });
    }();


});
