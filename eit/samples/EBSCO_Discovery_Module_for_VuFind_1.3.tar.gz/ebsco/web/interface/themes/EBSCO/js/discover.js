/*
 The Discover module javascript
 **/
$(document).ready(function() {
    /*
     * Auto executing function
     * If the first tab is active then use an 
     * XHT call to load the content of the right column
     **/
    var onLoad = function () {
        // Home page : Modify submit action based on selected radio
        // "path" is a global javascript variable initialised in layout.tpl
        $('.searchHomeForm input[type="submit"]').live('click', function (event) {
            event.preventDefault();
            var form = $(this).parents('form');
            var radio = form.find('input[name="service"]:checked');
            switch(radio.attr('id')) {
                case 'service-combined':
                    form.attr('action', path + '/Discover/EBSCO');
                    break;
                case 'service-catalog':
                    form.attr('action', path + '/Search/Results');
                    break;
                case 'service-articles':
                    form.attr('action', path + '/EBSCO/Search');
                    break;
            }
            $(form).submit();
            return true;
        });

        // Combined Search : ajax call the /EBSCO/Search action
        var tab1 = $('#toptab ul li:eq(0)'),
            tab2 = $('#toptab ul li:eq(1)'),
            tab3 = $('#toptab ul li:eq(2)'),
            active_tab = $('#toptab ul li.active');
        if(active_tab.attr('id') == tab1.attr('id')) {
            var url = tab3.find('a').attr('href');
            if (url) {
                $.get(url, function (data) {
                    if (data.match('An error has occurred')) {
                        var start = data.indexOf('<div class="error fatalError">');
                        var end = data.length - 1;
                        data = data.substring(start, end);
                        end = data.indexOf('</div>');
                        data = data.substring(0, end);
                    }
                    $('.combined-column-right .combined-table-cell-content').html(data);
                    if (data.match('<ul class="recordSet">')) {
                        $('.combined-column-right .combined-more a').removeClass('hide');
                    }
                });
            }
        }
    }();
});