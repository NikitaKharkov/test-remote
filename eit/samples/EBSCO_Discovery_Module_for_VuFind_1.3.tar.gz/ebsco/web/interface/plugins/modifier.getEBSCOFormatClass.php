<?php
/**
 * getEBSCOFormatClass Smarty plugin
 *
 * PHP version 5
 *
 */

/**
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     modifier
 * Name:     getEBSCOFormatClass
 * Purpose:  Get a class to display an icon for a EBSCO format
 * -------------------------------------------------------------
 *
 * @param string $format Format string provided by EBSCO API
 *
 * @return string        Format string suitable for VuFind display
 */ // @codingStandardsIgnoreStart
function smarty_modifier_getEBSCOFormatClass($format)
{
    // @codingStandardsIgnoreEnd
    switch (strtolower($format)) {
    case 'audio recording':
        return 'audio';
    case 'book':
    case 'book chapter':
        return 'book';
    case 'computer file':
    case 'web resource':
        return 'electronic';
    case 'dissertation':
    case 'manuscript':
    case 'paper':
    case 'patent':
        return 'manuscript';
    case 'ebook':
        return 'ebook';
    case 'kit':
        return 'kit';
    case 'image':
    case 'photograph':
        return 'photo';
    case 'music score':
        return 'musicalscore';
    case 'newspaper article':
        return 'newspaper';
    case 'video recording':
        return 'video';
    case 'journal article':
    default:
        return 'journal';
    }
}
?>