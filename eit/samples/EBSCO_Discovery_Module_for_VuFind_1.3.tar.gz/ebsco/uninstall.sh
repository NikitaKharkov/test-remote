#!/bin/sh

# EBSCO module uninstaller
#
# I. How to run this script
#
# 1. In console run
# chmod +x uninstall.sh
# 2. In console run
# ./uninstall.sh /path/to/vufind
# e.g. ./uninstall.sh /usr/local/vufind
# Use a user that has write permission for the VuFind directory structure.
#
# II. What the script will do
#
# 1. It will remove all [EBSCO] entries from VuFind config.ini file
# 2. It will delete all the module files from the VuFind directories


# Variables
VUFIND_HOME=$1
CURRENT_PATH=`pwd`


# Remove all EBSCO module files from VuFind installation
delete_module () {
    source_dir="$CURRENT_PATH/web"
    destination_dir="$VUFIND_HOME/web"
    # Remove files
    if [ -d "$source_dir" ]; then
        for source_file in $(find $source_dir -type f) ; do
            destination_file=$(printf '%s' "$source_file" | sed "s@$CURRENT_PATH@$VUFIND_HOME@g")
            #destination_file=${source_file/$CURRENT_PATH/$VUFIND_HOME}
            rm -rf $destination_file
        done
    fi
    source_dir="$CURRENT_PATH/tests"
    destination_dir="$VUFIND_HOME/tests"
    # Remove files
    if [ -d "$source_dir" ]; then
        for source_file in $(find $source_dir -type f) ; do
            destination_file=$(printf '%s' "$source_file" | sed "s@$CURRENT_PATH@$VUFIND_HOME@g")
            #destination_file=${source_file/$CURRENT_PATH/$VUFIND_HOME}
            rm -rf $destination_file
        done
    fi
    empty_dirs=("$VUFIND_HOME/web/services/EBSCO" 
        "$VUFIND_HOME/web/services/Discover" 
        "$VUFIND_HOME/web/interface/themes/EBSCO" 
        "$VUFIND_HOME/web/interface/themes/EBSCO_default" 
        "$VUFIND_HOME/web/interface/themes/EBSCO_classic" 
        "$VUFIND_HOME/tests/web/sys/fixtures")
    for dir in ${empty_dirs[*]}
    do
        echo "Deleting $dir"
        rm -rf "$dir"
    done
    echo "Removed files from $destination_dir"
}


# Remove EBSCO module settings from VuFind settings
setup_module () {
    configuration_file="$VUFIND_HOME/web/conf/config.ini"
    backup_file="$VUFIND_HOME/web/conf/config.ini.ebsco"
    count=`grep -c "EBSCO[ ]*=[ ]*ebsco\.ini" $configuration_file`
    if [ $count -ne 0 ]; then
        sed -e "s/\(EBSCO\|EBSCO_default\|EBSCO_classic\),[ ]*//" $configuration_file > $backup_file
        sed -i "/EBSCO[ ]*=[ ]*ebsco.ini/d" $backup_file
        mv $backup_file $configuration_file
        echo "Updated $configuration_file"
    fi
}


# Main
if [ ${#1} -gt 0 ]; then
    echo ""
    delete_module
    setup_module
    echo "" ; echo "The EBSCO module was successfully uninstalled." ; echo ""
else
    echo "" ; echo "You did not provide any parameter. Run the script like this : ./uninstall.sh /path/to/vufind" ; echo ""
fi
