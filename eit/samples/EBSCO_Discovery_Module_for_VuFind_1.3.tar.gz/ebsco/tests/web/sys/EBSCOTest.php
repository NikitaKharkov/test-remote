<?php
/**
 * EBSCO Test Class
 *
 * PHP version 5
 */

require_once dirname(__FILE__) . '/../prepend.inc.php';
require_once dirname(__FILE__) . '/../../../web/sys/EBSCOAPI.php';



class EBSCOTest extends PHPUnit_Framework_TestCase
{
    // The directory where fixture files are located - test5
    protected $fixtures;

    protected function setUp()
    {
        global $configArray;

        $configArray = parse_ini_file(
            dirname(__FILE__) . '/../../../web/conf/config.ini', true
        );
        $this->fixtures = dirname(__FILE__) . '/fixtures';
        PEAR::setErrorHandling(PEAR_ERROR_RETURN);
    }


    /**
     * Test apiAuthenticationToken method
     */
    public function test_apiAuthenticationToken()
    {
        $xml = simplexml_load_file($this->fixtures . "/1.xml");

        // Stub all methods invoked when running EBSCOAPI::apiAuthenticationToken (without EBSCOResponse)
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('request'));
        $stub_connector->expects($this->once())->method('request')->will($this->returnValue($xml));
        $stub_api->expects($this->once())->method('connector')->will($this->returnValue($stub_connector));

        // Test apiAuthenticationToken
        $this->assertEquals('1234567890ABCDEF1234567890ABCDEF1234', $stub_api->apiAuthenticationToken());
    }


    /**
     * Test apiSessionToken method
     */
    public function test_apiSessionToken()
    {
        $xml = simplexml_load_file($this->fixtures . "/2.xml");

        // Stub all methods invoked when running EBSCOAPI::apiSessionToken (without EBSCOResponse)
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('request'));
        $stub_connector->expects($this->once())->method('request')->will($this->returnValue($xml));
        $stub_api->expects($this->once())->method('connector')->will($this->returnValue($stub_connector));

        // Test apiSessionToken
        $this->assertEquals('1234567890', $stub_api->apiSessionToken());
    }


    /**
     * Test apiSearch method
     */
    public function test_apiSearch()
    {
        $expected_result = array(
            'recordCount' => 29828243,
            'response' => array(
                'numFound' => 1,
                'start' => 1,
                'docs' => array(
                     array(), array(), array(), array(), array(), array(), array(), array(), array(), array()
                )
            )
        );
        $search = array(array('lookfor' => 'something'));
        $xml1 = simplexml_load_file($this->fixtures . "/1.xml");
        $xml2 = simplexml_load_file($this->fixtures . "/2.xml");
        $xml3 = simplexml_load_file($this->fixtures . "/3.xml");

        // Stub all methods invoked when running EBSCOAPI::apiSearch (without EBSCOResponse)
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('request'));
        $stub_connector->expects($this->any())->method('request')->will($this->onConsecutiveCalls($xml1, $xml2, $xml3));
        $stub_api->expects($this->any())->method('connector')->will($this->returnValue($stub_connector));

        // Test apiSearch
        $result = $stub_api->apiSearch($search, array());
        $this->assertEquals($expected_result['recordCount'], $result['recordCount']);
        $this->assertEquals(count($expected_result['response']['docs']), count($result['response']['docs']));
    }


    /**
     * Test apiRetrieve method
     */
    public function test_apiRetrieve()
    {
        $expected_result = array(
            'DbId'        => 'e000xna',
            'AN'          => '420359',
            'recordtype'  => 'EBSCO'
        );
        $xml1 = simplexml_load_file($this->fixtures . "/1.xml");
        $xml2 = simplexml_load_file($this->fixtures . "/2.xml");
        $xml3 = simplexml_load_file($this->fixtures . "/4.xml");
        $an = 1; $db = 2;

        // Stub all methods invoked when running EBSCOAPI::apiRetrieve (without EBSCOResponse)
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('request'));
        $stub_connector->expects($this->any())->method('request')->will($this->onConsecutiveCalls($xml1, $xml2, $xml3));
        $stub_api->expects($this->any())->method('connector')->will($this->returnValue($stub_connector));

        // Test apiRetrieve
        $result = $stub_api->apiRetrieve($an, $db);
        $this->assertEquals($expected_result['DbId'], $result['DbId']);
    }


    /**
     * Test EBSCOConnector::request method for exceptions raised by HTTP_Request::sendRequest
     */
    public function test_request_1()
    {
        $error = PEAR::raiseError('Request error');

        // Stub all methods invoked when running EBSCOConnector::request
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('client'));
        $stub_client = $this->getMock('HTTP_Request', array('sendRequest'));
        $stub_api->expects($this->once())->method('connector')->will($this->returnValue($stub_connector));
        $stub_connector->expects($this->once())->method('client')->will($this->returnValue($stub_client));
        $stub_client->expects($this->once())->method('sendRequest')->will($this->returnValue($error));

        // Test EBSCOConnector::request
        $result = $stub_api->apiAuthenticationToken();
        $this->assertEquals($error->getMessage(), $result->getMessage());
    }


    /**
     * Test EBSCOConnector::request method for 404 responses returned by HTTP_Request::sendRequest
     */
    public function test_request_2()
    {
        // Stub all methods invoked when running EBSCOConnector::request
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('client'));
        $stub_client = $this->getMock('HTTP_Request', array('sendRequest', 'getResponseCode'));
        $stub_api->expects($this->once())->method('connector')->will($this->returnValue($stub_connector));
        $stub_connector->expects($this->once())->method('client')->will($this->returnValue($stub_client));
        $stub_client->expects($this->once())->method('sendRequest')->will($this->returnValue('something'));
        $stub_client->expects($this->once())->method('getResponseCode')->will($this->returnValue(EBSCOConnector::HTTP_NOT_FOUND));

        // Test EBSCOConnector::request
        $result = $stub_api->apiAuthenticationToken();
        $this->assertEquals('HTTP 404 : The resource you are looking for might have been removed, had its name changed, or is temporarily unavailable.', $result->getMessage());
    }


    /**
     * Test _call method for "Authorization Token missing" EBSCO errors 
     */
    public function test_request_3()
    {
        $xml_str = file_get_contents($this->fixtures . "/5.xml");

        // Stub all methods invoked when running EBSCOConnector::request
        $stub_api = $this->getMock('EBSCOAPI', array('connector'));
        $stub_connector = $this->getMock('EBSCOConnector', array('client'));
        $stub_client = $this->getMock('HTTP_Request', array('sendRequest', 'getResponseCode', 'getResponseBody'));
        $stub_api->expects($this->once())->method('connector')->will($this->returnValue($stub_connector));
        $stub_connector->expects($this->once())->method('client')->will($this->returnValue($stub_client));
        $stub_client->expects($this->once())->method('sendRequest')->will($this->returnValue('something'));
        $stub_client->expects($this->once())->method('getResponseCode')->will($this->returnValue(EBSCOConnector::HTTP_BAD_REQUEST));
        $stub_client->expects($this->any())->method('getResponseBody')->will($this->returnValue($xml_str));

        // Test EBSCOConnector::request
        $result = $stub_api->apiSessionToken();
        $this->assertEquals(EBSCOConnector::EDS_AUTH_TOKEN_MISSING, $result->getCode());
    }

}
?>