/*
 * StreamsHandler.java
 *
 * Created on February 1, 2008, 1:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.util.streams;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;


/**
 *
 * @author msanchez
 */
public class StreamsHandler {
   
   /** Creates a new instance of StreamsHandler */
   public StreamsHandler() {
   }
   
   //closes InputStream
   public static ByteArrayOutputStream readInto( InputStream is )
   throws IOException{
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      
      byte[] buf = new byte[1024*8];
      int len;
      while ((len = is.read(buf)) > 0)
         out.write(buf, 0, len);
      
      try{is.close();}catch(Exception e){}
      return out;
   }
}
