/*
 * XMLTransformationException.java
 *
 * Created on February 22, 2007, 4:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.util.xslt;

/**
 *
 * @author msanchez
 */
public class XMLTransformationException extends Exception {
   
   /** Creates a new instance of XMLTransformationException */
   public XMLTransformationException( Exception e ) {
      super(e);
   }
   
   public XMLTransformationException( String e ) {
      super(e);
   }
   
}
