/*
 * XMLTransformer.java
 *
 * Created on September 28, 2006, 5:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.util.xslt;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;

import java.util.Enumeration;

/**
 *
 * @author MSanchez
 */
public class XMLTransformer {
   
   private StreamSource xsl;
   Transformer transformer;
   boolean ignoreErrors;
   
   /** Creates a new instance of XMLTransformer */
   public XMLTransformer( File xslFile ) 
   throws XMLTransformationException{
      try{
         TransformerFactory factory = TransformerFactory.newInstance();
         transformer = factory.newTransformer(new StreamSource(xslFile));
      }catch( TransformerConfigurationException e ){
         throw new XMLTransformationException(e);
      }
   }
   
   public XMLTransformer( InputStream xsl ) 
   throws XMLTransformationException{
      try{
         TransformerFactory factory = TransformerFactory.newInstance();
         transformer = factory.newTransformer(new StreamSource(xsl));
      }catch( TransformerConfigurationException e ){
         throw new XMLTransformationException(e);
      }
   }
  
   public XMLTransformer( String xslFile ) 
   throws XMLTransformationException{
      try{
         if( !new File(xslFile).exists() )
            throw new XMLTransformationException("XSLT file not found");
         
         TransformerFactory factory = TransformerFactory.newInstance();
         transformer = factory.newTransformer(new StreamSource(xslFile));
      }catch( TransformerConfigurationException e ){
         throw new XMLTransformationException(e);
      }
   }

   public XMLTransformer( java.net.URL xslFileURL ) 
   throws XMLTransformationException{
      try{
         TransformerFactory factory = TransformerFactory.newInstance();
         transformer = factory.newTransformer(new StreamSource(xslFileURL.toString()));
      }catch( TransformerConfigurationException e ){
         throw new XMLTransformationException(e);
      }
   }
   
   public void setParameter( String name, String value ){
      transformer.setParameter(name,value);
   }

   public void transform( byte[] xml, OutputStream out )
   throws XMLTransformationException{
      try{
         transformer.transform(
               new StreamSource(new java.io.ByteArrayInputStream(xml)),
               new StreamResult(out)
               );
      }catch( TransformerException e ){
         throw new XMLTransformationException(e);
      }
   }

   public void transform( InputStream in , OutputStream out )
   throws XMLTransformationException{
      try{
         transformer.transform(new StreamSource(in),new StreamResult(out));
      }catch( TransformerException e ){
         throw new XMLTransformationException(e);
      }
   } 
}
