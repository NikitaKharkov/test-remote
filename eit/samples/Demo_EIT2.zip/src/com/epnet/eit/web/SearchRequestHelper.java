/*
 * RequestHelper.java
 *
 * Created on February 1, 2008, 1:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.eit.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;

/**
 * Helper class to service a search request
 * @author msanchez@ebscohost.com
 */
public class SearchRequestHelper {
   
   /**
    * Records per page. Used to calculate pagination.
    */
   private int recordsPerPage;
   
   /**
    * Creates a new instance of RequestHelper
    * @param recordsPerPage Records per page for pagination
    * @throws java.lang.Exception If records per page provided is not a valid number
    */
   public SearchRequestHelper( String recordsPerPage ) 
   throws Exception{
      this.recordsPerPage = Integer.parseInt(recordsPerPage);
   }
   
   /**
    * This method throws an exception if a mandatory parameter is not found
    * @param request The HttpServletRequest received
    * @param param parameter to retrieve from request.
    * @param mandatory if parameter to retrive if mandatory. 
    * This indicates the object to throw an Exception if true not found.
    * @return parameter or null if not found and not mandatory
    * @throws javax.servlet.ServletException If parameter not found and mandatory
    */
   protected String getParameter( HttpServletRequest request, String param, boolean mandatory )
   throws ServletException{
      String value = request.getParameter(param);
      if( value==null ){
         if( mandatory )
            throw new ServletException("Mandatory field not defined: "+param);
         else
            value = "";
      }
      
      return value;
   }

   /**
    * Get the proper page according to request
    * @param request request
    * @return page or null if not found or incorrect page provided
    */
   protected String getPage( HttpServletRequest request ){
      if( request.getParameter("page")==null )
         return null;
      
      try{
         int page = Integer.parseInt(request.getParameter("page"));
         if( page<=0 )
            return null;
         
         return "" + (page*recordsPerPage - recordsPerPage + 1);
      }catch( Exception e ){
         return null;
      }
   }
   
   /**
    * Verifies that the request contains al least the main parameters:
    * db and query
    * @param request The HttpServletRequest received
    * @return true - if at least mandatory parameters are included in the request. 
    * false - otherwise
    */
   protected boolean isValidRequest( HttpServletRequest request ){
      return 
            request.getParameter("query")!=null && 
            !request.getParameter("query").equals("") &&
            request.getParameter("db")!=null && 
            !request.getParameter("db").equals("");
   }
   
   /**
    * Quickly analizes the XML to determine if it is a one-hit record search.
    * @param xml search xml 
    * @return true if only one hit, false otherwise
    */
   protected boolean isSingleRecordResult( String xml ){
      try{
         int index = xml.indexOf("<Hits>")+"<Hits>".length();
         return Integer.parseInt(
                  xml.substring(
                     index,
                     xml.indexOf("</Hits>",index)
                  )
               )==1;
      }catch( Exception e ){
         return false;
      }
   }

   /**
    * Gets the first article id (AN) from the search XML.
    * If isSingleRecordResult is true, this one may be used to get that single AN.
    * @param xml search xml
    * @return AN
    */
   protected String getFirstAN( String xml ){
      try{
         int index = xml.indexOf("uiTerm=\"")+"uiTerm=\"".length();
         return xml.substring(
                  index,
                  xml.indexOf("\"",index)
               );
      }catch( Exception e ){
         return "#";
      }
   }
   
}
