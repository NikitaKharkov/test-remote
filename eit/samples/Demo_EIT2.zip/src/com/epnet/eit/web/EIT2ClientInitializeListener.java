/*
 * NewServletListener.java
 *
 * Created on February 1, 2008, 11:59 AM
 */

package com.epnet.eit.web;

import javax.servlet.ServletContextListener;
import javax.servlet.ServletContextEvent;

import com.epnet.eit2.rest.client.UserEIT2Client;
import com.epnet.eit2.rest.client.EITClientException;

/**
 *This Listener initializes the EIT client with the profile and password you
 *assing through web.xml
 *
 * @author  msanchez
 * @version
 *
 * Web application lifecycle listener.
 */

public class EIT2ClientInitializeListener implements ServletContextListener {
   
   /**
    * Initalizes EIT resources when application starts
    * @param evt Environment
    */
   public void contextInitialized(ServletContextEvent evt) {
      javax.servlet.ServletContext ctx = evt.getServletContext();
      
      try{
         
         UserEIT2Client eit = new UserEIT2Client(
               ctx.getInitParameter("EITHost"),
               ctx.getInitParameter("profile"),
               ctx.getInitParameter("password")
               );
         
         ctx.setAttribute("eit2Client",eit);
   
      }catch( Exception e ){
         ctx.log("Unable to initializa EIT2Client",e);
      }
   }

   /**
    * Does nothing
    * @param evt Environment
    */
   public void contextDestroyed(ServletContextEvent evt) {
   }
}
