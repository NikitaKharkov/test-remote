/*
 * RequestHelper.java
 *
 * Created on February 1, 2008, 1:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.eit.web;

import javax.servlet.http.HttpServletRequest;

/**
 * Helper class to service a record request
 * @author msanchez@ebscohost.
 */
public class RecordRequestHelper {
   
   /** Creates a new instance of RequestHelper */
   public RecordRequestHelper() {
   }
   
   /**
    * Verifies that the request contains al least the main parameters:
    * db and an
    * @param request The HttpServletRequest received
    * @return true - if at least mandatory parameters are included in the request. 
    * false - otherwise
    */
   protected boolean isValidRequest(  HttpServletRequest request ){
      return 
            request.getParameter("an")!=null && 
            !request.getParameter("an").equals("") &&
            !request.getParameter("an").equals("-1") &&
            request.getParameter("db")!=null && 
            !request.getParameter("db").equals("");
   }
}
