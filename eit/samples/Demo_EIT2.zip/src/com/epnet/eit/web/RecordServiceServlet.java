/*
 * RetrieveServiceServlet.java
 *
 * Created on December 4, 2007, 4:37 PM
 */

package com.epnet.eit.web;

import com.epnet.eit2.rest.client.UserEIT2Client;
import com.epnet.eit2.rest.client.EITClientException;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.epnet.util.streams.StreamsHandler;

import com.epnet.util.xslt.*;


/**
 * Serves record requests
 * @author msanchez@ebscohost.com
 * @version 1.0
 */
public class RecordServiceServlet extends HttpServlet {
   
   /**
    * The EIT client
    */
   UserEIT2Client eit;
   /**
    * A helper class to fulfill request
    */
   RecordRequestHelper helper;
   /**
    * The XSL transformer to present XML from EIT
    */
   XMLTransformer recordTransformer;
   
   /**
    * Initialize the servlet: create transformer, retrieve EIT client from context and create helper
    * @param config Configuration
    * @throws javax.servlet.ServletException If either the helper or the transformer creation fails
    */
   public void init( ServletConfig config )
   throws ServletException{
      super.init(config);

      //get EIT client from context
      eit = (UserEIT2Client)config.getServletContext().getAttribute("eit2Client");
      if( eit==null )
         throw new ServletException("EIT2Client not set in context");
      
      //create XML transformer
      try{
         recordTransformer = new XMLTransformer(
                  config.getServletContext().getRealPath( 
                     "/WEB-INF/xsl/"+config.getInitParameter("Record_XSLFilename")
                  )
               );
         
      }catch( XMLTransformationException e ){
         log("[INIT] Unable to create record transformer");
         throw new ServletException(e);
      }
      
      //create helper
      helper = new RecordRequestHelper();
   }
   
   
   /**
    * Fulfills request, both GET and POST
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {

      //if not all mandatory parameters, abort
      if( !helper.isValidRequest(request) )
         throw new ServletException("Invalid request");
      
      String db = request.getParameter("db");
      String an = request.getParameter("an");
      
      recordTransformer.setParameter("searchDB",db);
      
      //invoke EIT search
      ByteArrayOutputStream outXML;
      try{
         //search(query, startrec_1, numrec_10, sort_date, db, format_brief, subset_)
         outXML = StreamsHandler.readInto(
                  eit.search("an "+an,"1","1",null,db,"full",null)
               );
      }catch( Exception e ){
         throw new ServletException(e);
      }
      
      response.setCharacterEncoding("UTF-8");
      OutputStream out;
      
      //present record with XSL
      out = response.getOutputStream();
      try{
         recordTransformer.transform(outXML.toByteArray(),out);
      }catch( Exception e ){
         throw new ServletException(e);
      }
      
      out.close();
   }
   
   /**
    * Fulfill GET request
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
      processRequest(request, response);
   }
   
   /**
    * Fulfills POST request
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
      processRequest(request, response);
   }
   
   /**
    * Returns a short description of the servlet.
    * @return Description
    */
   public String getServletInfo() {
      return "EIT2 demo application - record retrieval";
   }
}
