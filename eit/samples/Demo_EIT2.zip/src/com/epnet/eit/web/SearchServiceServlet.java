/*
 * RetrieveServiceServlet.java
 *
 * Created on December 4, 2007, 4:37 PM
 */

package com.epnet.eit.web;

import com.epnet.eit2.rest.client.UserEIT2Client;
import com.epnet.eit2.rest.client.EITClientException;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.epnet.util.streams.StreamsHandler;

import com.epnet.util.xslt.*;


/**
 * Serves search requests
 * @author msanchez@ebscohost.com
 * @version 1.0
 */
public class SearchServiceServlet extends HttpServlet {
   
   /**
    * The EIT client
    */
   UserEIT2Client eit;
   /**
    * The number of records to retrieve per call and display
    */
   String recordsPerPage;
   /**
    * A helper class to fulfill request
    */
   SearchRequestHelper helper;
   /**
    * The XSL transformer to present XML from EIT
    */
   XMLTransformer searchTransformer;
   
   /**
    * Initialize the servlet: create transformer, retrieve EIT client from context and create helper
    * @param config Configuration
    * @throws javax.servlet.ServletException If the transformer creation fails
    */
   public void init( ServletConfig config )
   throws ServletException{
      super.init(config);

      //get EIT client from context
      eit = (UserEIT2Client)config.getServletContext().getAttribute("eit2Client");
      if( eit==null )
         throw new ServletException("EIT2Client not set in context");
      
      //get recordsPerPage
      try{
         recordsPerPage = config.getInitParameter("recordsPerPage");
         Integer.parseInt(recordsPerPage);
      }catch( Exception e ){
         throw new ServletException("Improper recordsPerPage value");
      }

      //create XML transformer
      try{
         searchTransformer = new XMLTransformer(
                  config.getServletContext().getResourceAsStream( 
                     "/WEB-INF/xsl/"+config.getInitParameter("Search_XSLFilename")
                  )
               );
         
      }catch( XMLTransformationException e ){
         log("[INIT] Unable to create search transformer");
         throw new ServletException(e);
      }
      
      //create helper
      try{
         helper = new SearchRequestHelper(recordsPerPage);
      }catch( Exception e ){
         log("[INIT] Unable to create helper");
         throw new ServletException(e);
      }
   }
   
   
   /**
    * Fulfills request, both GET and POST
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {

      //if not all mandatory parameters, abort
      if( !helper.isValidRequest(request) )
         throw new ServletException("Invalid request");
      
      String db = helper.getParameter(request,"db",true);
      String query = helper.getParameter(request,"query",true);
      
      //set db for XSL
      searchTransformer.setParameter("searchDB",db);
      
      //invoke EIT search
      ByteArrayOutputStream outXML;
      try{
         //search(query, startrec_1, numrec_10, sort_date, db, format_brief, subset_)
         outXML = StreamsHandler.readInto(
                  eit.search(
                     query,
                     helper.getPage(request), //if null, will use 1
                     recordsPerPage, //from initParam in web.xml
                     request.getParameter("sort"), //db dependant
                     db,
                     null, //for search use always default brief
                     null //for common search, don't set
                  )
               );
      }catch( Exception e ){
         throw new ServletException(e);
      }

      //analyze XML. If single hit, send record request instead
      String xml = outXML.toString("UTF-8");
      if( helper.isSingleRecordResult(xml) ){
         response.sendRedirect(
               request.getContextPath()+"/record?" +
               "db="+db+
               "&an="+helper.getFirstAN(xml)
               );
         return;
      }
      
      //otherwise, present search
      OutputStream out = response.getOutputStream();
      try{
         searchTransformer.transform(outXML.toByteArray(),out);
      }catch( Exception e ){
         throw new ServletException(e);
      }
      out.close();
   }
   
   /**
    * Fulfill GET request
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
      processRequest(request, response);
   }
   
   /**
    * Fulfills POST request
    * @param request servlet request
    * @param response servlet response
    * @throws javax.servlet.ServletException If unable to complete request
    * @throws java.io.IOException If unable to complete request
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
      processRequest(request, response);
   }
   
   /**
    * Returns a short description of the servlet.
    * @return Description
    */
   public String getServletInfo() {
      return "EIT2 demo application - search";
   }
}
