package com.ebsco;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

public class SearchType 
{
	long startRecord=0;
	UtilFunction utilObject=new UtilFunction();
    /// <summary>
    /// This method return XML documents which is the response of the webservice according the parameters 
    /// pass in the method
    /// </summary>
    /// <param name="method">Containt the name of method which has to be called from webservice</param>
    /// <param name="queryValue">Query which has to be passed in the Webservices</param>
    /// <param name="strStart">Start record count</param>
    /// <param name="count">Record count</param>
    /// <returns>XMLDOCUMENTS</returns>
    public Document GetResponseData(String method,String queryValue,String strStart,String count,String strUserID,String strPwd,String strDb)	//working
    {
        Document XMLDoc = null;
        String EITServiceURL="";
        try
        {
            //Checking the type of method which has to be called
            if (method.equals("Search"))
            {
                if (count=="50")
                	EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + method + "?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue + "&startrec=" + (Integer.parseInt(strStart) - startRecord) + "&numrec=50";
                else
                    EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + method + "?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue + "&startrec=" + strStart;
            }
            else if (method.equals("GetClusters"))
                EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/"+ method +"?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue;
            //Declare an HTTP-specific implementation of the WebRequest class.
            URL iurl = new URL(EITServiceURL);
      		HttpURLConnection uc = (HttpURLConnection)iurl.openConnection();
    		uc.setRequestMethod("GET");
    		uc.setDoOutput(true);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		 //----------------Start HttpResponse-------------------//
    		XMLDoc= docBuilder.parse (iurl.openStream());
    		uc.disconnect(); 
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return XMLDoc;
    }
    /// <summary>
    /// Get Rss Response Data by the webservice
    /// </summary>
    /// <returns>Document</returns>
    public Document GetRssResponseData()
    {
        Document XMLDoc = null;
        try
        {
            //URL of the service
            String EITServiceURL = "http://rss.ebscohost.com/AlertSyndicationService/Syndication.asmx/GetFeed?guid=3030448";
            //Declare XMLResponse document
            //Declare an HTTP-specific implementation of the WebRequest class.
          //Declare an HTTP-specific implementation of the WebRequest class.
            URL iurl = new URL(EITServiceURL);
    		HttpURLConnection uc = (HttpURLConnection)iurl.openConnection();
    		uc.setRequestMethod("GET");
    		uc.setDoOutput(true);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		 //----------------Start HttpResponse-------------------//
    		XMLDoc= docBuilder.parse (iurl.openStream());
    		uc.disconnect(); 
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return XMLDoc;
    }
    // This function creates an array of breadcrumbs using the formatted query
    // String. This function simply splits the query String using )+AND+(SU+ as
    // a delimiter, which separates the terms by subject.
    // ["breadcrumb name"] = "query String";
    // where "query String" is the query relevant to that breadcrumb.
    public Map<String,String> Breadcrumbs(String query)
    {
        // Output the breadcrumbs
        String tempQuery = "";
		// query.matches("");
        String delimiter = "\\)\\+AND\\+\\(SU\\+";
        String[] breadcrumbs = query.split(delimiter);
        int item = 0;
        Map<String, String> hashtable=new LinkedHashMap<String, String>();
        for (String breadcrumb : breadcrumbs)
        {
            item++;
            String str = "";
            // Make Breadcrumbs Readable
            str = breadcrumb.replace("+", " ");
            str = str.replace("(", "");
            str = str.replace(")", "");
            str = str.replace("+AND+FT+Y", "");
            str = str.replace("AND FT Y", "");
            // This is the query String. Each breadcrumb will have its own query String.
            tempQuery = "";
            // This loop builds the query up. For the first breadcrumb, it will
            // only include the first query. For the second breadcrumb, it will
            // include the first and second, etc.
            for (int index = 0; index < item; index++)
            {
                tempQuery += breadcrumbs[index];
                if (index != (item - 1))
                	tempQuery += ")+AND+(SU+";
            }
            // If the last character is not a parenthesis, append one
            // onto the query.
            int last=(tempQuery.length()) - 1;
            if (tempQuery.charAt(last) != ')')
            {
                tempQuery += ")";
            }
            if(!hashtable.containsKey(str))
               	hashtable.put(str,tempQuery);
        }
        return hashtable;
    }
    /// <summary>
    /// This function will retrieve the subjects associated with a search
    /// and return the 10 most common subjects in a sorted array.  It does this
    /// by retrieving the 50 records closest to the current start record.
    /// exclude is an associative array of items to not include in the
    /// returned subjects.  For any given $subject, if $exclude[ $subject ] is 
    /// set, then it, then it will not display that particular subject.
    /// </summary>
    /// <param name="query">Query for the term which has to be search</param>
    /// <param name="start"></param>
    /// <param name="exclude"></param>
    /// <returns></returns>
	public ArrayList<String> SubjectClusters(String query, String start, Map<String, String> exclude,String strUserID,String strPwd,String strDb)
    {
        ArrayList<String> arryList = new ArrayList<String>();
        try
        {
            Document xmldocument;
            long startRecord = 0;
            startRecord = Integer.parseInt(start) - 25;
            startRecord = (startRecord < 1) ? (24 - (25 - Integer.parseInt(start))) : (25);
            query = query.replace(" ", "+");
            // Retrieve the XML search file from the EIT Search Service.
            xmldocument = GetResponseData("Search", query, Long.toString((Integer.parseInt(start) - startRecord)), "50",strUserID,strPwd,strDb);
            String stringObtained=utilObject.getStringFromDocument(xmldocument);
            //Removing the xml version
			String replacedElement="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			String strXmlDoc=stringObtained.replace(replacedElement," ");
			Pattern p = Pattern.compile("<subj type=\"thes\">(.+?)</subj>");
			Matcher m = p.matcher(strXmlDoc);
			String strXml;
            //To find the subject from the XML
            HashMap<String, Integer> htSubject = new HashMap<String, Integer>();
            while(m.find())
            {
                strXml = m.group(1);
                String strvalue = strXml.replace("<subj type=\"thes\">", "").replace("</subj>", "");
                String StringSeparators =strXml;
                String[] result;
                result = strXmlDoc.split(StringSeparators);
                if(!htSubject.containsKey(strvalue) && !exclude.containsKey(strvalue))
                {
                	htSubject.put(strvalue, (result.length - 1));
                }
            }
            //Sorting the data retrive in the HashMap
            int k = 0;
            for (Iterator<String> itr = sortByValue(htSubject).iterator(); itr.hasNext(); )
	        {
            	 //Taking the top 10 record to display 
            	if (k <= 9)
                {
            		String key = itr.next();
					arryList.add(key);
                }
                else
                {
                    break;
                }
                k++;
	        }
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return arryList;
    }
    
    @SuppressWarnings("unchecked")
	private static List<String> sortByValue(final Map<String, Integer> m)
	{
		List<String> keys = new ArrayList<String>();
		keys.addAll(m.keySet());
		Collections.sort(keys, new Comparator() 
		{
			public int compare(Object o1, Object o2)
			{
				Object v1 = m.get(o1);
				Object v2 = m.get(o2);
				if (v2 == null)
				{
					return (v1 == null) ? 0 : 1;
				}
				else if (v2 instanceof Comparable)
				{
					return ((Comparable<Object>) v2).compareTo(v1);
				}
				else 
				{
					return 0;
				}
			}
		});
	    return keys;
	}
}