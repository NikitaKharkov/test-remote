package com.ebsco;

import java.io.StringReader;
import java.io.StringWriter;
import java.net.MalformedURLException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;


public class UtilFunction 
{
	//Method for taking input as a document and getting it transformed to a string using the 
	// transform method of Transformer class 
	public String getStringFromDocument(Document doc)
	{
	    try
	    {
	       //DomSource object is created here of class DomSource
	       DOMSource domSource = new DOMSource(doc);
	     //StringWriter object is created here of class StringWriter
	       StringWriter writer = new StringWriter();
	     //StreamResult object is created here of class StreamResult
	       StreamResult result = new StreamResult(writer);
	     //TransformerFactory object is created here of class TransformerFactory
	       TransformerFactory tf = TransformerFactory.newInstance();
	       Transformer transformer = tf.newTransformer();
	       //Transformation is done here taking domsource as input and result as output.
	       transformer.transform(domSource, result);
	       return writer.toString();
	    }
	    catch(TransformerException ex)
	    {
	       ex.printStackTrace();
	       return null;
	    }
	} 
	//This method takes the absolute path of XSL as input along with the string and gives the transformed string as output
	public String getXML(String xslPath,String xmlDoc)
	{
		//DocumentBuilderFactory object is created here of class DocumentBuilderFactory
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance(); 
		DocumentBuilder docBuilder;
		StreamResult result = new StreamResult(new StringWriter());
		try
		{
			//A new instance of the DocumentBuilder is created.
			docBuilder=docBuilderFactory.newDocumentBuilder();
			//StringReader object is created of class StringReader which reads the string passed as a parameter.
			StringReader reader = new StringReader(xmlDoc);
			//InputSource object is created of class InputSource which reads the data as a character stream.
			InputSource inputSource = new InputSource();
			inputSource.setCharacterStream(reader);
			//Obtain a new instance of a DOM Document object to build a DOM tree with. 
			docBuilder.newDocument();
			//Parsing is done and a document is returned.
			Document docXML=docBuilder.parse(inputSource);
			
			DOMSource source = new DOMSource(docXML);
			TransformerFactory tFactory = TransformerFactory.newInstance();
			//Absolute path of the XSL is given as input to transformer
			Transformer transformer = tFactory.newTransformer(new StreamSource(xslPath));
			//Transformation is done taking the document as input in DomSource and result string is sent back as response.
			transformer.transform(source, result);
		} 
		catch (MalformedURLException e) 
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result.getWriter().toString();
	}	
}
