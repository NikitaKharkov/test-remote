package com.ebsco;

import java.net.HttpURLConnection;
import java.net.URL;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;

public class Rest 
{
	// Holds the URL of the service
	private String service_url;    
	public String url="";	    
	/**
	*This function initializes the class with the URL of the data
	*service.
	*/
	public void connect(String  u_service_url )
	{
	    this.service_url = u_service_url; 
	}
	/**
	*Sends a command. If the web service is located at
	*http://example.com/service.aspx/ , the command 'Info' would
	*would look as follows:
	*http://example.com/service.aspx/Info?param1=value&param2=value
	* @param v_strURL
	* @param parm
	* @param strUserID
	* @param strPwd
	* @return Document 
	*/
	public Document send(String v_strURL, String[] parm,String strUserID,String strPwd)
	{
		Document XMLDoc = null;
		/**
		 * Call to the URL function is made here depending on the value of the
		 * v_strURL value we get different responses
		 * http://example.com/service.aspx/ , the v_strURL="Info" 
		 * would look as follows:
		 * http://example.com/service.aspx/Info?prof=value&pwd=value
		 */
	    url =getURL(v_strURL, parm,strUserID,strPwd);
	    try
	    {
	    	
	    	if ( url != "" ) 
	    	{
	    		URL iurl = new URL(url);
	    		//Returns a URLConnection object to the remote object referred to by the URL. 
	    		HttpURLConnection uc = (HttpURLConnection)iurl.openConnection();
	    		uc.setRequestMethod("GET");
	    		uc.setDoOutput(true);
	    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	    		XMLDoc= docBuilder.parse (iurl.openStream());
	    		uc.disconnect();
	    	}
	    }
	    catch(Exception e)
	    {
	    	//Redirecting to the error page
	    }
	    return XMLDoc;
	}
	/**
	 * Using the values of the params for generating URL.
	 * @param v_strURL
	 * @param parm
	 * @param strUserID
	 * @param strPwd
	 * @return String url
	 */
	public String getURL(String v_strURL, String[] parm,String strUserID,String strPwd)
	{
		if (v_strURL == "Info")
		{
			url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd;
		}
		else if (v_strURL == "Browse")
		{
			url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd + "&index=" + parm[0] + "&term=" + parm[1] + "&db=" + parm[2];
		}
		else if (v_strURL == "Search")
		{
			url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd + "&query=" + parm[0] + "&startrec=" + parm[1] + "&db=" + parm[2] + "&sort=" + parm[3];
		}
		return url;
	}
}
