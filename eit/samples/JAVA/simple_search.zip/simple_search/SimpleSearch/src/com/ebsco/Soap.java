package com.ebsco;

import java.net.*;
import java.io.*;

public class Soap
{
	/**
     *This SOAP message requests database information from the service.  
     */ 
	public String Info(String strUserID,String strPwd)
    {
        // This SOAP message requests database information from the service.
        String xmlInfoResponse = "";
        try
        {
            //Create cutom soap header 
            StringBuilder strInfoRequestBody = new StringBuilder();
            strInfoRequestBody.append("<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" soap:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding\">");
            strInfoRequestBody.append("<soap:Header><auth:AuthorizationHeader soap:mustUnderstand=\"1\" xmlns:auth=\"http://epnet.com/webservices/SearchService/2007/07/\">");
            strInfoRequestBody.append("<auth:Profile>" + strUserID + "</auth:Profile>" );
            strInfoRequestBody.append("<auth:Password>" + strPwd + "</auth:Password>");
            strInfoRequestBody.append("</auth:AuthorizationHeader>");
            strInfoRequestBody.append("</soap:Header>");
            strInfoRequestBody.append("<soap:Body>");
            strInfoRequestBody.append("<eit:Info xmlns:eit=\"http://epnet.com/webservices/SearchService/2007/07/\"/></soap:Body></soap:Envelope>");
            //Pass to the method for the soap response
            xmlInfoResponse = postXMLTransaction(strInfoRequestBody.toString());
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return xmlInfoResponse;
    }
    /// <summary>
    /// This message will request a Search from the SOAP service.
    /// Send the SOAP message to the service.  The data returned from
    /// the send function is the entire SOAP message.  We just want to
    /// get the information inside
    /// </summary>
    /// <param name="parm">Parameter from the page to add in the soap header</param>
    /// <returns> String containg XML from webservices  response</returns>
    public String Search(String[] parm,String strUserID,String strPwd)
    {
        String xmlSearchoResponse = "";
        try
        {   
            //Get userid and password
            String numRec = "10";
            //Soap header for the Search 
            StringBuilder strSearchRequestBody = new StringBuilder();
            strSearchRequestBody.append("<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" soap:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" >");
            strSearchRequestBody.append("<soap:Header><auth:AuthorizationHeader soap:mustUnderstand=\"1\" xmlns:auth=\"http://epnet.com/webservices/SearchService/2007/07/\">");
            strSearchRequestBody.append("<auth:Profile>" + strUserID + "</auth:Profile>");
            strSearchRequestBody.append("<auth:Password>" + strPwd + "</auth:Password>");
            strSearchRequestBody.append("</auth:AuthorizationHeader></soap:Header>");
            strSearchRequestBody.append("<soap:Body><eit:Search xmlns:eit=\"http://epnet.com/webservices/SearchService/2007/07/\">");
            strSearchRequestBody.append("<eit:searchRequest><eit:Query>" +parm[0] + "</eit:Query>");
            strSearchRequestBody.append("<eit:Databases>" + parm[2] + "</eit:Databases>");
            strSearchRequestBody.append("<eit:StartingRecordNumber>" + parm[1] + "</eit:StartingRecordNumber>");
            strSearchRequestBody.append("<eit:NumberRecordsReturned>" + numRec + "</eit:NumberRecordsReturned>");
            strSearchRequestBody.append("<eit:Sort>" + parm[3] + "</eit:Sort>");
            strSearchRequestBody.append("</eit:searchRequest></eit:Search></soap:Body></soap:Envelope>");
            xmlSearchoResponse = postXMLTransaction(strSearchRequestBody.toString());
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return xmlSearchoResponse;
    }
    /// <summary>
    /// This message will request a Browse from the SOAP service.
    /// </summary>
    /// <param name="parm">Parameter from the page to add in the soap header</param>
    /// <returns>String containg XML from webservices  response</returns>
    public String Browse(String[] parm,String strUserID,String strPwd)
    {
        String xmlBrowseResponse="";
        try
        {
            StringBuilder strBrowseRequestBody =new StringBuilder();
            strBrowseRequestBody.append("<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" soap:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" >");
            strBrowseRequestBody.append("<soap:Header><auth:AuthorizationHeader soap:mustUnderstand=\"1\" xmlns:auth=\"http://epnet.com/webservices/SearchService/2007/07/\">");
            strBrowseRequestBody.append("<auth:Profile>"+strUserID+"</auth:Profile>");
            strBrowseRequestBody.append("<auth:Password>"+strPwd+"</auth:Password>");
            strBrowseRequestBody.append("</auth:AuthorizationHeader>");
            strBrowseRequestBody.append("</soap:Header>");
            strBrowseRequestBody.append("<soap:Body><eit:Browse xmlns:eit=\"http://epnet.com/webservices/SearchService/2007/07/\"><eit:browseRequest>");
            strBrowseRequestBody.append("<eit:Term>" + parm[1]+ "</eit:Term>");
            strBrowseRequestBody.append("<eit:Index>" + parm[0] + "</eit:Index>");
            strBrowseRequestBody.append("<eit:Databases>" + parm[2] + "</eit:Databases>");
            strBrowseRequestBody.append("</eit:browseRequest></eit:Browse></soap:Body></soap:Envelope>");
            xmlBrowseResponse=postXMLTransaction(strBrowseRequestBody.toString());
        }
        catch (Exception e)
        {   
        	e.printStackTrace();
        }
        return xmlBrowseResponse;
    }
    /// <summary>
    /// This function uses cURL to send data to the SOAP service.
    //  String $message The Soap message to be posted as the request
    /// </summary>
    /// <param name="strBody">Created soap header for the request</param>
    /// <returns>return Returns the response from web service</returns>
	public String postXMLTransaction(String strBody)
    {
        StringBuilder strResponse = new StringBuilder();
        String ou="";
        try
        {
        	URL iurl = new URL("http://eit.ebscohost.com/Services/SearchService.asmx");
    		HttpURLConnection uc = (HttpURLConnection)iurl.openConnection();
    		uc.setDoOutput(true);
    		uc.setRequestMethod("GET");
    		uc.setRequestProperty("Content-type", "application/soap+xml; charset=UTF-8");
    		OutputStream reqStream = uc.getOutputStream();
   		    reqStream.write(strBody.getBytes());
    		InputStream resStream = uc.getInputStream();
    		BufferedReader in = new BufferedReader(new InputStreamReader(resStream));
    		while ((ou = in.readLine()) != null)
    			   strResponse.append(ou);
		    in.close();
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
        return strResponse.toString();
    }
}

