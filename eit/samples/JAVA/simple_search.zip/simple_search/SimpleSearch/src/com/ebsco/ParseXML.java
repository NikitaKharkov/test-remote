package com.ebsco;

import java.util.*;
import org.w3c.dom.*;

public class ParseXML 
{
		public ArrayList<Map<String, String>> parseXML(Document doc,String selectedDB)
		{
			ArrayList<Map<String, String>> resultArrayList=new ArrayList<Map<String, String>>();
			Map<String, String> hashDataIndex=new LinkedHashMap<String, String>();		
			Map<String, String> hashDataTags=new LinkedHashMap<String, String>();	
			Map<String, String> hashDataSort=new LinkedHashMap<String, String>();	
			try 
			{	
				//Normalizing the document.
				doc.getDocumentElement().normalize();
				//Looping through the document with tagname db to get required Nodes.
				NodeList listOfNodes = doc.getElementsByTagName("db");
				for(int index=0; index<listOfNodes.getLength() ; index++)
				{
						Node firstNode = listOfNodes.item(index); 
						if(firstNode.getNodeType()== Node.ELEMENT_NODE)
						{
							//Checking the attribute value to check it shouldn't have any tag name as xsi:type.
								NamedNodeMap getAttrib = firstNode.getAttributes();
								Node checkNode = getAttrib.getNamedItem("xsi:type");
								if(!(checkNode!=null && checkNode.getNodeValue().equalsIgnoreCase("DatabaseWithAuth")))
								{
									if(getAttrib.getNamedItem("shortName").getNodeValue().equalsIgnoreCase(selectedDB))//DB from request
									{
										//If database match found then get the ChildNodes of that.
										NodeList xmlNodeList=firstNode.getChildNodes();
										for(int dbIndex=0;dbIndex<xmlNodeList.getLength();dbIndex++)
										{
											Node dbChildNodes=xmlNodeList.item(dbIndex);
											//Get Nodes by name dbIndices ,get its children and save the value in a map
											if(dbChildNodes.getNodeName().equals("dbIndices"))
											{
												NodeList dbIndexChildList=dbChildNodes.getChildNodes();
								                for (int x = 0; x < dbIndexChildList.getLength(); x++)
								                {
													Node dbIndexChildItemNode=dbIndexChildList.item(x);
								                   	 if(dbIndexChildItemNode.getNodeType() == Node.ELEMENT_NODE)
								    	                 {
								                    		NamedNodeMap getAttrib1 = dbIndexChildItemNode.getAttributes();
							                        		hashDataIndex.put(getAttrib1.getNamedItem("name").getNodeValue(), getAttrib1.getNamedItem("description").getNodeValue());
							           			         }      
								                }
											}
											//Get Nodes by name dbTags ,get its children and save the value in a map
											else if(dbChildNodes.getNodeName().equals("dbTags"))
											{
												NodeList dbIndexChildList=dbChildNodes.getChildNodes();
								                for (int x = 0; x < dbIndexChildList.getLength(); x++)
								                {
													Node dbIndexChildItemNode=dbIndexChildList.item(x);
								                   	 if(dbIndexChildItemNode.getNodeType() == Node.ELEMENT_NODE)
								    	                 {
								                    		NamedNodeMap getAttrib1 = dbIndexChildItemNode.getAttributes();
							                        		hashDataTags.put(getAttrib1.getNamedItem("name").getNodeValue(), getAttrib1.getNamedItem("description").getNodeValue());
							           			         }      
								                }
											}
											//Get Nodes by name sortOptions ,get its children and save the value in a map
											else if(dbChildNodes.getNodeName().equals("sortOptions"))
											{
												NodeList dbIndexChildList=dbChildNodes.getChildNodes();
								                for (int x = 0; x < dbIndexChildList.getLength(); x++)
								                {
													Node dbIndexChildItemNode=dbIndexChildList.item(x);
								                   	 if(dbIndexChildItemNode.getNodeType() == Node.ELEMENT_NODE)
								    	                 {
								                    		NamedNodeMap getAttrib1 = dbIndexChildItemNode.getAttributes();
							                        		hashDataSort.put(getAttrib1.getNamedItem("id").getNodeValue(), getAttrib1.getNamedItem("name").getNodeValue());
							           			         }      
								                }
											}
										}
								}
						}
					}	
				}
			}
			catch (Exception e) 
			{
				e.printStackTrace ();
			}
			//Adding the map in an ArrayList and returning it back.
			resultArrayList.add(hashDataIndex);
			resultArrayList.add(hashDataSort);
			resultArrayList.add(hashDataTags);
			return resultArrayList;
		}
}
