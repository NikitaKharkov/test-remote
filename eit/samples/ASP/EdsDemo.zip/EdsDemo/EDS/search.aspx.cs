﻿#region System namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Net;
using System.Text;
using System.Xml.Xsl;
using System.Web.Configuration;

#endregion

#region Page namespaces
namespace EDS
{
    /// <summary>
    /// This class shows the data get by the parameters pass by the INDEX page as a querystring
    /// It creates the query to pass in webservice and get the response and create the xml to pass in the XSL to create the page
    /// </summary>
    public partial class search : System.Web.UI.Page
    {
        #region Variable and object
        long start;
        string queryToPass = "";
        string queryToDisplay = "";
        string query = "";
        string sort = "";
        string queryDisp = "";
        string xml_vars = "";
        string queryAdv = "";
        #endregion

        #region Method
        /// <summary>
        /// Page load is get excecuted at the starting of the page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string queryValue = "";
            //For search parameter
            XmlDocument xmlDocument = new XmlDocument();
            //For GetClusters parameter
            XmlDocument xmlClustered = new XmlDocument();
            try
            {
                //To create the query to pass
                queryValue = GetAllQueryItem();
                //Return XML document by keyword search
                xmlDocument = GetResponseData("Search", queryValue);
                //Return XML document by keyword GetClusters
                xmlClustered = GetResponseData("GetClusters", queryValue);
                //Create controls and XML document to pass in XSL for display
                CreatControls(xmlDocument, xmlClustered);
            }
            catch (Exception)
            {
                //To DO
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// This method create control and append the required nodes to the xml file as string and
        /// pass to the XSL to create the Page according to the XML node pass
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="xmlClustered"></param>
        private void CreatControls(XmlDocument xmlDocument, XmlDocument xmlClustered)
        {
            long hits = 0;
            try
            {
                //To find the number of hits
                XmlNodeList xmlCountNode = xmlDocument.GetElementsByTagName("Hits");
                if (xmlDocument.ChildNodes.Count > 0)
                {
                    foreach (XmlNode xmlNode in xmlCountNode)
                    {
                        hits = hits + Convert.ToInt64(xmlNode.InnerText);
                    }
                }
                // Get the RecordCount for this page.  This represents the number of
                // records returned on this page.
                XmlNodeList XMLrecords = xmlDocument.GetElementsByTagName("rec");
                long RecordCount = 0;
                RecordCount = XMLrecords.Count;

                // Next Page record number and Previous Page record number
                long NextPageStart = start + 10;
                long PrevPageStart = start - 10;


                // Begin: generate wrapper XML that will be used by to build the search results web page
                // search.xsl, located in the same directory as search.php, will translate this XML into HTML
                StringBuilder xmlText = new StringBuilder();
                xmlText.Append("<?xml version='1.0' encoding='UTF-8'?>\n");
                xmlText.Append("<?xml-stylesheet type=\"text/xsl\" href='search.xsl'?>\n");
                xmlText.Append("<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n");
                xmlText.Append("<wrapper>\n");
                xmlText.Append("<query_req>" + query + "</query_req>\n");
                xmlText.Append("<query_adv>" + queryAdv + "</query_adv>\n");
                xmlText.Append("<query>" + queryToDisplay + "</query>\n");
                xmlText.Append("<prevpage>" + PrevPageStart + "</prevpage>\n");
                xmlText.Append("<hits>" + hits + "</hits>\n");
                //if not hits found then specify noresults as true with value 1 or if found set to false with value 0
                if (hits == 0)
                {
                    xmlText.Append("<noresults>1</noresults>");
                }
                else
                {
                    xmlText.Append("<noresults>0</noresults>");
                }
                //if number of records is greater than 10 specify the start of next page    
                if ((RecordCount) < 10)
                {
                    xmlText.Append("<nextpage>0</nextpage>\n");
                }
                else
                {
                    xmlText.Append("<nextpage>" + NextPageStart + "</nextpage>\n");
                }
                //specify total count of records found
                xmlText.Append("<totalrecs>" + RecordCount + "</totalrecs>\n");
                //specify start for the current page
                xmlText.Append("<thispage>" + start + "</thispage>\n");
                string pageNo = "";
                if (Convert.ToString(Request.QueryString["page"]) == null) { pageNo = "1"; } else { pageNo = Convert.ToString(Request.QueryString["page"]); }

                xmlText.Append("<page>" + pageNo + "</page>\n");
                xmlText.Append("<sort>" + sort + "</sort>\n");

                // Output the variables for the XSL stylesheet.
                xmlText.Append(xml_vars);

                string strReplace = xmlDocument.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");
                // Output the results from the Search.
                xmlText.Append(strReplace);

                string strCluster = xmlClustered.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");

                // Output the results from the Search.
                xmlText.Append(strCluster);
                xmlText.Append("</wrapper>\n");

                //XmlDocuments to pass in xsl for the page creation
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlText.ToString());
                //Path for the XSL
                string xslPath = Server.MapPath("~//App_Data/search.xsl");
                XslCompiledTransform transform = new XslCompiledTransform();
                transform.Load(xslPath);
                transform.Transform(doc, null, Response.Output);
            }
            catch (Exception)
            {
                //To DO
            }
        }
        /// <summary>
        /// Method to get response from the webservice as a form of XML documents
        /// as per the the query and type
        /// </summary>
        /// <param name="type"> Type of request</param>
        /// <param name="queryValue"> query to pass in webservice </param>
        /// <returns></returns>
        private XmlDocument GetResponseData(string type, string queryValue)
        {
            XmlDocument XMLDoc = null;
            try
            {
                //User id and password ofthe webservice
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);
                string EITServiceURL = "";
                //Foemation of the URL as per request
                if (type.Equals("Search"))
                {
                    EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + type + "?prof=" + strUserID + "&pwd=" + strPwd + "&query=" + query + "&sort=" + sort + "&startrec=" + start + "&numrec=10";
                }
                else if (type.Equals("GetClusters"))
                {
                    EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + type + "?prof=" + strUserID + "&pwd=" + strPwd + "&query=" + query;
                }
                //Declare XMLResponse document

                //Declare an HTTP-specific implementation of the WebRequest class.
                HttpWebRequest objHttpWebRequest;

                //Declare XMLReader
                XmlTextReader xmlTextReader;
                objHttpWebRequest = (HttpWebRequest)WebRequest.Create(EITServiceURL);
                HttpWebResponse response = (HttpWebResponse)objHttpWebRequest.GetResponse();
                //----------------Start HttpResponse--------------------------------//
                //Load response stream into XMLReader
                xmlTextReader = new XmlTextReader(response.GetResponseStream());
                //Declare XMLDocument
                XMLDoc = new XmlDocument();
                XMLDoc.Load(xmlTextReader);
            }
            catch (Exception)
            {
                //To DO
            }
            return XMLDoc;
        }
        /// <summary>
        /// Method create the query as per the parameters pass from the INDEX page
        /// </summary>
        /// <returns></returns>
        private string GetAllQueryItem()
        {

            try
            {
                sort = Request.QueryString["sort"];
                query = Request.QueryString["query"];
                string full_text = Request.QueryString["ft"];
                string scholarly = Request.QueryString["sch"];
                string j_name = Request.QueryString["journal_name"];
                string from_year = Request.QueryString["from_year"];
                string from_month = Request.QueryString["from_month"];
                string to_year = Request.QueryString["to_year"];
                string to_month = Request.QueryString["to_month"];
                string pubtype = Request.QueryString["pubtype"];
                string searchfield = Convert.ToString(Request.QueryString["searchfield"]);
                string j_author = Convert.ToString(Request.QueryString["journal_author"]);
                string j_title = Convert.ToString(Request.QueryString["journal_title"]);

                string s1 = Request.QueryString["s1"];
                string t1 = Request.QueryString["t1"];
                string d1 = Request.QueryString["d1"];
                string s2 = Request.QueryString["s2"];
                string t2 = Request.QueryString["t2"];
                string d2 = Request.QueryString["d2"];
                string s3 = Request.QueryString["s3"];
                string t3 = Request.QueryString["t3"];

                // Initialize the starting position of the records in the XML returned from the web services API.
                // If the starting position parameter doesn't exist, set it to 1
                if (Request.QueryString["start"] == null)
                {
                    start = 1;
                }
                else
                {
                    start = Convert.ToInt64(Convert.ToString(Request.QueryString["start"]));
                }
                if (searchfield != "keyword")
                {
                    if (searchfield == "author")
                    {
                        s1 = query;
                        t1 = "AU";
                        query = "";
                    }
                    else if (searchfield == "title")
                    {
                        s1 = query;
                        t1 = "TI";
                        query = "";
                    }
                }
                // Format the Query using the limiters above.
                if (query != "")
                {  
                    // Format the Query using the limiters above.
                    queryToPass = query;
                    queryToDisplay = query;
                    // Remove preceding and trailing blank space
                    query = query.Trim();

                    // Encode any blank spaces within the query string.  Should be done as a best practice.  
                    query = query.Replace(" ", "+");

                    // Initialize limiter variable.  xml_vars holds the limiters which will be passed to
                    // the XSLT stylesheet via XML

                    // Add left and right parenthesis around the query string.  This will ensure the search criteria is
                    // properly bounded in the query string
                    if (query[0] != '(')
                    {
                        query = '(' + query;
                    }

                    // Once the search criteria is added to the query string, append any limiters that were selected via the UI
                    // to the query string.  
                    if (query[Convert.ToInt16(((Convert.ToInt16(query.Length)) - 1))] != ')')
                        query += ")";

                    // User has indicated, via the Search Options screen, that the search must include 
                    // articles containing Full Text
                    if (full_text != null && !full_text.Equals(""))
                    {
                        // append to the query, the FT field code and set to a value of Y
                        query += "+AND+(FT+Y)";
                        xml_vars += "<ft ft=\"on\" />\n";
                    }

                    // User has indicated, via the Search Options screen, that the search must include 
                    // Scholarly (Peer Reviewed) Journals
                    if (scholarly != null && !scholarly.Equals(""))
                    {
                        // append to the query, the RV field code and set to a value of Y
                        query += "+AND+(RV+Y)";
                        xml_vars += "<sch sch=\"on\" />\n";
                    }


                    // User has specified a Journal Name via the Search Options screen
                    if (j_name != null && !j_name.Equals(""))
                    {
                        // encode any blank spaces within the query string with + signs
                        j_name = j_name.Replace(" ", "+");
                        // preface journal name with the SO field code.  this will greatly help narrow the scope of the search
                        query += ("+AND+(SO+" + j_name + ")");
                        xml_vars += "<jname>" + j_name + "</jname>\n";
                    }
                    // User has specified an article title via the Search Options screen
                    if (j_title != null && !j_title.Equals(""))
                    {
                        // encode any blank spaces within the query string with + signs
                        j_title = j_title.Replace(" ", "+");
                        // preface article title with the TI field code.  this will greatly help narrow the scope of the search
                        query += "+AND+(TI+" + j_title + ")";
                        xml_vars += "<jtitle>" + j_title + "</jtitle>\n";
                    }

                    // User has specified an author's name via the Search Options screen
                    if (j_author != null && !j_author.Equals(""))
                    {
                        // encode any blank spaces within the query string with + signs
                        j_author = j_author.Replace(" ", "+");
                        // preface article title with the TI field code.  this will greatly help narrow the scope of the search
                        query += "+AND+(AU+" + j_author + ")";
                        xml_vars += "<jauthor>" + j_author + "</jauthor>\n";
                    }
                    if (pubtype == "all")
                    {
                        xml_vars += "<pubtype>all</pubtype>\n";
                    }
                    else if (pubtype == "books")
                    {
                        xml_vars += "<pubtype>books</pubtype>\n";
                        query += "+AND+(PT+book)";
                    }
                    else if (pubtype == "articles")
                    {
                        xml_vars += "<pubtype>articles</pubtype>\n";
                        query += "+AND+(ZT+article)";
                    }

                    // User has chosen to specify From and/or To dates to narrow the scope of the search.  
                    if (!from_year.Equals("") || !to_year.Equals(""))
                    {
                        // preface From and/or To date with DT field code
                        query += "+AND+(DT+";

                        if (from_year != null && !from_year.Equals(""))
                        {
                            // append From date to query string
                            query += from_year + from_month;
                            xml_vars += "<from_year>" + from_year + "</from_year>\n";
                            xml_vars += "<from_month>" + from_month + "</from_month>\n";
                        }
                        query += '-';
                        if (to_year != null && !to_year.Equals(""))
                        {
                            // append To date to query string
                            query += to_year + to_month;
                            xml_vars += "<to_year>" + to_year + "</to_year>\n";
                            xml_vars += "<to_month>" + to_month + "</to_month>\n";
                        }
                        // close the date parenthesis in order to properly bound the date parameters
                        query += ")";
                    }
                }
                if (s1 != null)
                {
                    xml_vars += "<s1>" + s1.ToString() + "</s1>\n";
                }
                if (t1 != null)
                {
                    xml_vars += "<t1>" + t1.ToString() + "</t1>\n";
                }
                if (d1 != null)
                {
                    xml_vars += "<d1>" + d1.ToString() + "</d1>\n";
                }
                if (s2 != null)
                {
                    xml_vars += "<s2>" + s2.ToString() + "</s2>\n";
                }
                if (t2 != null)
                {
                    xml_vars += "<t2>" + t2.ToString() + "</t2>\n";
                }
                if (d2 != null)
                {
                    xml_vars += "<d2>" + d2.ToString() + "</d2>\n";
                }
                if (s3 != null)
                {
                    xml_vars += "<s3>" + s3.ToString() + "</s3>\n";
                }
                if (t3 != null)
                {
                    xml_vars += "<t3>" + t3.ToString() + "</t3>\n";
                }
                //Replacing some charactor
                s1 = s1.Replace(" ", "+");
                s1 = (s1 != null && !s1.Equals("")) ? ("(" + t1 + (t1 != "" ? "+(" : "") + s1 + ")" + (t1 != "" ? ")" : "")) : null;
                s2 = s2.Replace(" ", "+");
                s2 = (s2 != null && !s2.Equals("")) ? ("(" + t2 + (t2 != "" ? "+(" : "") + s2 + ")" + (t2 != "" ? ")" : "")) : null;
                s3 = s3.Replace(" ", "+");
                s3 = (s3 != null && !s3.Equals("")) ? ("(" + t3 + (t3 != "" ? "+(" : "") + s3 + ")" + (t3 != "" ? ")" : "")) : null;
                if (Request.QueryString["advset"] == "")
                {
                    //queryAdv = s1 + ((s2 != "") ? ("+" + d1 + "+") : null) + s2 + ((s3 != "") ? ("+" + d2 + "+") : null) + s3;
                    if (s1 != null)
                    {
                        queryAdv += s1;
                    }
                    if (s2 != null && queryAdv != "")
                    {
                        queryAdv += '+' + d1 + '+' + s2;
                    }
                    else
                    {
                        queryAdv += s2;
                    }
                    if (s3 != null && queryAdv != "")
                    {
                        queryAdv += '+' + d2 + '+' + s3;
                    }
                    else
                    {
                        queryAdv += s3;
                    }
                }
                if (query != "" && s1 != "" && s2 != "" && s3 != "")
                {
                    //die(header("Location: index.php"));
                }
                if (query != "")
                {
                    if (queryAdv != "")
                    {
                        query += "+AND+" + queryAdv;
                    }
                }
                else if (queryAdv != "" && query == "")
                {
                    query = queryAdv;
                    queryToPass = queryAdv;
                }
                else
                {
                    // die(header("Location: index.php"));
                }
                int rtbrac = query.Count(f => f == '(');
                int lfbrac = query.Count(f => f == ')'); 
                if (lfbrac > rtbrac)
                {
                    query = query.Substring(0, Convert.ToInt16(query.Length) - 1);
                }
            }
            catch (Exception)
            {
                //To DO
            }
            queryToDisplay = query;
            return query;
        }
        #endregion
    }
}
#endregion