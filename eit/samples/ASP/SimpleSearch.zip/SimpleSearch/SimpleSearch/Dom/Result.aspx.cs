﻿
#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using SimpleSearch.TypeSearch.dom;
using System.Xml;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from the Querystring
    /// <summary>
    // Class created for taking input from the URL 
    // and show the data as per the response.
    /// </summary>
    public partial class Result : System.Web.UI.Page
    {
        #region Variable and object
        private long resultCount = 0;
        private string start = "";
        private string link="";
        long topResult ;
        string query = "";

        DataService xmlDoc;
        private StringBuilder pageControls = new StringBuilder();
        #endregion
        #region Event
        /// <summary>
        /// Load event is exceuted to create and show the requested 
        /// Data 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    //Check the value of Database else redirect
                    if (Request.QueryString["db"] != "")
                    {
                        linkHp.PostBackUrl = "~/Dom/Search.aspx?db=" + Convert.ToString(Request.QueryString["db"]);
                        //Check other value else redirect
                        if (Convert.ToString(Request.QueryString["s1"]) != "" || Convert.ToString(Request.QueryString["s2"]) != "" || Convert.ToString(Request.QueryString["s3"]) != "" || Convert.ToString(Request.QueryString["s4"]) != "")
                        {
                            //Initiallization of class
                            xmlDoc = new DataService();
                            //Passing the webservice URL
                            xmlDoc.Connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
                            string[] parm = Getparameter();
                            // Request Database Information through Search Method
                            var xmlData = xmlDoc.PostXMLTransaction("Search", parm);
                            //Display the result which is return from the webservice
                            DisplayResult(xmlData);
                        }
                        else
                        {
                            Response.Redirect("Search.aspx?db=" + Convert.ToString(Request.QueryString["db"]));
                        }
                    }
                    else
                    {
                        Response.Redirect("Search.aspx?db=" + Convert.ToString(Request.QueryString["db"]));
                    }
                }
                catch (Exception)
                {
                    //Redirecting the page if error occured
                    //To DO  
                }
            }
        }
        /// <summary>
        /// Reload the page with new patameters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtSearch.Text.Trim() != "")
                {
                    Response.Redirect("Result.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&s1=" + txtSearch.Text.ToString() + "&t1=" + Convert.ToString(Request.QueryString["t1"]) + "&d1=" + Convert.ToString(Request.QueryString["d1"]) + "&s2=" + Convert.ToString(Request.QueryString["s2"]) + "&t2=" + Convert.ToString(Request.QueryString["t2"]) + "&d2=" + Convert.ToString(Request.QueryString["d2"]) + "&s3=" + Convert.ToString(Request.QueryString["s3"]) + "&t3=" + Convert.ToString(Request.QueryString["t3"]) + "&d3=" + Convert.ToString(Request.QueryString["d3"]) + "&s4=" + Convert.ToString(Request.QueryString["s4"]) + "&t4=" + Convert.ToString(Request.QueryString["t4"]) + "&sort=" + Convert.ToString(Request.QueryString["sort"]) + "&ft=" + Convert.ToString(Request.QueryString["ft"]));
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        #endregion
        #region Method
        /// <summary>
        /// Display the result after several formation of tag by parsing the nodelist
        /// </summary>
        /// <param name="xmlData">Parameter containing XMLdocuments</param>
        private void DisplayResult(XmlDocument xmlData)
        {
            StringBuilder sbTable = new StringBuilder();
            String checkSubject = "";
            try
            {  
                if (xmlData.ChildNodes.Count > 0)
                {
                    // Returns the number of search hits by tag name Statistics
                    XmlNodeList xmlCountNode = xmlData.GetElementsByTagName("Statistics");
                    foreach (XmlNode xmlNode in xmlCountNode)
                    {
                        foreach (XmlNode xmlChildNode in xmlNode.ChildNodes)
                        {
                            for (int k = 0; k < xmlChildNode.ChildNodes.Count; k++)
                            {
                                if (xmlChildNode.ChildNodes.Item(k).Name.Equals("Hits"))
                                {
                                    resultCount = Convert.ToInt64(xmlChildNode.ChildNodes.Item(k).InnerText);
                                }
                            }
                        }
                    }
                    //Create control to display on page for show up the data
                    CreateControl(resultCount);
                    //Creating dynamic table for diaplay
                    sbTable.Append(" <table  border='0' width='700px'><tr class='title' style='text-align: center;'>");
                    sbTable.Append("<th class='search_result'><h3>Search Results for: " + query + "</h3> Results " + start + " - " + topResult + " of " + resultCount + " Total Results<br>" + pageControls + "</th></tr>");
                    //Getting all node by using GetElementsByTagName rec
                    XmlNodeList xnList = xmlData.GetElementsByTagName("rec");
                    //looping all nodes for the header
                    foreach (XmlNode xmlItem in xnList)
                    {
                        StringBuilder inerString = new StringBuilder();
                        inerString.Append("<tr ><td><font style='font-weight: bold;'><a href='");
                        for (int i = 0; i < xmlItem.ChildNodes.Count; i++)
                        {
                            if (xmlItem.ChildNodes.Item(i).Name.Equals("header"))
                            {
                                inerString.Append(GetElement(xmlItem.ChildNodes.Item(i), "atl") + "</a></font><br><i>");
                                inerString.Append("By: " + GetElement(xmlItem.ChildNodes.Item(i), "au"));
                                inerString.Append(GetElement(xmlItem.ChildNodes.Item(i), "jtl")+", ");
                                inerString.Append(GetElement(xmlItem.ChildNodes.Item(i), "dt")+ "</i>");
                                checkSubject =GetElement(xmlItem.ChildNodes.Item(i), "su");
                                if (checkSubject != "")
                                {
                                    inerString.Append("<br><br>Subject:<br>");
                                    inerString.Append(checkSubject);
                                }
                                inerString.Append("<br><br></td></tr>");
                            }
                            else if (xmlItem.ChildNodes.Item(i).Name.Equals("plink"))
                            {
                                inerString.Append(GetElement(xmlItem.ChildNodes.Item(i), "plink") + "'>");
                            }
                        }
                        sbTable.Append(inerString);
                    }
                    sbTable.Append("<tr><td class='search_result' colspan='2' style='text-align:center;'> Results" + start + " - " + topResult + " of " + resultCount + " Total Results<br>" + pageControls + "</td></tr>");
                }
                
                //Closing the table
                sbTable.Append("</table>");
                //Binding the created table to div
                divTable.InnerHtml = Convert.ToString(sbTable); 
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
        }
        /// <summary>
        /// Building and creating the next and previous controls to show on the
        /// page for the navigation
        /// </summary>
        /// <param name="hits"></param>
        /// <returns></returns>
        private StringBuilder CreateControl(long hits)
        {
            long sCount = Convert.ToInt64(start);
            topResult = sCount + 9;
            try
            {
                if (topResult > hits || (hits < 10))
                {
                    topResult = hits;
                }
                if (sCount > 1)
                {
                    pageControls.Append(" <a href='" + link + " &start=" + (sCount - 10) + "'>Prev</a> ");
                }
                else
                {
                    pageControls.Append(" Prev ");
                }
                pageControls.Append( " | ");

                if (sCount < (hits - 9))
                {
                    pageControls.Append(" <a href='" + link + "&start=" + (sCount + 10) + "'>Next</a> ");
                }
                else
                {
                    pageControls.Append(" Next ");
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }

            return pageControls; 
        }
        /// <summary>
        /// Looping to get all the required data node
        /// </summary>
        /// <param name="xmlItem">passing the XMLItems for the XMLList</param>
        /// <param name="type">The type of node</param>
        /// <returns></returns>
        private string  GetElement(XmlNode xmlItem, string type)
        {
           
            StringBuilder sbBuilder=new StringBuilder();
            string strResult = "";
            try
            {
                foreach (XmlNode xmlClildItem in xmlItem)
                {
                    if (!type.Equals("plink"))
                    {
                          foreach (XmlNode childItem in xmlClildItem.ChildNodes)
                            {
                                if (childItem.Name.Equals("jinfo") && type.Equals("jtl"))
                                {
                                    for (int j = 0; j < childItem.ChildNodes.Count; j++)
                                    {
                                        if (childItem.ChildNodes.Item(j).Name.Equals(type))
                                        {
                                           sbBuilder.Append(childItem.ChildNodes[j].InnerText);
                                        }
                                    }
                                    return strResult = Convert.ToString(sbBuilder);
                                }
                                else if (childItem.Name.Equals("pubinfo") && type.Equals("dt"))
                                {
                                    for (int j = 0; j < childItem.ChildNodes.Count; j++)
                                    {
                                        if (childItem.ChildNodes.Item(j).Name.Equals(type))
                                        {
                                            sbBuilder.Append(childItem.ChildNodes[j].InnerText+".");
                                        }
                                    }
                                    return strResult = Convert.ToString(sbBuilder);
                                    
                                }
                                else if (childItem.Name.Equals("artinfo"))
                                {
                                    for (int i = 0; i < childItem.ChildNodes.Count; i++)
                                    {
                                        if (childItem.ChildNodes.Item(i).Name.Equals("aug") && type.Equals("au"))
                                        {
                                            for (int j = 0; j < childItem.ChildNodes.Item(i).ChildNodes.Count; j++)
                                            {
                                                sbBuilder=sbBuilder.Append(childItem.ChildNodes.Item(i).ChildNodes[j].InnerText+"; ");
                                            }
                                            return strResult = Convert.ToString(sbBuilder);
                                        }
                                        else if (childItem.ChildNodes.Item(i).Name.Equals("tig") && type.Equals("atl"))
                                        {
                                            for (int j = 0; j < childItem.ChildNodes.Item(i).ChildNodes.Count; j++)
                                            {
                                                sbBuilder = sbBuilder.Append(childItem.ChildNodes.Item(i).ChildNodes[j].InnerText);
                                            }
                                            return strResult = Convert.ToString(sbBuilder);
                                           
                                        }
                                        else if (childItem.ChildNodes.Item(i).Name.Equals("su") && type.Equals("su"))
                                        {
                                             sbBuilder = sbBuilder.Append(childItem.ChildNodes.Item(i).InnerText+",");
                                        }
                                    }
                                }
                            }
                    }
                    else if (type.Equals("plink"))
                    {
                        sbBuilder.Append(xmlItem.ChildNodes[0].InnerText);
                        return strResult = Convert.ToString(sbBuilder);
                    }
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
            return strResult = Convert.ToString(sbBuilder);
        }
        /// <summary>
        /// Crinting the url and all other parameter to pass in the page
        /// or to us for navigation througt the pages.
        /// </summary>
        /// <returns> return string </returns>
        private string[] Getparameter()
        {
            string[] parms = null;
            try
            {
                // Search Terms for TEXTBOX
                string s1 = Convert.ToString(Request.QueryString["s1"]);
                string s2 = Convert.ToString(Request.QueryString["s2"]);
                string s3 = Convert.ToString(Request.QueryString["s3"]);
                string s4 = Convert.ToString(Request.QueryString["s4"]);
                // Search Terms for DROPDOWN    
                string d1 = Convert.ToString(Request.QueryString["d1"]);
                string d2 = Convert.ToString(Request.QueryString["d2"]);
                string d3 = Convert.ToString(Request.QueryString["d3"]);
                // Search Terms for condition DROPDOWN   
                string t1 = Convert.ToString(Request.QueryString["t1"]);
                string t2 = Convert.ToString(Request.QueryString["t2"]);
                string t3 = Convert.ToString(Request.QueryString["t3"]);
                string t4 = Convert.ToString(Request.QueryString["t4"]);
                // Other controls
                string db = Convert.ToString(Request.QueryString["db"]);
                string sort = Convert.ToString(Request.QueryString["sort"]);
                start = (Convert.ToString(Request.QueryString["start"]) != null) ? (Convert.ToString(Request.QueryString["start"])) : "1";
                string ft = (Convert.ToString(Request.QueryString["ft"]) != "0") ? "true" : "false";
                // No search terms, go back to select DB
                if (s1 != null && s2 != null && s3 != null && s4 != null || db != null)
                {
                    // The link for 'next' and 'previous' pages
                    link = "Result.aspx?db=" + db + "&sort=" + sort + "&s1=" + s1 + "&s2=" + s2 + "&s3=" + s3 + "&s4=" + s4 + "&t1=" + t1 + "&t2=" + t2 + "&t3=" + t3 + "&t4=" + t4 + "&d1=" + d1 + "&d2=" + d2 + "&d3=" + d3 + "&ft=" + ft;
                    // Query Build Algorithm
                    //if the term to be searched is not null check for the Tag of the catergory else keep it null
                    if (!s1.Equals(null) && !s1.Equals(""))
                    {
                        s1 = s1.Replace(" ", "+");
                        s1 = (s1 != null && !s1.Equals("")) ? ("(" + t1 + (t1 != "" ? "+(" : "") + s1 + ")" + (t1 != "" ? ")" : "")) : null;
                    }
                    if (!s2.Equals(null) && !s2.Equals(""))
                    {
                        s2 = s2.Replace(" ", "+");
                        s2 = (s2 != null && !s2.Equals("")) ? ("(" + t2 + (t2 != "" ? "+(" : "") + s2 + ")" + (t2 != "" ? ")" : "")) : null;
                    }
                    if (!s3.Equals(null) && !s3.Equals(""))
                    {
                        s3 = s3.Replace(" ", "+");
                        s3 = (s3 != null && !s3.Equals("")) ? ("(" + t3 + (t3 != "" ? "+(" : "") + s3 + ")" + (t3 != "" ? ")" : "")) : null;
                    }
                    if (!s4.Equals(null) && !s4.Equals(""))
                    {
                        s4 = s4.Replace(" ", "+");
                        s4 = (s4 != null && !s4.Equals("")) ? ("(" + t4 + (t4 != "" ? "+(" : "") + s4 + ")" + (t4 != "" ? ")" : "")) : null;
                    }
                    //if trem to be searched is not null append database name
                    query = s1 + ((s2 != "") ? ("+" + d1 + "+") : null) + s2 + ((s3 != "") ? ("+" + d2 + "+") : null) + s3 + ((s4 != "") ? ("+" + d3 + "+") : null) + s4;
                    //format query with brackets and check for full text display     
                    query = query.Replace(")(", ")+AND+(");
                    if (!(query.Contains(@"/\+AND\+FT\+Y/")) && ft == "true")
                    {
                        query += "+AND+FT+Y";
                    }
                    parms = new string[] { query, start, Convert.ToString(Request.QueryString["db"]), sort };
                }
                else
                {
                    //Redirecting the page if error occured
                    //To DO
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
            return parms;
        }

        #endregion

       
    }
    #endregion
}
#endregion