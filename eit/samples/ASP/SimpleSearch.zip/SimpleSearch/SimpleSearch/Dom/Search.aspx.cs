﻿
#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.dom;
using System.Xml;
using System.Collections;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input and displaying data
    /// <summary>
    // Class created for taking input from querystring
    // and displaying data
    /// </summary>
    public partial class search : System.Web.UI.Page
    {
        #region Variable and object
        DataService xmlDoc;
        #endregion
        #region Event
        /// <summary>
        /// Load event is exceuted to create and show the requested 
        /// Data 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //Initiallization of class
                xmlDoc = new DataService();
                //Passing the webservice URL
                xmlDoc.Connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
                // Request Database Information through Info Method
                var xmlData = xmlDoc.PostXMLTransaction("Info", null);
                //Checking for the db tag
                FillDatabase(xmlData);
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
        }
        protected void drpDatabase_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpDatabase.SelectedIndex != -1)
            {
               Response.Redirect("~/Dom/Search.aspx?db=" + drpDatabase.SelectedValue);
            }
        }
        /// <summary>
        /// Fill all the controls as per the database selected
        /// </summary>
        private void FillDatabase(XmlDocument xmlData)
        {
            if (!IsPostBack)
            {
                drpDatabase.Items.Clear();
                drpDatabase.Items.Add("Select Database");
                drpFind.Items.Add(new ListItem("Select a Field (optional)", ""));
                drpFirst.Items.Add(new ListItem("Select a Field (optional)", ""));
                ConditionsFill();
                if (xmlData.ChildNodes.Count > 0)
                {
                    XmlNodeList xnList = xmlData.GetElementsByTagName("db");
                    for (int i = 0; i < xnList.Count; i++)
                    {
                        if (xnList[i].Attributes["xsi:type"] == null)
                        {
                            drpDatabase.Items.Add(new ListItem(xnList[i].Attributes["longName"].Value, xnList[i].Attributes["shortName"].Value));
                        }
                    }
                    
                }
                if (Request.QueryString["db"] != null)
                {
                    GetAllValue(xmlData);
                }
            }
        }
        private void GetAllValue(XmlDocument xmlData)
        {
            try
            {
              drpDatabase.SelectedValue = Convert.ToString(Request.QueryString["db"]);
                if (xmlData.ChildNodes.Count > 0)
                    {
                        //Geting all the element by tag name
                        XmlNodeList xnList = xmlData.GetElementsByTagName("db");
                        int i = 0;
                        foreach (XmlNode xmlNode in xnList)
                        {
                            //Checking for the Attributes 
                            if (xmlNode.Attributes["shortName"] != null)
                            {
                                //Checking for the db tag
                                if (xmlNode.Attributes["shortName"].Value == Convert.ToString(Request.QueryString["db"]))
                                {
                                    dbName.Text = xnList[i].Attributes["longName"].Value;
                                    //Checking for the Attributes 
                                    foreach (XmlNode subNode in xmlNode)
                                    {
                                        //Checking for the dbIndices tag
                                        if (subNode.Name.Equals("dbIndices"))
                                        {
                                            foreach (XmlNode childNode in subNode.ChildNodes)
                                            {
                                                drIndex.Items.Add(new ListItem(childNode.Attributes["description"].Value, childNode.Attributes["name"].Value));
                                            }
                                        }
                                        //Checking for the dbTags tag
                                        if (subNode.Name.Equals("dbTags"))
                                        {
                                            //Binding the dropdown to show data from XML file
                                            
                                            foreach (XmlNode childNode in subNode.ChildNodes)
                                            {
                                                drpFind.Items.Add(new ListItem(childNode.Attributes["description"].Value, childNode.Attributes["name"].Value));
                                                drpFirst.Items.Add(new ListItem(childNode.Attributes["description"].Value, childNode.Attributes["name"].Value));
                                                drpSecond.Items.Add(new ListItem(childNode.Attributes["description"].Value, childNode.Attributes["name"].Value));
                                                drpThird.Items.Add(new ListItem(childNode.Attributes["description"].Value, childNode.Attributes["name"].Value));
                                            }
                                        }
                                        //Checking for the sortOptions tag
                                        if (subNode.Name.Equals("sortOptions"))
                                        {
                                            foreach (XmlNode childNode in subNode.ChildNodes)
                                            {
                                                drpDateSort.Items.Add(new ListItem(childNode.Attributes["name"].Value, childNode.Attributes["id"].Value));
                                            }
                                        }
                                    }

                                }
                            }
                            i++;
                        }
                        //Filling the dropdown on the pages
                        ConditionsFill();
                    }
            }
            catch (Exception)
            {
                //To do
            }
        }

        /// <summary>
        /// Event call to handle the click button of browse.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                if (Request.QueryString["db"] != null && drIndex.SelectedIndex != -1 && txtBrosefor.Text.Trim()!="")
                {
                    Response.Redirect("~/Dom/Browse.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&index=" + drIndex.SelectedValue.ToString() + "&browse=" + txtBrosefor.Text.Trim());
                }                
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
        }
        /// <summary>
        /// Event call to handle the click button of Search.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (Request.QueryString["db"] != null)
                {
                    Response.Redirect("~/Dom/Result.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&s1=" + txtFind.Text.ToString() + "&t1=" + drpFind.SelectedValue.ToString() + "&d1=" + drpFirstSelect.SelectedValue.ToString() + "&s2=" + txtFirst.Text.ToString() + "&t2=" + drpFirst.SelectedValue.ToString() + "&d2=" + drpSecondSelect.SelectedValue.ToString() + "&s3=" + txtSecond.Text.ToString() + "&t3=" + drpSecond.SelectedValue.ToString() + "&d3=" + drpThirdSelect.SelectedValue.ToString() + "&s4=" + txtThird.Text.ToString() + "&t4=" + drpThird.SelectedValue.ToString() + "&sort=" + drpDateSort.SelectedValue.ToString() + "&ft=" + chkbx.Checked);
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
        }
        #endregion
        #region Method

        /// <summary>
        /// Get value from XML file and binding the data to dropdown
        /// </summary>
        private void ConditionsFill()
        {
            try
            {
                ArrayList item = new ArrayList();
                item.Add("AND");
                item.Add("OR");
                item.Add("NOT");

                drpFirstSelect.DataSource = item;
                drpFirstSelect.DataBind();
                drpSecondSelect.DataSource = item;
                drpSecondSelect.DataBind();
                drpThirdSelect.DataSource = item;
                drpThirdSelect.DataBind();
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO  
            }
        }
        #endregion

    }
    #endregion

}
#endregion 