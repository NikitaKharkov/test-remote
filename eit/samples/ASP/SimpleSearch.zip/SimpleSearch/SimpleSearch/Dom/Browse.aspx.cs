﻿
#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.dom;
using System.Xml;
using System.Text;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from the Linkbutton
    /// <summary>
    // Class created for taking input from the Linkbutton 
    // and redirect the page to the requested page
    /// </summary>
    public partial class Browse : System.Web.UI.Page
    {
        #region Variable and object
        DataService xmlDoc;
        #endregion

        #region Events
        /// <summary>
        /// OnPreInit event is called and override to add several control
        /// </summary>
        /// <param name="e">Contains Event arrguments</param>
        protected override void OnPreInit(EventArgs e)
        {
            try
            {
                //to check if any parrameret is blanck the redirect the page
                if (Request.QueryString["db"] != "" || Request.QueryString["index"] != null || Request.QueryString["browse"] != null)
                {
                    linkHp.PostBackUrl="~/Dom/Search.aspx?db=" + Convert.ToString(Request.QueryString["db"]) ;
                    //// Setup profile parameters to pass in the class
                    string[] parms = new string[] { Convert.ToString(Request.QueryString["index"]), Convert.ToString(Request.QueryString["browse"]), Convert.ToString(Request.QueryString["db"]) };
                    //Initiallization of class
                    xmlDoc = new DataService();
                    //Passing the webservice URL
                    xmlDoc.Connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
                    // Request Database Information through Browse Method
                    var xmlData = xmlDoc.PostXMLTransaction("Browse", parms);
                    //Check the return doc count else redirect
                    if (xmlData.ChildNodes.Count > 0)
                    {
                        // Get all 'rec' elements from the XML document.
                        XmlNodeList xnList = xmlData.GetElementsByTagName("rec");
                        //Creating table dynamically to show data at the page
                        StringBuilder sbTable = new StringBuilder();
                        sbTable.Append("<table align='left' width='50%'>");
                        sbTable.Append("<tr ><th>Name</th><th>Records Count</th></tr>\n");
                        //Looping to get all the child record for the keyword
                        for (int i = 0; i < xnList.Count; i++)
                        {
                            foreach (XmlNode xmlNode in xnList[i])
                            {
                                foreach (XmlNode subNode in xmlNode)
                                {
                                    if (subNode.Attributes["searchKey"] != null || subNode.Attributes["count"] != null)
                                    {
                                        sbTable.Append("<tr >");
                                        sbTable.Append(CreateControl("term", subNode.Attributes["searchKey"],null ));
                                        sbTable.Append(CreateControl("count", subNode.Attributes["count"], subNode.Attributes["searchKey"]));
                                        sbTable.Append("</tr>");
                                    }
                                }
                            }
                        }
                        sbTable.Append("</table>");
                        divTable.InnerHtml = sbTable.ToString();
                    }
                }
                else
                {
                    //If any parrameter is blanck the redirect the page
                    Response.Redirect("Search.aspx?db=" + Convert.ToString(Request.QueryString["db"]));
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
        }
        /// <summary>
        /// Reload the page with new parameters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtSearch.Text.Trim() != "")
                {
                    Response.Redirect("Browse.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&index=" + Convert.ToString(Request.QueryString["index"]) + "&browse="+txtSearch.Text.Trim());
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        
        #endregion

        #region Method
        /// <summary>
        /// Use to create control and assign its value dynamically
        /// </summary>
        /// <param name="type">Type of parameter</param>
        /// <param name="xmlNodeList">Send the nodelist for getting value for the control</param>
        /// <param name="i">Value of control</param>
        /// <returns></returns>
        private string CreateControl(string type, XmlNode xmlNodeList, XmlNode xmlNodeCount)
        {
            string strControl = "";
            try
            {
                //Check the type of the control
                if (type == "term")
                {
                    //Based on type create the control
                    strControl = "<td>\n<a href='Browse.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&index=" + Convert.ToString(Request.QueryString["index"]) + "&browse=" + xmlNodeList.Value.Replace(",", "").Replace("+", "") + "'>" + xmlNodeList.Value.Replace(",", "").Replace("+", "") + "</a>\n</td>";
                }
                else if (type == "count")
                {
                    //Based on value create the control
                    strControl = "<td>\n<a href='Browse.aspx?db=" + Convert.ToString(Request.QueryString["db"]) + "&index=" + Convert.ToString(Request.QueryString["index"]) + "&browse=" + xmlNodeCount.Value.Replace(",", "").Replace("+", "") + "'>" + xmlNodeList.Value.Replace(",", "").Replace("+", "") + "</a>\n</td>"; 
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
            return strControl;
        }
        #endregion

       
    }
    #endregion
}
#endregion



