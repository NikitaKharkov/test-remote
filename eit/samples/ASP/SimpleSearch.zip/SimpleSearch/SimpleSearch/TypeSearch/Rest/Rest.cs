﻿#region ©2011 PSL.
/*=====================================================================
 File:   cls Rest.cs
 Author:   Ritesh Sinha
 DateCreated: 2011-09-02
 DateChanged: 2005-09-02
 ---------------------------------------------------------------------
 ©2011 All Rights Reserved. 
=======================================================================
=======================================================================|
This class containing all commmon function that will be used in 
other classes and projects by adding a reference to this class.
=======================================================================|*/
/*=====================================================================
 Date   Author  Changes   Reasons
     
 
 Changes: Create, Refactoring, Upgrade 
=====================================================================*/
#endregion

#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Configuration;
using System.Web.Configuration;
using System.IO;
using System.Xml;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch.TypeSearch.dom
{
    //This DataService class uses PHP's cURL to connect to the
    //EBSCOhost Web Service.  The methods are as follows:
    //  - DataService->Connect( u_service_url )
    //This function initializes the class with the URL of the data
    //service.
    //  - DataService->PostXMLTransaction( v_strURL, parm )
    //This function sends a command using the HTTP GET protocol.
    //This function returns the output from the web service call.
    public class DataService
    {
        // Holds the URL of the service
        private string service_url;
       
        /// <summary>
        /// Set the Service URL
        /// </summary>
        /// <param name="u_service_url">Webservice url passed </param>
        public void Connect(string u_service_url)
        {
            service_url = u_service_url;
        }
        // Sends a command. If the web service is located at
        // http://example.com/service.aspx , the command 'Info' would
        // would look as follows:
        // "http://example.com/service.aspx/Info?param1=value&param2=value"
        public XmlDocument PostXMLTransaction(string v_strURL, string[] parm)
        {
            //Declare XMLResponse document
            XmlDocument XMLDoc = null;
            string url = "";
            //Declare an HTTP-specific implementation of the WebRequest class.
            HttpWebRequest objHttpWebRequest;
            //Declare XMLReader
            XmlTextReader xmlTextReader;
            try
            {
                //Get userid and password
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);
                //Check the type of method and create the URL acordingly
                if (v_strURL == "Info")
                {
                    url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd;
                }
                else if (v_strURL == "Browse")
                {
                    url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd + "&index=" + parm[0].ToString() + "&term=" + parm[1].ToString() + "&db=" + parm[2].ToString();
                }
                else if (v_strURL == "Search")
                {
                    url = service_url + v_strURL + "?prof=" + strUserID + "&pwd=" + strPwd + "&query=" + parm[0].ToString() + "&startrec=" + parm[1].ToString() + "&db=" + parm[2].ToString() + "&sort=" + parm[3].ToString();
                }
                if (url != "")
                {
                    //Creates an HttpWebRequest for the specified URL.
                    objHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                    HttpWebResponse response = (HttpWebResponse)objHttpWebRequest.GetResponse();
                    //----------------Start HttpResponse----------------------------//
                    //Load response stream into XMLReader
                    xmlTextReader = new XmlTextReader(response.GetResponseStream());
                    //Declare XMLDocument
                    XMLDoc = new XmlDocument();
                    XMLDoc.Load(xmlTextReader);
                    ////Close XMLReader
                    xmlTextReader.Close();
                }
            }
            catch (WebException we)
            {
                //TODO: Add custom exception handling
                // throw new Exception(we.Message);
            }
            catch (Exception ex)
            {
                //TODO: Add custom exception handling
                //throw new Exception(ex.Message);
            }
            finally
            {
                //Release objects
                xmlTextReader = null;
                objHttpWebRequest = null;
            }
            //Return
            return XMLDoc;
        }
    }
}
#endregion

