﻿#region ©2011 PSL.
/*=====================================================================
 File:   cls SOAP.cs
 Author:   Ritesh Sinha
 DateCreated: 2011-09-02
 DateChanged: 2005-09-02
 ---------------------------------------------------------------------
 ©2011 All Rights Reserved. 
=======================================================================
=======================================================================|
This class containing all commmon function that will be used in 
other classes and projects by adding a reference to this class.
=======================================================================|*/
/*=====================================================================
 Date   Author  Changes   Reasons
     
 
 Changes: Create, Refactoring, Upgrade 
=====================================================================*/
#endregion

#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Configuration;
using System.Web.Services.Protocols;
using System.Xml;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Formatters;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch.TypeSearch.soap
{
    /// <summary>
    /// This class is a SOAP Implementation of the web service
    //available at http://eit.ebscohost.com/Services/SearchService.asmx.
    //This class is based off of the WSDL file:
    //http://eit.ebscohost.com/Services/SearchService.asmx?WSDL
    /// </summary>
    public class SOAP
    {
        #region Variable and object
        StringBuilder soapMsg = new StringBuilder();
        #endregion

        /// <summary>
        /// This SOAP message requests database information from
        /// the service.
        /// </summary>
        /// <returns> string containg XML from webservices response</returns>
        public string Info()
        {
            // This SOAP message requests database information from
            // the service.
            string xmlInfoResponse = "";
            try
            {
                //Get userid and password from config file
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);

                //Create cutom soap header 
                StringBuilder strInfoRequestBody = new StringBuilder();
                strInfoRequestBody.Append(@"
                <soap:Envelope xmlns:soap=""http://www.w3.org/2003/05/soap-envelope"" soap:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding"">
                <soap:Header>
                <auth:AuthorizationHeader soap:mustUnderstand=""1"" xmlns:auth=""http://epnet.com/webservices/SearchService/2007/07/"">
                <auth:Profile>" + strUserID + "</auth:Profile>");
                strInfoRequestBody.Append("<auth:Password>" + strPwd + "</auth:Password>");
                strInfoRequestBody.Append("</auth:AuthorizationHeader>");
                strInfoRequestBody.Append("</soap:Header>");
                strInfoRequestBody.Append("<soap:Body>");
                strInfoRequestBody.Append(@"<eit:Info xmlns:eit=""http://epnet.com/webservices/SearchService/2007/07/""/></soap:Body></soap:Envelope>");
                //Pass to the method for the soap response
                xmlInfoResponse = PostXMLTransaction(strInfoRequestBody.ToString());
            }
            catch (Exception)
            {
            }
            return xmlInfoResponse;
        }
        /// <summary>
        /// This message will request a Search from the SOAP service.
        /// Send the SOAP message to the service.  The data returned from
        /// the send function is the entire SOAP message.  We just want to
        /// get the information inside
        /// </summary>
        /// <param name="parm">Parameter from the page to add in the soap header</param>
        /// <returns> string containg XML from webservices  response</returns>
        public string Search(string[] parm)
        {
            string xmlSearchoResponse = "";
            try
            {   
                //Get userid and password
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);

                string numRec = "10";
                //Soap header for the Search 
                StringBuilder strSearchRequestBody = new StringBuilder();
                strSearchRequestBody.Append(@"
                  <soap:Envelope xmlns:soap=""http://www.w3.org/2003/05/soap-envelope"" soap:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/"" >
                    <soap:Header>
                        <auth:AuthorizationHeader soap:mustUnderstand=""1"" xmlns:auth=""http://epnet.com/webservices/SearchService/2007/07/"">
                            <auth:Profile>" + strUserID + "</auth:Profile>");
                strSearchRequestBody.Append("<auth:Password>" + strPwd + "</auth:Password>");
                strSearchRequestBody.Append("</auth:AuthorizationHeader></soap:Header>");
                strSearchRequestBody.Append(@"<soap:Body><eit:Search xmlns:eit=""http://epnet.com/webservices/SearchService/2007/07/"">");
                strSearchRequestBody.Append("<eit:searchRequest><eit:Query>" + Convert.ToString(parm[0]) + "</eit:Query>");
                strSearchRequestBody.Append("<eit:Databases>" + Convert.ToString(parm[2]) + "</eit:Databases>");
                strSearchRequestBody.Append("<eit:StartingRecordNumber>" + Convert.ToString(parm[1]) + "</eit:StartingRecordNumber>");
                strSearchRequestBody.Append("<eit:NumberRecordsReturned>" + numRec + "</eit:NumberRecordsReturned>");
                strSearchRequestBody.Append("<eit:Sort>" + Convert.ToString(parm[3]) + "</eit:Sort>");
                strSearchRequestBody.Append("</eit:searchRequest></eit:Search></soap:Body></soap:Envelope>");
                xmlSearchoResponse = PostXMLTransaction(strSearchRequestBody.ToString());
            }
            catch (Exception)
            {
            }
            return xmlSearchoResponse;
        }
        /// <summary>
        /// This message will request a Browse from the SOAP service.
        /// </summary>
        /// <param name="parm">Parameter from the page to add in the soap header</param>
        /// <returns>string containg XML from webservices  response</returns>
        public string Browse(string[] parm)
        {
            string xmlBrowseResponse="";
           
            try
            {
                 string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);

                StringBuilder strBrowseRequestBody =new StringBuilder();
                strBrowseRequestBody.Append( @"
                    <soap:Envelope xmlns:soap=""http://www.w3.org/2003/05/soap-envelope"" soap:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/"" >
                    <soap:Header>
                        <auth:AuthorizationHeader soap:mustUnderstand=""1"" xmlns:auth=""http://epnet.com/webservices/SearchService/2007/07/"">
                            <auth:Profile>"+strUserID+"</auth:Profile>");
                strBrowseRequestBody.Append("<auth:Password>"+strPwd+"</auth:Password>");
                strBrowseRequestBody.Append("</auth:AuthorizationHeader>");
                strBrowseRequestBody.Append("</soap:Header>");
                strBrowseRequestBody.Append(@"<soap:Body><eit:Browse xmlns:eit=""http://epnet.com/webservices/SearchService/2007/07/""><eit:browseRequest>");
                strBrowseRequestBody.Append("<eit:Term>" + Convert.ToString(parm[1])+ "</eit:Term>");
                strBrowseRequestBody.Append("<eit:Index>" + Convert.ToString(parm[0]) + "</eit:Index>");
                strBrowseRequestBody.Append("<eit:Databases>" + Convert.ToString(parm[2]) + "</eit:Databases>");
                strBrowseRequestBody.Append("</eit:browseRequest></eit:Browse></soap:Body></soap:Envelope>");
                xmlBrowseResponse=PostXMLTransaction(strBrowseRequestBody.ToString());
            }
            catch (Exception)
            {   
            }
            return xmlBrowseResponse;
        }
        /// <summary>
        /// This function uses cURL to send data to the SOAP service.
        //  string $message The Soap message to be posted as the request
        /// </summary>
        /// <param name="strBody">Created soap header for the request</param>
        /// <returns>return Returns the response from web service</returns>
        private string PostXMLTransaction(string strBody)
        {
            string strResponse = "";
            try
            {
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://eit.ebscohost.com/Services/SearchService.asmx");
                request.Method = "POST";
                request.ContentType = "application/soap+xml; charset=utf-8";
                request.ContentLength = strBody.Length;
                System.IO.StreamWriter streamWriter = new System.IO.StreamWriter(request.GetRequestStream());
                streamWriter.Write(strBody);
                streamWriter.Close();
                System.IO.StreamReader streamReader = new System.IO.StreamReader(request.GetResponse().GetResponseStream());

                while (!streamReader.EndOfStream)
                {
                    strResponse += streamReader.ReadLine();
                }
                streamReader.Close();
            }
            catch (Exception)
            {
            }
            return strResponse;
        }
    }
}
#endregion