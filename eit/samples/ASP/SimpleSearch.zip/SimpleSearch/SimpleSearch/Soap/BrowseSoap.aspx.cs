﻿

#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.soap;
using System.Xml;
using System.Text;
using System.Xml.Xsl;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from the Linkbutton
    /// <summary>
    // Class created for taking input from the Linkbutton 
    // and redirect the page to the requested page
    /// </summary>
    public partial class BrowseSoap : System.Web.UI.Page
    {
        #region Variable and object
        SOAP xmlDoc;
        #endregion

        #region Events
        /// <summary>
        /// OnPreInit event is called and override to add several control
        /// </summary>
        /// <param name="e">Contains Event arrguments</param>
        protected override void OnPreInit(EventArgs e)
        {
            try
            {
                //to check if any parrameret is blanck the redirect the page
                if (Request.QueryString["db"] != "" || Request.QueryString["index"] != null || Request.QueryString["browse"] != null)
                {
                    //// Setup profile parameters to pass in the class
                    string[] parms = new string[] { Convert.ToString(Request.QueryString["index"]), Convert.ToString(Request.QueryString["browse"]), Convert.ToString(Request.QueryString["db"]) };
                    //Initiallization of class
                    xmlDoc = new SOAP();
                    var xmlData = xmlDoc.Browse(parms);
                    //Check the return doc count else redirect
                    if (xmlData.Length > 0)
                    {
                        //Creating custom XML to pass data to XSL
                        string strReplace = xmlData.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                        StringBuilder xmlCreate = new StringBuilder();

                        // Output information about the search query.
                        xmlCreate.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"browseSoap.xsl\"?>");
                        xmlCreate.Append("<wrapper>\n");
                        xmlCreate.Append("<dbSelect>" + Convert.ToString(Request.QueryString["db"])+ "</dbSelect>\n");
                        xmlCreate.Append("<index>" + Convert.ToString(Request.QueryString["index"]) +"</index>\n");
                        xmlCreate.Append(strReplace);
                        xmlCreate.Append("\n</wrapper>");
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(xmlCreate.ToString());
                        //Passing xmldoc to transform the xml in XLS
                        string xslPath = Server.MapPath("~//App_Data/browseSoap.xsl");
                        XslCompiledTransform transform = new XslCompiledTransform();
                        transform.Load(xslPath);
                        transform.Transform(doc, null, Response.Output);
                    }
                }
                else
                {
                    //Redirecting the page if error occured
                    //To DO
                }

            }
            catch (Exception)
            {
                //To do
            }
        }
        #endregion
          
    }

    #endregion
}
#endregion


