﻿#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.soap;
using System.Xml;
using System.Collections;
using System.Xml.Xsl;
using System.Text;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from query string
    /// <summary>
    // Class created for taking requested and processing the same  
    /// </summary>
    public partial class searchSoap : System.Web.UI.Page
    {
        #region Variable and object
        SOAP xmlDoc;
        #endregion

        #region Event

        /// <summary>
        /// Page load event is called and to add several control in XLS
        /// </summary>
        /// <param name="e">Contains Event arrguments</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //Check the querystring for DB else redirect
                if (Request.QueryString["db"] != "")
                {
                    //Initiallization of class
                    xmlDoc = new SOAP();
                   
                    //Get all the parameter
                    var xmlData = xmlDoc.Info();
                    // Request Database Information through Browse Method
                    //Check the return doc count else redirect
                    if (xmlData.Length > 0)
                    {
                        //Passing xmldoc to transform the xml in XLS
                        string xslPath = Server.MapPath("~//App_Data/searchSoap.xsl");
                        StringBuilder xmlString=new StringBuilder(); 
                        xmlData = xmlData.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");

                        xmlString.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"searchSoap.xsl\"?>");
                        xmlString.Append("<wrapper>\n");
                        xmlString.Append("<selected>selected</selected>\n");
                        xmlString.Append("<dbSelect>"+ Convert.ToString(Request.QueryString["db"])+ "</dbSelect>\n"+  xmlData);
                        xmlString.Append("\n</wrapper>");
                        XslCompiledTransform transform = new XslCompiledTransform();
                        transform.Load(xslPath);
                        XmlDocument xml = new XmlDocument();
                        xml.LoadXml(xmlString.ToString());
                        transform.Transform(xml, null, Response.Output);
                    }
                }
                else
                {
                    Response.Redirect("~/Soap/SelectDbSoap.aspx");
                }

            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
        }
        #endregion
    }
    #endregion
}
#endregion