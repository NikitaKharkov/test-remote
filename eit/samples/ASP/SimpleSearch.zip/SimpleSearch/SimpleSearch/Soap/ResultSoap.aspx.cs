﻿#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using SimpleSearch.TypeSearch.soap;
using System.Xml;
using System.Xml.Xsl;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from query string  
    /// <summary>
    // Class created for taking requested and processing the same  
    /// </summary>
    public partial class ResultSoap : System.Web.UI.Page
    {
        #region Variable and object
        SOAP xmlDoc;
        private string start = "";
        private string link="";
        private StringBuilder pageControls = new StringBuilder();
        StringBuilder xmlVars = new StringBuilder();
        string query = "";
        #endregion

        #region Event
        
        /// <summary>
        /// Page load event is called and to add several control in XLS
        /// </summary>
        /// <param name="e">Contains Event arrguments</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //Check the querystring for DB else redirect
                if (Request.QueryString["db"] != "")
                {
                    ////Check the querystring for other valuse else redirect
                    if (Convert.ToString(Request.QueryString["s1"]) != "" || Convert.ToString(Request.QueryString["s2"]) != "" || Convert.ToString(Request.QueryString["s3"]) != "" || Convert.ToString(Request.QueryString["s4"]) != "")
                    {
                        //Initiallization of class
                        xmlDoc = new SOAP();
                        //Get all the parameter
                        string[] parm = Getparameter();
                        // Request Database Information through Browse Method
                        var xmlData = xmlDoc.Search(parm);
                        //Check the return doc count else redirect
                        DisplayResult(xmlData);
                    }
                    else
                    {
                        Response.Redirect("~/Soap/SearchSoap.aspx?db=" + Convert.ToString(Request.QueryString["db"]));
                    }
                }
                else
                {
                    Response.Redirect("~/Soap/SelectDbSoap.aspx");
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// Creating custom XML to pass data to XSL
        /// </summary>
        /// <param name="xmlData"></param>
        private void DisplayResult(string xmlData)
        {
            StringBuilder sbTable = new StringBuilder();
            try
            {
                if (xmlData.Length> 0)
                {
                    string strReplace = xmlData.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                    StringBuilder xmlCreate = new StringBuilder();
                    
                    // Output information about the search query.
                    xmlCreate.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"resultsSoap.xsl\"?>");
                    xmlCreate.Append("<wrapper>\n");
                    xmlCreate.Append("<dbSelect>" + Convert.ToString(Request.QueryString["db"]) + "</dbSelect>\n");
                    xmlCreate.Append("<start_record>" + start + "</start_record>\n");
                    xmlCreate.Append("<query>" + query + "</query>\n");
                    xmlCreate.Append("<prev_page>" + link.Replace("&", "&amp;") + "&amp;start=" + (Convert.ToInt64(start)- 10) + "</prev_page>\n");
                    xmlCreate.Append("<next_page>" + link.Replace("&", "&amp;") + "&amp;start=" + (Convert.ToInt64(start) + 10) + "</next_page>\n");
                    xmlCreate.Append("<new_search>" + link.Replace("&", "&amp;") + "</new_search>\n");
                    // Output the variables for the XSL stylesheet.
                    xmlCreate.Append(xmlVars);
                    xmlCreate.Append(strReplace);
                    xmlCreate.Append("\n</wrapper>");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(xmlCreate.ToString());
                    //Passing xmldoc to transform the xml in XLS
                    string xslPath = Server.MapPath("~//App_Data/resultsSoap.xsl");
                    XslCompiledTransform transform = new XslCompiledTransform();
                    transform.Load(xslPath);
                    transform.Transform(doc, null, Response.Output);
                }
                    
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
        }
        /// <summary>
        /// Getting all the parameter from querystring and forming the link
        /// </summary>
        /// <returns></returns>
        private string[] Getparameter()
        {
            string[] parms = null;
           // StringBuilder for URL 
            try
            {
                // Execute search query and return results.
                // Search Terms for TEXTBOX
                string s1 = Convert.ToString(Request.QueryString["s1"]);
                if (s1 != "")
                {
                    xmlVars.Append("<s1>" + s1 + "</s1>\n");
                }
                string s2 = Convert.ToString(Request.QueryString["s2"]);
                if (s2 != "")
                {
                    xmlVars.Append("<s2>" + s2 + "</s2>\n");
                }
                string s3 = Convert.ToString(Request.QueryString["s3"]);
                if (s3 != "")
                {
                    xmlVars.Append("<s3>" + s3 + "</s3>\n");
                }
                string s4 = Convert.ToString(Request.QueryString["s4"]);
                if (s4 != "")
                {
                    xmlVars.Append("<s4>" + s4 + "</s4>\n");
                }
                // Search Terms for DROPDOWN    
                string d1 = Convert.ToString(Request.QueryString["d1"]);
                if (d1 != "")
                {
                    xmlVars.Append("<d1>" + d1 + "</d1>\n");
                }
                string d2 = Convert.ToString(Request.QueryString["d2"]);
                if (d2 != "")
                {
                    xmlVars.Append("<d2>" + d2 + "</d2>\n");
                }
                string d3 = Convert.ToString(Request.QueryString["d3"]);
                if (d3 != "")
                {
                    xmlVars.Append("<d3>" + d3 + "</d3>\n");
                }
                // Search Terms for DROPDOWN   
                string t1 = Convert.ToString(Request.QueryString["t1"]);
                if (t1 != "")
                {
                    xmlVars.Append("<t1>" + t1 + "</t1>\n");
                }
                string t2 = Convert.ToString(Request.QueryString["t2"]);
                if (t2 != "")
                {
                    xmlVars.Append("<t2>" + t2 + "</t2>\n");
                }
                string t3 = Convert.ToString(Request.QueryString["t3"]);
                if (t3 != "")
                {
                    xmlVars.Append("<t3>" + t3 + "</t3>\n");
                }
                string t4 = Convert.ToString(Request.QueryString["t4"]);
                if (t4 != "")
                {
                    xmlVars.Append("<t4>" + t4 + "</t4>\n");
                }
                // Other
                string db = Convert.ToString(Request.QueryString["db"]);
                string sort = Convert.ToString(Request.QueryString["sort"]);
                if (sort != "")
                {
                    xmlVars.Append("<sort>" + sort + "</sort>\n");
                }
                start = (Convert.ToString(Request.QueryString["start"]) != null) ? (Convert.ToString(Request.QueryString["start"])) : "1";
                string ft = (Convert.ToString(Request.QueryString["ft"]) != "0") ? "true" : "false";
                if (ft != "true")
                {
                    xmlVars.Append("<ft>" + ft + "</ft>\n");
                }
                // No search terms, go back to select DB
                if (s1 != null && s2 != null && s3 != null && s4 != null || db != null)
                {
                    // The link for 'next' and 'previous' pages
                    link = "ResultSoap.aspx?db=" + db + "&sort=" + sort + "&s1=" + s1 + "&s2=" + s2 + "&s3=" + s3 + "&s4=" + s4 + "&t1=" + t1 + "&t2=" + t2 + "&t3=" + t3 + "&t4=" + t4 + "&d1=" + d1 + "&d2=" + d2 + "&d3=" + d3 + "&ft=" + ft;
                    // Query Build Algorithm
                    if (!s1.Equals(null) && !s1.Equals(""))
                    {
                        s1 = s1.Replace(" ", "+");
                        s1 = (s1 != null && !s1.Equals("")) ? ("(" + t1 + (t1 != "" ? "+(" : "") + s1 + ")" + (t1 != "" ? ")" : "")) : null;
                    }
                    if (!s2.Equals(null) && !s2.Equals(""))
                    {
                        s2 = s2.Replace(" ", "+");
                        s2 = (s2 != null && !s2.Equals("")) ? ("(" + t2 + (t2 != "" ? "+(" : "") + s2 + ")" + (t2 != "" ? ")" : "")) : null;
                    }
                    if (!s3.Equals(null) && !s3.Equals(""))
                    {
                        s3 = s3.Replace(" ", "+");
                        s3 = (s3 != null && !s3.Equals("")) ? ("(" + t3 + (t3 != "" ? "+(" : "") + s3 + ")" + (t3 != "" ? ")" : "")) : null;
                    }
                    if (!s4.Equals(null) && !s4.Equals(""))
                    {
                        s4 = s4.Replace(" ", "+");
                        s4 = (s4 != null && !s4.Equals("")) ? ("(" + t4 + (t4 != "" ? "+(" : "") + s4 + ")" + (t4 != "" ? ")" : "")) : null;
                    }
                    query = s1 + ((s2 != "") ? ("+" + d1 + "+") : null) + s2 + ((s3 != "") ? ("+" + d2 + "+") : null) + s3 + ((s4 != "") ? ("+" + d3 + "+") : null) + s4;
                    query = query.Replace(")(", ")+AND+(");
                    if (!(query.Contains("AND FT Y") && ft == "true"))                    {
                        query += "AND FT Y";
                    }
                    parms = new string[] { query, start, Convert.ToString(Request.QueryString["db"]), sort };
                }
                else
                {
                    //To redirect
                    Response.Redirect("~/Soap/SearchSoap.aspx?db=" + Convert.ToString(Request.QueryString["db"]));
                }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
            return parms;
        }
        #endregion
    }
    #endregion
}
#endregion