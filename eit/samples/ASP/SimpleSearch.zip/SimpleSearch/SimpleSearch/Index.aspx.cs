﻿
#region Namespace Declaration

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.soap;
#endregion


#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from the Linkbutton
    /// <summary>
    // Class created for taking input from the Linkbutton 
    // and redirect the page to the requested page
    /// </summary>
    public partial class index : System.Web.UI.Page
    {
        #region Events
        /// <summary>
        ///Main begins program execution.
        /// </summary>
        /// <param name="sender">It point to the sender by whic it has been called</param>
        /// <param name="e">Contains Event arrguments</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Begins program execution.         
        }
        /// <summary>
        /// Search using REST and DOM:- It will redirect the page which are using Dom
        /// </summary>
        /// <param name="sender">Linkbutton is the sender</param>
        /// <param name="e">Contains all event of linkbutton</param>
        protected void DOM_Click(object sender, EventArgs e)
        {
            try
            {
                //Redirecting the page on requested URL
                Response.Redirect("~/Dom/Search.aspx");
            }
            catch (Exception )
            {
                //Redirecting the page if error occured
               // //To DO
            }
            
        }
        /// <summary>
        /// Search using REST and XSL:- It will redirect the page which are using Dom and XSL for UI
        /// </summary>
        /// <param name="sender">Linkbutton is the sender</param>
        /// <param name="e">Contains all event of linkbutton</param>
        protected void REST_Click(object sender, EventArgs e)
        {
            try
            {
                //Redirecting the page on requested URL
                Response.Redirect("~/XSL/SearchXLS.aspx");
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
              //  //To DO
            }
             
        }
        /// <summary>
        /// Search using SOAP and XSL:- It will redirect the page which are using SOAP and XSL for UI
        /// </summary>
        /// <param name="sender">Linkbutton is the sender</param>
        /// <param name="e">Contains all event of linkbutton</param>
        protected void SOAP_Click(object sender, EventArgs e)
        {
            try
            {
                //Redirecting the page on requested URL
                //To Do
                Response.Redirect("~/Soap/SearchSoap.aspx");
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
             //   //To DO
            }
        }
        #endregion
    }
    #endregion
}
#endregion