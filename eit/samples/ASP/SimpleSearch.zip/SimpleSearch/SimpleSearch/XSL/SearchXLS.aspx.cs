﻿#region Namespace Declaration
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SimpleSearch.TypeSearch.dom;
using System.Xml;
using System.Collections;
using System.Xml.Xsl;
using System.Text;
#endregion

#region  Namespaces for the Page
namespace SimpleSearch
{
    #region Class created for taking input from query string
    /// <summary>
    // Class created for taking requested and processing the same  
    /// </summary>
    public partial class searchXLS : System.Web.UI.Page
    {
        #region Variable and object
        DataService xmlDoc;
        #endregion

        #region Event

        /// <summary>
        /// Page load event is called and to add several control in XLS
        /// </summary>
        /// <param name="e">Contains Event arrguments</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                   //Initiallization of class
                    xmlDoc = new DataService();
                    //Passing the webservice URL
                    xmlDoc.Connect("http://eit.ebscohost.com/Services/SearchService.asmx/");
                    //Get all the parameter
                    var xmlData = xmlDoc.PostXMLTransaction("Info", null);
                    // Request Database Information through Browse Method
                    //Check the return doc count else redirect
                    if (xmlData.ChildNodes.Count > 0)
                    {
                        string strReplace = xmlData.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");
                        StringBuilder xmlCreate = new StringBuilder();
                        xmlCreate.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"search.xsl\"?>");
                        xmlCreate.Append("<wrapper>\n");
                        xmlCreate.Append("<selected>selected</selected>\n");
                        xmlCreate.Append("<dbSelect>" + Convert.ToString(Request.QueryString["db"]) + "</dbSelect>\n" + strReplace);
                        xmlCreate.Append("\n</wrapper>");
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(xmlCreate.ToString());
                        //Passing xmldoc to transform the xml in XLS
                        string xslPath = Server.MapPath("~//App_Data/search.xsl");
                        XslCompiledTransform transform = new XslCompiledTransform();
                        transform.Load(xslPath);
                        transform.Transform(doc, null, Response.Output);
                    }
            }
            catch (Exception)
            {
                //Redirecting the page if error occured
                //To DO
            }
        }
        #endregion
    }
    #endregion
}
#endregion