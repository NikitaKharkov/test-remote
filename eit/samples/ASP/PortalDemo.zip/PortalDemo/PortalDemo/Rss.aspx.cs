﻿#region System namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using PortalDemo.TypeSearch;
using System.Text.RegularExpressions;
using System.Xml.Xsl;
#endregion

#region Page namespace
namespace PortalDemo
{
    /// <summary>
    /// This file will simply retrieve the RSS reed in $url, and will display it
    /// using XSLT
    /// </summary>
    public partial class Rss : System.Web.UI.Page
    {
        #region Event
        /// <summary>
        /// Page load is excecuted when page is loaded 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //XMLDocument to get response of the webservices
                XmlDocument xmlDocument = new XmlDocument();
                //Object of the class SearchType 
                SearchType rssSearch = new SearchType();
                //Get response for the RSS 
                xmlDocument = rssSearch.GetRssResponseData();
                
                if (xmlDocument.ChildNodes.Count > 0)
                {
                    //Get inner xml of xmlDocument 
                    string xmlData = xmlDocument.InnerXml.ToString();
                    //Removing the XML version from InnerXml
                    xmlData=xmlData.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                    xmlData = Regex.Replace(xmlData, "/<rss(.*?)>/", "<ep_feed>");
                    xmlData = Regex.Replace(xmlData, "/<\\/rss>/", "</ep_feed>");
                    xmlData = Regex.Replace(xmlData, "/<description>(.*?)<\\/description>/", "<description></description>");
                    //Creating new  XMLDocument and loading it from the created string
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(xmlData.ToString());
                    //Path of the rss.xsl
                    string xslPath = Server.MapPath("~//App_Data/rss.xsl");
                    //Doing the transformation 
                    XslCompiledTransform transform = new XslCompiledTransform();
                    transform.Load(xslPath);
                    transform.Transform(doc, null, Response.Output);
                }
            }
            catch (Exception)
            {
               
            }
        }
        #endregion
    }
}
#endregion