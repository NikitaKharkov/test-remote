﻿#region System Namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using PortalDemo.TypeSearch;
using System.Text.RegularExpressions;
using System.Collections;
#endregion

#region Page Namespace
namespace PortalDemo
{
    /// <summary>
    /// This example makes use of the REST protocol to retrieve the RSS feeds
    /// and the search results.  Both are processed using XSLT.
    /// </summary>
    public partial class Index : System.Web.UI.Page
    {
        /// <summary>
        /// Page load is called when page is requested
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string query = Request.QueryString["query"];
            string start = Request.QueryString["start"];
            string queryUnformatted = "";
            string query_original = "";
            string strXmlDocCluster = "";
            StringBuilder sb = new StringBuilder();
            string strXmlDoc = "";
            try
            {
                // If there is no query set, then we display the index page.
                if (query == null)
                {
                    //Code commented to stoping display of blan page.
                    //sb.Append("<no_data>Please Enter a term to see the Search Results</no_data>");
                    //XmlDocument doc = new XmlDocument();
                    //doc.LoadXml(sb.ToString());
                    ////Passing xmldoc to transform the xml in XLS
                    //string xslPath = Server.MapPath("~//App_Data/search.xsl");
                    //XslCompiledTransform transform = new XslCompiledTransform();
                    //transform.Load(xslPath);
                    //transform.Transform(doc, null, Response.Output);
                    
                    //TO ADD DEFAULT VALUE FOR DISPLAY
                    query = "global warming";
                }
                // Make sure the query is not empty.
                if (start == null)
                {
                    start = "1";
                }
                queryUnformatted = query;
                if (!queryUnformatted.Contains("AND FT Y"))
                {
                    query = queryUnformatted + " AND FT Y";
                }
                else
                {
                    query = queryUnformatted;
                }
                // Replace all spaces with plus signs.
                query = query.Replace(" ", "+");
                // Insert parenthesis if they are not already in the string. Checking the
                // first and last characters.
                if (query[0].ToString() != "(")
                {
                    query = "(" + query;
                }
                if (query[query.Length - 1].ToString() != ")")
                {
                    query += ')';
                }
                SearchType portalSearch = new SearchType();
                XmlDocument xDoc = new XmlDocument();
                XmlDocument xDocCluster = new XmlDocument();
                xDoc = portalSearch.GetResponseData("Search", query, start, null);
                //Return xmldocument of the clustered
                xDocCluster = portalSearch.GetResponseData("GetClusters", query, null, null);
                long numHits = 0;
                //Get number of records which are hits by the specific keyword
                if (xDoc.ChildNodes.Count > 0)
                {
                    // Get rid of the default XML version information in xml
                    strXmlDoc = xDoc.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");
                    // Get rid of the default XML version information in cluster
                    strXmlDocCluster = xDocCluster.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");
                    // Output the XML header, and use the search stylesheet 'search.xsl'.
                    MatchCollection collection = Regex.Matches(strXmlDoc, "<Hits>(.+?)<\\/Hits>");
                    if (collection.Count > 1)
                    {
                        string strVal = collection[0].Value;
                        strVal = strVal.Replace("<Hits>", "").Replace("</Hits>", "");
                        numHits = Convert.ToInt64(strVal);
                    }
                }
                if ((Request.QueryString["qo"] == null))
                {
                    query_original = queryUnformatted;
                }
                else
                {
                    query_original = Request.QueryString["qo"];
                }
                sb.Append("<wrapper>\n");
                // The "query_original" field is used to display the original query in the search box.
                sb.Append("<query_original>" + query_original + "</query_original>\n");
                // This holds the actual formatted query.
                sb.Append("<query>" + query + "</query>\n");
                // Lowest and highest record number.
                sb.Append("<min>" + start + "</min>\n");
                sb.Append("<max>" + (Convert.ToInt64(start) + 9) + "</max>\n");
                // Output Breadcrumbs. This function returns the breadcrumbs in an
                // associative array.
                Hashtable hsBreadcrumbs = new Hashtable();
                hsBreadcrumbs = portalSearch.Breadcrumbs(query);
                sb.Append("<breadcrumbs>" + "\n");
                foreach (DictionaryEntry entry in hsBreadcrumbs)
                {
                    sb.Append("\t" + "<bc name='" + entry.Key + "'>" + entry.Value + "</bc>" + "\n");
                }
                sb.Append("</breadcrumbs>\n");
                if (numHits > 0)
                {
                    ArrayList arraySubject = portalSearch.SubjectClusters(query, start, hsBreadcrumbs);
                    sb.Append("<eit_subjects>" + "\n");

                    foreach (string subject in arraySubject)
                    {
                        sb.Append("\t" + "<eit_subject>" + subject + "</eit_subject>" + "\n");
                    }
                    sb.Append("</eit_subjects>" + "\n");
                }
                // Print out the XML search results returned from the web service.
                sb.Append(strXmlDoc);
                sb.Append(strXmlDocCluster);
                sb.Append("</wrapper>");
                XmlDocument docresult = new XmlDocument();
                docresult.LoadXml(sb.ToString());
                //Passing xmldoc to transform the xml in XLS
                string xslPath = Server.MapPath("~//App_Data/search.xsl");
                //Doing Transformation of the page
                XslCompiledTransform transform = new XslCompiledTransform();
                transform.Load(xslPath);
                transform.Transform(docresult, null, Response.Output);

            }
            catch (Exception)
            {

            }
        }
    }
}
#endregion




