﻿#region System namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Net;
using System.Web.Configuration;
using System.Text.RegularExpressions;
using System.Collections;

#endregion

#region page namespace
namespace PortalDemo.TypeSearch
{
    /// <summary>
    ///  This class uses webservice to retrieve data as xml document.It s method also return array 
    ///  and contain several method 
    /// </summary>
    public class SearchType
    {
        long startRecord=0;
        /// <summary>
        /// This method return XML documents which is the response of the webservice according the parameters 
        /// pass in the method
        /// </summary>
        /// <param name="method">Containt the name of method which has to be called from webservice</param>
        /// <param name="queryValue">Query which has to be passed in the Webservices</param>
        /// <param name="strStart">Start record count</param>
        /// <param name="count">Record count</param>
        /// <returns>XMLDOCUMENTS</returns>
        public XmlDocument GetResponseData(string method,string queryValue,string strStart,string count)
        {
            XmlDocument XMLDoc = null;
            string EITServiceURL="";
            try
            {
                //User id and password from the webconfig file
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);
                string strDb = Convert.ToString(WebConfigurationManager.AppSettings["db"]);
                //Checking the type of method whic has to be called
                if (method.Equals("Search"))
                {
                    if (count=="50")
                    {
                        EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + method + "?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue + "&startrec=" + (Convert.ToInt64(strStart) - startRecord) + "&numrec=50";
                    }
                    else
                    {
                        EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/" + method + "?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue + "&startrec=" + strStart;
                    }
                    
                }
                else if (method.Equals("GetClusters"))
                {
                    EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/"+ method +"?prof=" + strUserID + "&pwd=" + strPwd + "&db=" + strDb + "&query=" + queryValue;
                }
                //Declare an HTTP-specific implementation of the WebRequest class.
                HttpWebRequest objHttpWebRequest;
                //Declare XMLReader
                XmlTextReader xmlTextReader;
                objHttpWebRequest = (HttpWebRequest)WebRequest.Create(EITServiceURL);
                HttpWebResponse response = (HttpWebResponse)objHttpWebRequest.GetResponse();
                //----------------Start HttpResponse-------------------//
                //Load response stream into XMLReader
                xmlTextReader = new XmlTextReader(response.GetResponseStream());
                //Declare XMLDocument
                XMLDoc = new XmlDocument();
                XMLDoc.Load(xmlTextReader);
            }
            catch (Exception)
            {
                //To DO
            }

            return XMLDoc;
        }
        /// <summary>
        /// Get Rss Response Data by the webservice
        /// </summary>
        /// <returns>XmlDocument</returns>
        public XmlDocument GetRssResponseData()
        {
            XmlDocument XMLDoc = null;
            try
            {
                //User id and password from the webconfig file
                string strUserID = Convert.ToString(WebConfigurationManager.AppSettings["Userid"]);
                string strPwd = Convert.ToString(WebConfigurationManager.AppSettings["Pwd"]);

                //URL of the service
                String EITServiceURL = "http://rss.ebscohost.com/AlertSyndicationService/Syndication.asmx/GetFeed?guid=3030448";
                //Declare XMLResponse document

                //Declare an HTTP-specific implementation of the WebRequest class.
                HttpWebRequest objHttpWebRequest;

                //Declare XMLReader
                XmlTextReader xmlTextReader;
                objHttpWebRequest = (HttpWebRequest)WebRequest.Create(EITServiceURL);
                HttpWebResponse response = (HttpWebResponse)objHttpWebRequest.GetResponse();

                //----------------Start HttpResponse

                //Load response stream into XMLReader
                xmlTextReader = new XmlTextReader(response.GetResponseStream());

                //Declare XMLDocument
                XMLDoc = new XmlDocument();
                XMLDoc.Load(xmlTextReader);
            }
            catch (Exception)
            {   
            }
            return XMLDoc;
        }
        // This function creates an array of breadcrumbs using the formatted query
        // string. This function simply splits the query string using )+AND+(SU+ as
        // a delimiter, which separates the terms by subject.
        // ["breadcrumb name"] = "query string";
        // where "query string" is the query relevant to that breadcrumb.
        public Hashtable Breadcrumbs(string query)
        {
            // Output the breadcrumbs
            string tempQuery = "";
            string[] breadcrumbs = query.Split(new string[] { ")+AND+(SU+" }, StringSplitOptions.None);
            int bcBount = breadcrumbs.Length;
            int item = 0;

            Hashtable hashtable = new Hashtable();

            foreach (string breadcrumb in breadcrumbs)
            {
                item++;
                string str = "";
                // Make Breadcrumbs Readable
                str = breadcrumb.Replace("+", " ");
                str = str.Replace("(", "");
                str = str.Replace(")", "");
                str = str.Replace("+AND+FT+Y", "");
                str = str.Replace("AND FT Y", "");
                // This is the query string. Each breadcrumb will have its own
                // query string.

                tempQuery = "";
                // This loop builds the query up. For the first breadcrumb, it will
                // only include the first query. For the second breadcrumb, it will
                // include the first and second, etc.
                for (int i = 0; i < item; i++)
                {
                    tempQuery += breadcrumbs[i];
                    if (i != (item - 1))
                    {
                        tempQuery += ")+AND+(SU+";
                    }
                }
                // If the last character is not a parenthesis, append one
                // onto the query.
                if (tempQuery[(tempQuery.Length) - 1].ToString() != ")")
                {
                    tempQuery += ")";
                }
                hashtable[str] = tempQuery;
            }
            return hashtable;
        }
        /// <summary>
        /// This function will retrieve the subjects associated with a search
        /// and return the 10 most common subjects in a sorted array.  It does this
        /// by retrieving the 50 records closest to the current start record.
        /// exclude is an associative array of items to not include in the
        /// returned subjects.  For any given $subject, if $exclude[ $subject ] is 
        /// set, then it, then it will not display that particular subject.
        /// </summary>
        /// <param name="query">Query for the term which has to be search</param>
        /// <param name="start"></param>
        /// <param name="exclude"></param>
        /// <returns></returns>
        public ArrayList SubjectClusters(string query, string start, Hashtable exclude)
        {
            ArrayList arryList = new ArrayList();
            try
            {
                XmlDocument xmldocument = new XmlDocument();
                long startRecord = 0;
                startRecord = Convert.ToInt64(start) - 25;
                startRecord = (startRecord < 1) ? (24 - (25 - Convert.ToInt64(start))) : (25);
                // Force a full-text only search result.
                //if (!query.Contains("AND FT Y"))
                //{
                //    query += "AND FT Y";
                //}
                query = query.Replace(" ", "+");
                // Retrieve the XML search file from the EIT Search Service. See 'function curl_get()'
                // below for more details.
                xmldocument = GetResponseData("Search", query, Convert.ToString((Convert.ToInt64(start) - startRecord)), "50");
                //Removing the xml version
                string strXmlDoc = xmldocument.InnerXml.ToString().Replace("<?xml version=\"1.0\"?>", "");
                MatchCollection collection = Regex.Matches(strXmlDoc, "<subj type=\"thes\">(.+?)<\\/subj>");
                string strXml;
                //To find the subject from the XML
                Dictionary<string, string> htSubject = new Dictionary<string, string>();
                for (int i = 0; i <= collection.Count - 1; i++)
                {
                    strXml = collection[i].Value;
                    string strvalue = strXml.Replace("<subj type=\"thes\">", "").Replace("</subj>", "");

                    string[] stringSeparators = new string[] { strXml };
                    string[] result;
                    result = strXmlDoc.Split(stringSeparators, StringSplitOptions.None);
                    if (!htSubject.ContainsKey(strvalue) && !exclude.ContainsKey(strvalue))
                    {
                        htSubject.Add(strvalue, Convert.ToString(result.Length - 1));
                    }
                }
                //Sorting the data retrive inthe Dictionary
                var sortedDict = (from entry in htSubject orderby entry.Value descending select entry);
                int k = 0;
                //Taking the top 10 record to display 
                foreach (var item in sortedDict)
                {
                    if (k <= 9)
                    {
                        arryList.Add(item.Key);
                    }
                    else
                    {
                        break;
                    }
                    k++;
                }
            }
            catch (Exception)
            {
            }
            return arryList;
        }
    }
}
#endregion