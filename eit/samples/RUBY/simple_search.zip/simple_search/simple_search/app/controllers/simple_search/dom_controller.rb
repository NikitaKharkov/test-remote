class SimpleSearch::DomController < ApplicationController
  require "rexml/document"
  include REXML
  
  def index
  end
  
  ################################### Search using REST and DOM ##########################################
  
  def search_form
    database = params[:db] 
    
    db_url = BASE_URL.sub('ACTION', DATABASE)
    response = Utilities.get_response(db_url)
    @databases = []
    response.elements.each("info/dbInfo/db") do |elem|
      @databases << [elem.attributes["longName"], elem.attributes["shortName"]]
      @db_data = elem if database == elem.attributes["shortName"] if database
      @db = elem.attributes["longName"] if @db.blank? if @db_data 
    end
    logger.debug "@db = #{@db}"
  end
  
  def search
    unless params[:db].blank?
      @db = params[:db]

      unless params[:page_start]
        @query = SimpleSearch.form_query(params)
        url = SimpleSearch.form_url(params, @query) if @query
        @url_str = url
        @page_start = 1
      else
        @page_start = params[:page_start]
        @url_str = params[:url_str]
        @query = params[:query]

        if params[:quick_search]
          search_txt = params[:search]
          @url_str.sub!(/\+\((.*)\)\)/, "+(#{search_txt}))")
          @query.sub!(/\+\((.*)\)\)/, "+(#{search_txt}))")
        end
      end

      if @url_str
        url = SimpleSearch.paginate(@url_str, @page_start)
        @records = nil
        @total = nil
        response = Utilities.get_response(url)
        response.elements.each("searchResponse/SearchResults/records"){|elem| @records = elem}
        response.elements.each("searchResponse/Hits"){|elem| @total = elem.text}
      end
    else
      redirect_to :action => "search_form"
    end
  end
  
  def browse
    unless params[:db].blank? or params[:browse].blank?
      browse_url = BASE_URL.sub('ACTION',BROWSE)
      @index = params[:index].blank? ? params[:index_id] : params[:index][:id]
      text = params[:browse]
      @db = params[:db]
      browse_url+="&index=#{@index}&term=#{text}&db=#{@db}"
      response = Utilities.get_response(browse_url)
      response.elements.each("browseResponse/response/records"){|elem| @records = elem}
    else
      redirect_to :action => "search_form", :db => params[:db]
    end
  end
  
  
end
