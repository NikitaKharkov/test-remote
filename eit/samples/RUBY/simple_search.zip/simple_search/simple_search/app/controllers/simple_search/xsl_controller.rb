class SimpleSearch::XslController < ApplicationController
  require "rexml/document"
  include REXML
  
  def index
  end
  
  
  ################################### Search using REST and XSL##########################################
  
  def xsl
    db_url = BASE_URL.sub('ACTION', DATABASE)
    response = Utilities.call_api(db_url)
    response = Utilities.alter_header(response, 'display_db')
    response.sub!("xmlns=\"http://epnet.com/webservices/SearchService/Response/2007/07/\"","")
    @data = response
    render :xml => @data
  end
  
  def search_form_xml
    database = params[:db]
    db_url = BASE_URL.sub('ACTION', DATABASE)
    response = Utilities.call_api(db_url)
    
    data = "<wrapper>\n<dbSelect>#{database}</dbSelect>#{response}\n</wrapper>"
    data = Utilities.alter_header(data, 'search')
    @data = data
    render :xml => @data
  end
  
  def search_xml
    unless params[:db].blank?
      db = params[:db]
      params[:sort_id] = params[:sort]
      query = SimpleSearch.form_query(params)
      url = SimpleSearch.form_url(params, query) if query
      url_str = url
      p_start = params[:start].to_i
      start = (p_start.to_i>0) ? p_start.to_i : 1

      link = SimpleSearch.get_link(params)

      url = SimpleSearch.paginate(url_str, start)
      response = Utilities.call_api(url)
      vars = SimpleSearch.form_vars(params)

      data = "\n<wrapper>\n<dbSelect>#{db}</dbSelect>\n"+
              "<start_record>#{start}</start_record>\n"+
              "<query>#{query}</query>\n"+
              "<prev_page>#{link}&amp;start=#{start - 10}</prev_page>\n"+
              "<next_page>#{link}&amp;start=#{start + 10}</next_page>\n"+
              "#{vars}#{response}\n</wrapper>"
      data = Utilities.alter_header(data, 'results')
      @data = data
      render :xml => @data
    else
      redirect_to :action => "search_form_xml"
    end
  end
  
  def browse_xml
    unless params[:db].blank? or params[:browse].blank?
      browse_url = BASE_URL.sub('ACTION',BROWSE)
      browse = params[:browse].gsub(" ","+")
      browse_url+="&index=#{params[:index]}&term=#{browse}&db=#{params[:db]}"
      response = Utilities.call_api(browse_url)
      data = "<wrapper>\n<dbSelect>#{params[:db]}</dbSelect>\n"+
                  "<index>#{params[:index]}</index>\n#{response}\n</wrapper>"
      data = Utilities.alter_header(data, 'browse')

      @data = data
      render :xml => @data
    else
      redirect_to :action => "search_form_xml", :db => params[:db]
    end
  end
  
end
