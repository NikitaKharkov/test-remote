class SimpleSearchController < ApplicationController
  require "rexml/document"
  include REXML
  
  def index
  end
  
    
end
