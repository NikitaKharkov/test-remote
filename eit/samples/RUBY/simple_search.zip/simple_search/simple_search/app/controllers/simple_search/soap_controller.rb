class SimpleSearch::SoapController < ApplicationController
  require "rexml/document"
  include REXML
  
  def index
  end
  
  
  
  ################################### Search using SOAP and XSL ##########################################
  
  def soap
    response = Utilities.call_soap
    response = Utilities.alter_soap_header(response, 'display_db_soap')
    #response.gsub!("http://schemas.xmlsoap.org/soap/envelope/","http://www.w3.org/2003/05/soap-envelope")
    logger.debug "response = #{response}"
    #response.sub!("xmlns=\"http://epnet.com/webservices/SearchService/Response/2007/07/\"","")
    @data = response
    render :xml => @data
  end
  
  def search_form_soap
    database = params[:db]
    response = Utilities.call_soap
    
    data = "<wrapper>\n<selected>selected</selected>\n<dbSelect>#{database}</dbSelect>#{response}\n</wrapper>"
    data = Utilities.alter_soap_header(data, 'search_soap')
    
    @data = data
    render :xml => @data
  end
  
  def browse_soap
    unless params[:db].blank? or params[:browse].blank?
      browse = params[:browse] 
      vals = {:db => params[:db], :term => browse, :index => params[:index]}
      response = Utilities.browse_soap(vals)

      data = "<wrapper>\n<dbSelect>#{params[:db]}</dbSelect>\n"+
                  "<index>#{params[:index]}</index>\n#{response}\n</wrapper>"
      data = Utilities.alter_soap_header(data, 'browse_soap')
      logger.debug "data = #{data}"

      @data = data
      render :xml => @data
    else
      redirect_to :action => "search_form_soap", :db => params[:db]
    end
  end
  
  def search_soap
    db = params[:db]
    unless db.blank?
      params[:sort_id] = params[:sort]
      query = SimpleSearch.form_query_soap(params)
      url = SimpleSearch.form_url(params, query) if query
      url_str = url
      p_start = params[:start].to_i
      start = (p_start.to_i>0) ? p_start.to_i : 1

      link = SimpleSearch.get_link(params, 'soap')

      #url = SimpleSearch.paginate(url_str, start)
      #response = Utilities.call_api(url)

      vals = {:query => query, :start => start, :sort => params[:sort], :db => db}
      response = Utilities.soap_search(vals)

      vars = SimpleSearch.form_vars(params)

      data = "\n<wrapper>\n<dbSelect>#{db}</dbSelect>\n"+
              "<start_record>#{start}</start_record>\n"+
              "<query>#{query}</query>\n"+
              "<prev_page>#{link}&amp;start=#{start - 10}</prev_page>\n"+
              "<next_page>#{link}&amp;start=#{start + 10}</next_page>\n"+
              "#{vars}#{response}\n</wrapper>"
      data = Utilities.alter_soap_header(data, 'results_soap')
      logger.debug "data = #{data}"

      @data = data
      render :xml => @data
    else
      redirect_to :action => "search_form_soap"
    end
  end
  
end
