class SimpleSearch
  def self.form_query(params)
    
    full_text = params[:ft] || params[:full_text]
    db = params[:db]
    
    #search textboxes
    search_txt_1 = params[:s1] || params[:txt1]
    search_txt_2 = params[:s2] || params[:txt2]
    search_txt_3 = params[:s3] || params[:txt3]
    search_txt_4 = params[:s4] || params[:txt4]
    
    #tags
    tag_1 = params[:t1] || params[:tag1][:id]
    tag_2 = params[:t2] || params[:tag2][:id]
    tag_3 = params[:t3] || params[:tag3][:id]
    tag_4 = params[:t4] || params[:tag4][:id]
    
    #operators
    opr_1 = params[:d1] || params[:operator1][:id]
    opr_2 = params[:d2] || params[:operator2][:id]
    opr_3 = params[:d3] || params[:operator3][:id]
    
    RAILS_DEFAULT_LOGGER.debug "full_text = #{full_text} | db=#{db} | search_txt_1=#{search_txt_1} | tag_1=#{tag_1} | opr_1=#{opr_1}"
    
    # No search terms, go back to select DB
    if((search_txt_1.blank? && search_txt_2.blank? && search_txt_3.blank? && search_txt_4.blank?) || db.blank?) 
        return nil
    end

    #Query Build Algorithm
    #if the term to be searched is not null check for the Tag of the catergory else keep it null
    search_txt_1.gsub!(" ", "+")
    search_txt_1 = !search_txt_1.blank? ? ("(#{tag_1}" + (!tag_1.blank? ? '+(' : '') + "#{search_txt_1})" + (!tag_1.blank? ? ')' : '')) : ""
    
    search_txt_2.gsub!(" ", "+")
    search_txt_2 = !search_txt_2.blank? ? ("(#{tag_2}" + (!tag_2.blank? ? '+(' : '') + "#{search_txt_2})" + (!tag_2.blank? ? ')' : '')) : ""
    
    search_txt_3.gsub!(" ", "+")
    search_txt_3 = !search_txt_3.blank? ? ("(#{tag_3}" + (!tag_3.blank? ? '+(' : '') + "#{search_txt_3})" + (!tag_3.blank? ? ')' : '')) : ""
    
    search_txt_4.gsub!(" ", "+")
    search_txt_4 = !search_txt_4.blank? ? ("(#{tag_4}" + (!tag_4.blank? ? '+(' : '') + "#{search_txt_4})" + (!tag_4.blank? ? ')' : '')) : ""

    #if trem to be searched is not null append database name
   # query = search_txt_1 + ((!search_txt_2.blank?) ? ('+' + opr_1 + '+') : "") +
   #         search_txt_2 + ((!search_txt_3.blank?) ? ('+' + opr_2 + '+') : "") +
   #         search_txt_3 + ((!search_txt_4.blank?) ? ('+' + opr_3 + '+') : "") + 
   #         search_txt_4
  
   

   # NEW QUERY ALGORITHM     
    query = ''   
    
    query+=search_txt_1  unless search_txt_1.blank?
    
    if !search_txt_2.blank? and !query.blank?
      query += "+#{opr_1}+#{search_txt_2}"
    else
      query += search_txt_2
    end
    
    if !search_txt_3.blank? and !query.blank?
      query += "+#{opr_2}+#{search_txt_3}"
    else
      query += search_txt_3
    end

    if !search_txt_4.blank? and !query.blank?
      query += "+#{opr_3}+#{search_txt_4}"
    else
      query += search_txt_4
    end
    
    RAILS_DEFAULT_LOGGER.debug "intermidiate query = #{query}"

    #format query with brackets and check for full text display     
    query.gsub!(")(", ")+AND+(") 
    if  query !~ /\+AND\+FT\+Y/ && full_text == "1"
        query += '+AND+FT+Y'
    end
    
    query
  end
  
  
  
  def self.form_url(params, query)
    sort = params[:sort_id] || params[:sort][:id]
    search_url = BASE_URL.sub('ACTION', SEARCH)
    search_url + "&query=#{query}&db=#{params[:db]}&sort=#{sort}"
  end
  
  def self.paginate(url,page_start)
    "#{url}&startrec=#{page_start}"
  end
  
  def self.get_link(params, type='xml')
    "search_#{type}?format=xml&amp;db=#{params[:db]}&amp;sort=#{params[:sort]}&amp;s1=#{params[:s1]}"+
    "&amp;s2=#{params[:s2]}&amp;s3=#{params[:s3]}&amp;s4=#{params[:s4]}"+
    "&amp;t1=#{params[:t1]}&amp;t2=#{params[:t2]}&amp;t3=#{params[:t3]}"+
    "&amp;t4=#{params[:t4]}&amp;d1=#{params[:d1]}&amp;d2=#{params[:d2]}"+
    "&amp;d3=#{params[:d3]}&amp;ft=#{params[:ft]}"
  end
  
  #
  #Difference between this method and form_query method
  #In form_query --> + is used to append strings in query
  #In form_query_soap --> space is used to append strings in query
  #Because of such subtle difference they are kept as different methods to not miss the difference
  #
  def self.form_query_soap(params)
    full_text = params[:ft] || params[:full_text]
    db = params[:db]
    
    #search textboxes
    search_txt_1 = params[:s1] || params[:txt1]
    search_txt_2 = params[:s2] || params[:txt2]
    search_txt_3 = params[:s3] || params[:txt3]
    search_txt_4 = params[:s4] || params[:txt4]
    
    #tags
    tag_1 = params[:t1] || params[:tag1][:id]
    tag_2 = params[:t2] || params[:tag2][:id]
    tag_3 = params[:t3] || params[:tag3][:id]
    tag_4 = params[:t4] || params[:tag4][:id]
    
    #operators
    opr_1 = params[:d1] || params[:operator1][:id]
    opr_2 = params[:d2] || params[:operator2][:id]
    opr_3 = params[:d3] || params[:operator3][:id]
    
    # No search terms, go back to select DB
    if((search_txt_1.blank? && search_txt_2.blank? && search_txt_3.blank? && search_txt_4.blank?) || db.blank?) 
        return nil
    end

    #Query Build Algorithm
    #if the term to be searched is not null check for the Tag of the catergory else keep it null
    
    search_txt_1 = !search_txt_1.blank? ? ("(#{tag_1}" + (!tag_1.blank? ? ' (' : '') + "#{search_txt_1})" + (!tag_1.blank? ? ')' : '')) : ""
    search_txt_2 = !search_txt_2.blank? ? ("(#{tag_2}" + (!tag_2.blank? ? ' (' : '') + "#{search_txt_2})" + (!tag_2.blank? ? ')' : '')) : ""
    search_txt_3 = !search_txt_3.blank? ? ("(#{tag_3}" + (!tag_3.blank? ? ' (' : '') + "#{search_txt_3})" + (!tag_3.blank? ? ')' : '')) : ""
    search_txt_4 = !search_txt_4.blank? ? ("(#{tag_4}" + (!tag_4.blank? ? ' (' : '') + "#{search_txt_4})" + (!tag_4.blank? ? ')' : '')) : ""
          
    # NEW QUERY ALGORITHM     
    query = ''   
    
    query+=search_txt_1  unless search_txt_1.blank?
    
    if !search_txt_2.blank? and !query.blank?
      query += "+#{opr_1}+#{search_txt_2}"
    else
      query += search_txt_2
    end
    
    if !search_txt_3.blank? and !query.blank?
      query += "+#{opr_2}+#{search_txt_3}"
    else
      query += search_txt_3
    end

    if !search_txt_4.blank? and !query.blank?
      query += "+#{opr_3}+#{search_txt_4}"
    else
      query += search_txt_4
    end
    
    RAILS_DEFAULT_LOGGER.debug "intermidiate query = #{query}"

    #format query with brackets and check for full text display     
    if  query !~ /\ AND\ FT\ Y/ && full_text == "1"
        query += ' AND FT Y'
    end
    
    query
  end
  
  def self.form_vars(params)
    vars = ""

    vars += "<s1>#{params[:s1]}</s1>\n" if params[:s1]
    vars += "<s2>#{params[:s2]}</s2>\n" if params[:s2]
    vars += "<s3>#{params[:s3]}</s3>\n" if params[:s3]
    vars += "<s4>#{params[:s4]}</s4>\n" if params[:s4]

    vars += "<d1>#{params[:d1]}</d1>\n" if params[:d1]
    vars += "<d2>#{params[:d2]}</d2>\n" if params[:d2]
    vars += "<d3>#{params[:d3]}</d3>\n" if params[:d3]

    vars += "<t1>#{params[:t1]}</t1>\n" if params[:t1]
    vars += "<t2>#{params[:t2]}</t2>\n" if params[:t2]
    vars += "<t3>#{params[:t3]}</t3>\n" if params[:t3]
    vars += "<t4>#{params[:t4]}</t4>\n" if params[:t4]

    vars += "<sort>#{params[:sort]}</sort>\n" if params[:sort]
    vars += "<ft>#{params[:ft]}</ft>\n" if params[:ft]
    
    vars
  end
end