module SimpleSearchHelper
  

  def get_indices(db_data)
    index_arr = []
    if db_data and db_data.elements
      db_data.elements.each("dbIndices/dbIndex "){|elem| index_arr << [elem.attributes["description"], elem.attributes["name"]]}
    end
    index_arr
  end
  
  def get_tags(db_data)
    tag_arr = []
    if db_data and db_data.elements
      db_data.elements.each("dbTags/dbTag "){|elem| tag_arr << [elem.attributes["description"], elem.attributes["name"]]}
    end
    tag_arr
  end
  
  def get_booleans
    {"AND" => "AND", "OR" => "OR", "NOT" => "NOT"}
  end
  
  def get_sort_options(db_data)
    sort_arr = []
    if db_data and db_data.elements
      db_data.elements.each("sortOptions/sort"){|elem| sort_arr << [elem.attributes["name"],elem.attributes["id"]]}
    end
    sort_arr
  end
  
  def prev_page_start
    if(@page_start > 10)
      return @page_start-10
    else
      return nil
    end
  end
  
  def next_page_start
    if(@page_start < (@total - 9))
      return @page_start + 10
    else
      return nil
    end
  end
  
  def top_result
    top_result = @page_start + 9
    top_result = @total if(top_result > @total)
    top_result
  end
  
  def get_attrs(record)
    result = {}
    record.elements.each("plink") { |elem| result['link'] = elem.text}

    record.elements.each("header") do |elem| 
      record_control = nil
      record_artinfo = nil
      elem.elements.each("controlInfo"){|element| record_control = element}
      record_control.elements.each("artinfo"){|element| record_artinfo = element}
      begin
        by_str = 'By: '
        record_artinfo.elements.each("aug/au"){|rec| by_str += "#{rec.text};"}
        jtl = ''
        dt = ''
        record_control.elements.each("jinfo/jtl"){|elem| jtl = elem.text}
        record_control.elements.each("pubinfo/dt"){|elem| dt = elem.text}
        by_str += "#{jtl}, #{dt}"
      rescue
        by_str = ''
      end  
      result['by_str'] = by_str
      record_artinfo.elements.each("tig/atl"){|elem| result['link_str'] = elem.text}
      subjects = []
      record_artinfo.elements.each("su"){|elem| subjects << elem.text}
      result['subjects'] = subjects.join(', ')
    end
   
    result
  end
  
end
