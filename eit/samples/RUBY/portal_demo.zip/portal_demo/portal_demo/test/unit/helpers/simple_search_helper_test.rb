require 'test_helper'

class SimpleSearchHelperTest < ActionView::TestCase
end
