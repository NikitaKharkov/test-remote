class PortalDemo
  
  def self.xml_header(file)
    # We do not need to connect to the server.  We simply just
      # put out XML headers, and use the default XSL stylesheet.

      # index.xsl is the portal stylesheet.
      #xml_header('search.xsl');
      
      #xml = ''
      #xml+= "<?xml version='1.0' encoding='UTF-8'?>\n"
      #xml+= "<?xml-stylesheet type='text/xsl' href=\"search_portal.xsl\"?>\n"
      xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<?xml-stylesheet type=\"text/xsl\" href=\"/portal_demo/#{file}.xsl\"?>\n"
      xml+= "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n"
      xml+= '<wrapper>'
      xml+= '<no_data>Please Enter a term to see the Search Results</no_data>'
      xml+= '</wrapper>'
      xml
      
    
  end
  
  def self.form_query_info(params)
    return_hash = {}
    return_hash[:start] = params["start"] ? params["start"] : 1
      
    # Get the unformatted query string
    query_unformatted = params['query']

    # Force a full-text only search result
    #if (!preg_match('/ AND FT Y/', $query_unformatted))
    query = nil
    if query_unformatted !~ / AND FT Y/
        query = query_unformatted + ' AND FT Y'
    else
        query = query_unformatted.clone
    end

    # Replace all spaces with plus signs.
    query.gsub!(" ","+")

    # Insert parenthesis if they are not already in the string.  Checking the
    # first and last characters.
    if query_unformatted.start_with?('(') and query_unformatted.end_with?(')')
      query = "(#{query})"
    else
      query='('+query unless query.start_with?('(')  
      query+=')' unless query.end_with?(')')  
    end
    

    return_hash[:query_unformatted] = query_unformatted
    return_hash[:query] = query
    
    return_hash
  end
  
  def self.form_xml(query_hash, search_response, cluster_response)
    
    start = query_hash[:start].to_i
    query = query_hash[:query].clone
    
    xml = "<?xml version='1.0' encoding='UTF-8'?>\n"+
            "<?xml-stylesheet type='text/xsl' href=\"search_portal.xsl\"?>\n"+
            "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n"
  
     
    xml+= "<wrapper>\n"
    
    # The "query_original" field is used to display the original query in the search box.
    xml+= "<query_original>#{query_hash[:query_original]}</query_original>\n"
    
    # This holds the actual formatted query
    xml+= "<query>#{query}</query>\n"
    
    # Lowest and highest record number
    xml+= "<min>#{start}</min>\n"
    xml+= "<max>#{start.to_i+9}</max>\n"
    
    # Output Breadcrumbs.  This function returns the breadcrumbs in an
    # associative array.
    breadcrumbs = breadcrumbs(query)
    
    xml+= "<breadcrumbs>\n"
    breadcrum_hash = {}
    breadcrumbs.each do |bc|
       xml+= "\t<bc name='#{bc[0]}'>#{bc[1]}</bc>\n"
       breadcrum_hash[bc[0]] = bc[1]
    end 
    
    xml+= "</breadcrumbs>\n"
    
    # If there were no hits, we do not need to search for subject clusters.
    if (query_hash[:num_hits].to_i > 0) 
      # Exlude subjects already in breadcrumbs.
      subjects = subject_clusters(query, start, breadcrum_hash, DEFAULT_DB);

      # Print out the subject terms for the "Narrow Search" section.
      xml+= "<eit_subjects>\n"
      
      subjects.each do |term|
        xml+= "\t<eit_subject>#{term}</eit_subject>\n"
      end
      xml+= "</eit_subjects>\n"
    end
    
    # Print out the XML search results returned from the web service.
    xml+= search_response
    xml+= cluster_response
    
    
    xml+= '</wrapper>'
    xml
  
  end
  
        
  def self.breadcrumbs(query)
    
    return_arr = []

    # Output the breadcrumbs into $breadcrumbs array
    breadcrumbs = query.split(")+AND+(")
    
    # Counter to keep track of which breadcrumb is being processed.
    item = 0
    
    #for each (breadcrumbs as $breadcrumb) {
    breadcrumbs.each do |breadcrumb|
      
      item+=1;

      # Make Breadcrumbs Readable with replacing the standards
      breadcrumb.gsub!("+"," ")
      breadcrumb.gsub!("(","")
      breadcrumb.gsub!(")","")
      breadcrumb.gsub!("+AND+FT+Y","")
      breadcrumb.gsub!(" AND FT Y"," ")
      breadcrumb.strip!
      
      # This is the query string.  Each breadcrumb will have its own query string.
      temp_query = ''

      # This loop builds the query up.  For the first breadcrumb, it will
      # only include the first query.  For the second breadcrumb, it will
      # include the first and second, etc.
        
      for i in 0...item   
        temp_query += breadcrumbs[i]
        temp_query += ')+AND+(' if (i != (item - 1))
      end

      # If the last character is not a parenthesis, append one
      # onto the query.
      #unless (query.start_with?('(') and query.end_with?(')'))
        temp_query+=')' unless temp_query.end_with?(')')
        temp_query='('+temp_query unless temp_query.start_with?('(')
      #end

      #trim the extra information of the cluster tags
      breadcrumb = breadcrumb.slice(3,breadcrumb.length) if item>1
      return_arr << [breadcrumb, temp_query]
    end
    return_arr
  end
  
  def self.subject_clusters(query, start, exclude, db)
    
    start_record = start - 25
    start_record = (start_record < 1) ? (24 - (25 - start)) : (25)
    
    # Force a full-text only search result if it is checked
    query += ' AND FT Y' if query =~ / AND FT Y/
      
    
    #Encrypt the query according to standards by replacing space by +
    query.gsub!(" ","+")
    
    # Retrieve the XML search file from the EIT Search Service.  See 'function curl_get()'
    # below for more details.
    clust_url = PORTAL_BASE_URL.sub("ACTION", "Search")
    url = clust_url+"&db=#{db}&query=#{query}&startrec=#{start-start_record}&numrec=50"
    
    response = Utilities.call_api(url)
    
    #$subject_clusters = preg_match_all('/<subj type="thes">(.+?)<\/subj>/', $xml, $subjects);
    subjects = []
    response.scan(/<subj type="thes">(.+?)<\/subj>/){|match| subjects << match}
    
    count = {}
    return_ar = []
    subjects.each do |subject|
      subject = subject[0]
      
      #count[subject] = 0 if count[subject].blank?
        
      # Set the subject to -1 if it is in the exclude list.  Otherwise, increment.
      
      if exclude[subject].blank? and exclude[subject.downcase].blank?
        if count[subject].blank?
        count[subject ] = 1
        else  
          count[subject ] += 1
        end  
      end
      
    end
    
    #arsort($count);
    count = count.sort {|key,val| val[1] <=> key[1]}
    
    i = 0
    #foreach ($count as $subject => $number) {
    count.each do |subject|
        break if i >= 10
       
        i+=1
	
        # Trim any extra information off of the end of the subject, and replace
        # any ampersands with &amp;
        subject_trimmed = subject[0].split('(')[0]
        
        # Trim any ampersands out of subjects, these cause problems with the HTML 
        subject_trimmed.gsub!("&amp;","")
        
        #return_ar[i] = subject_trimmed
        return_ar << subject_trimmed
    end
    return_ar
  end
  
  
end