class PortalDemoController < ApplicationController
  def test
    redirect_to :action => "index", :format => "xml"
  end
  
  def index
    xml_data = ''
    if params['query'].blank?
	  params['query'] = 'global warming'
	end
      #xml_data = PortalDemo.xml_header('search_portal')
    #else
      query_hash = PortalDemo.form_query_info(params)
      query = query_hash[:query]
      search_url = PORTAL_BASE_URL.sub('ACTION', SEARCH)
      
      search_url+="&db=#{DEFAULT_DB}&query=#{query}&startrec=#{query_hash[:start]}"
      search_response = Utilities.call_api(search_url)
      
      cluster_url = PORTAL_BASE_URL.sub('ACTION', CLUSTERS)
      cluster_url+="&db=#{DEFAULT_DB}&query=#{query}"
      cluster_response = Utilities.call_api(cluster_url)
      
      
      # Get rid of the default XML version information
      search_response.gsub!("<?xml version=\"1.0\"?>","")
      cluster_response.gsub!("<?xml version=\"1.0\"?>","")
      
      match = search_response.match(/<Hits xmlns=\"http:\/\/epnet.com\/webservices\/SearchService\/Response\/2007\/07\/\">(.+?)<\/Hits>/)
      query_hash[:num_hits] = match[1]
      
      #if (!isset($_GET["qo"]))
      unless params["qo"].blank?  
          query_hash[:query_original] = query_hash[:query_unformatted]
      else
          query_hash[:query_original] = params["qo"]
      end
      
      xml_data = PortalDemo.form_xml(query_hash, search_response, cluster_response)
      
   

    
    #end #params blank if ends here
      
    @data = xml_data
    render :xml => @data
      
  end
  
  def get_rss
    
    response = Utilities.call_api(RSS_URL)
    logger.debug "-------------------response = #{response}"
    response.gsub!("<?xml version=\"1.0\" encoding=\"utf-8\"?>","")
    response.gsub!(/<rss(.*?)>/,"<ep_feed>")
    response.gsub!(/<\/rss>/,"</ep_feed>")
    response.gsub!(/<description>(.*?)<\/description>/,"<description></description>")
    
    header =  "<?xml version='1.0' encoding='UTF-8'?>\n"
    header+= "<?xml-stylesheet type='text/xsl' href='rss_portal.xsl'?>\n"
    header+= "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n"
    
    response = header + response
    
    @data = response
    render :xml => @data
    
#    render :nothing => true
    
  end
end