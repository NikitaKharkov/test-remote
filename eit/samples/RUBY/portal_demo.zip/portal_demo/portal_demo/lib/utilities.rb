class Utilities
  require "rexml/document"
  require 'savon'
  require 'rubygems'
  

  include REXML
  
  def self.call_api(url)
    RAILS_DEFAULT_LOGGER.debug "Before curl url = #{url}"
    `curl #{url}`
  end
  
  def self.parse_response(url)
    response_str = call_api(url) 
    Document.new response_str
  end
  
  def self.get_response(url)
    parse_response(url)
  end
  
  def self.alter_header(data, file)
    data.sub!("<?xml version=\"1.0\"?>", "")
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<?xml-stylesheet type=\"text/xsl\" href=\"#{file}.xsl\"?>\n"+data
  end
  
  def self.alter_soap_header(data, file)
    data.sub!("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "")
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<?xml-stylesheet type=\"text/xsl\" href=\"#{file}.xsl\"?>\n"+data
  end
  
  
  def self.call_soap
    #url = "http://eit.ebscohost.com/Services/SearchService.asmx?WSDL"
    client ||= Savon::Client.new(SOAP_WSDL)
    
    actions = client.wsdl.soap_actions
    RAILS_DEFAULT_LOGGER.debug "actions = #{actions.inspect}"
    
     response = client.request(:info) do |soap|
      soap.header = {
                      "auth:AuthorizationHeader" => {"auth:Profile" => "webdes.eit.bbates", "auth:Password" => "ebsco"},
                      :attributes! => {"auth:AuthorizationHeader" => 
                                          { "xmlns:auth" => 'http://epnet.com/webservices/SearchService/2007/07/'
                                             } } }
      soap.body = {
                    :attributes! => {"eit:Info" => {"xmlns:eit" => "http://epnet.com/webservices/SearchService/2007/07/"}}}
    end

    xml_res = response.to_xml
    RAILS_DEFAULT_LOGGER.debug "xml_res class = #{xml_res.class}"
    xml_res
  end
  
  def self.browse_soap(vals)
    #url = "http://eit.ebscohost.com/Services/SearchService.asmx?WSDL"
    client ||= Savon::Client.new(SOAP_WSDL)
    
    actions = client.wsdl.soap_actions
    RAILS_DEFAULT_LOGGER.debug "actions = #{actions.inspect}"
    
     response = client.request(:browse) do |soap|
      soap.header = {
                      "auth:AuthorizationHeader" => {"auth:Profile" => "webdes.eit.bbates", "auth:Password" => "ebsco"},
                      :attributes! => {"auth:AuthorizationHeader" => 
                                          { "xmlns:auth" => 'http://epnet.com/webservices/SearchService/2007/07/'}
                                      } 
                    }
      soap.body = { "ins1:browseRequest" => {"ins1:Term" => vals[:term], "ins1:Index" => vals[:index], "ins1:Databases" => vals[:db]},
                                          :attributes! => 
                                            {"ins1:Browse" => {"xmlns:eit" => "http://epnet.com/webservices/SearchService/2007/07/"}}}
    end

    xml_res = response.to_xml
    #RAILS_DEFAULT_LOGGER.debug "xml_res class = #{xml_res}"
    xml_res
  end
  
  def self.soap_search(vals)
    #url = "http://eit.ebscohost.com/Services/SearchService.asmx?WSDL"
    client ||= Savon::Client.new(SOAP_WSDL)
    
    actions = client.wsdl.soap_actions
    RAILS_DEFAULT_LOGGER.debug "actions = #{actions.inspect}"
    
     response = client.request(:search) do |soap|
      soap.header = {
                      "auth:AuthorizationHeader" => {"auth:Profile" => "webdes.eit.bbates", "auth:Password" => "ebsco"},
                      :attributes! => {"auth:AuthorizationHeader" => 
                                          { "xmlns:auth" => 'http://epnet.com/webservices/SearchService/2007/07/'}
                                      } 
                    }
      soap.body = { "ins1:searchRequest" => {"ins1:Query" => vals[:query], "ins1:Databases" => vals[:db], "ins1:StartingRecordNumber" => vals[:start],
                                              "ins1:NumberRecordsReturned" => 10, "ins1:Sort" => vals[:sort]},
                                          :attributes! => 
                                            {"ins1:Search" => {"xmlns:eit" => "http://epnet.com/webservices/SearchService/2007/07/"}}}
    end

    xml_res = response.to_xml
    xml_res
    
  end


end