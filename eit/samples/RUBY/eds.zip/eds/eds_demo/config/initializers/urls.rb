# Web services account ID and password.  Account will be used to authenticate each request to the web services API.  
# Accounts are created and maintained in ESBCOadmin.  If you do not have a web services account, 
# Contact your EBSCO Account Manager who can create one for you.
PROFILE = ""
PWD = ""

#URLS and other constants used in application
EDS_BASE_URL = "http://eit.ebscohost.com/Services/SearchService.asmx/ACTION?prof=#{PROFILE}&pwd=#{PWD}"
RSS_URL = "http://rss.ebscohost.com/AlertSyndicationService/Syndication.asmx/GetFeed?guid=2574264"
SOAP_WSDL = "http://eit.ebscohost.com/Services/SearchService.asmx?WSDL"
BROWSE = "Browse"
DATABASE = "Info"
SEARCH = "Search"
CLUSTERS = "GetClusters"
DEFAULT_DB = "a9h"