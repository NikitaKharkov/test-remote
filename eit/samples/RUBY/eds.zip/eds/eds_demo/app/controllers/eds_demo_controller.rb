class EdsDemoController < ApplicationController
  def index
    
  end
  
  def search
    if (!params[:query].blank? or !params[:s1].blank? or !params[:s2].blank? or !params[:s3].blank?)
      xml = EdsDemo.eds(params)
      @data = xml
      render :xml => @data
    else
      redirect_to :action => "index"
    end
  end
end
