class EdsDemo
  
  def self.eds(params)
    vars, query, query_dis = form_var_hash(params)
    #query_o = vars["query"]
    
    
    # Initialize the starting position of the records in the XML returned from the web services API.
    # If the starting position parameter doesn't exist, set it to 1
    vars[:start] = params[:start].blank? ? 1 : params[:start].to_i
    
    return_hash = form_url(vars,query,query_dis)
    url_str = return_hash[:url_str]
    response = call_service(url_str)
    #RAILS_DEFAULT_LOGGER.debug "response = #{response}"
    
    cluster_url = EDS_BASE_URL.sub('ACTION', "GetClusters")
    cluster_url+="&query=#{return_hash[:query]} "
    cluster_response = Utilities.call_api(cluster_url)
    return_hash[:cluster_response] = cluster_response
    
    res_hash = Hash.from_xml(response)
    hits = res_hash["search_response"]["hits"].to_i rescue 0
    res_hash["search_response"]["statistics"]["statistic"].each{|statistic|  hits+=statistic["hits"].to_i}
    record_count = res_hash["search_response"]["search_results"]["records"]["rec"].length rescue 0
    next_page_start = vars[:start] + 10
    prev_page_start = vars[:start] - 10
    return_hash[:hits] = hits
    return_hash[:record_count] = record_count
    return_hash[:next_page_start] = next_page_start
    return_hash[:prev_page_start] = prev_page_start
    #return_hash[:start] = params[:start].blank? ? 1 : params[:start]
    return_hash[:query_o] = vars["query"]
    
    return_hash[:page] = params['page']
    return_hash[:sort] = params['sort']
    
    
    xml = form_xml(return_hash, response)
    
  end
  
  def self.form_var_hash(params)
    vars = {}
    
    
    vars["sort"] 	= params[:sort]
    vars["query"] 	= params[:query]
    vars["full_text"] 	= params[:ft]
    vars["scholarly"]	= params[:sch]
    vars["from_year"]	= params[:from_year]
    vars["from_month"]	= params[:from_month]
    vars["to_year"]	= params[:to_year]
    vars["to_month"]	= params[:to_month]
    vars["pubtype"]	= params[:pubtype]
    vars["searchfield"] = params[:searchfield]
    vars["advset"] = params[:advset]
    
    vars["s1"]	= params[:s1]
    vars["t1"]	= params[:t1]
    vars["d1"]	= params[:d1]
    vars["s2"] = params[:s2]
    vars["t2"]	= params[:t2]
    vars["d2"]	= params[:d2]
    vars["s3"]	= params[:s3]
    vars["t3"] = params[:t3]
    
    
    query = vars["query"].clone
    query_dis = vars["query"].clone
    
    
     if (vars["searchfield"] != "keyword")
       if (vars["searchfield"] == "author")
         vars["s1"] = query
         vars["t1"] = "AU"
         query = ""
       elsif (vars["searchfield"] == "title")
         vars["s1"] = query
         vars["t1"] = "TI"
         query = ""
       end
     end
     
    RAILS_DEFAULT_LOGGER.debug "befire returning in for vars hash query = #{query}"
    [vars, query, query_dis]
  end
  
  def self.form_url(vars, query, query_dis)
    unless query.blank?
       #Format the Query using the limiters above.
      query = vars["query"].clone
      query_o = vars["query"].clone
      query_dis = vars["query"].clone

      RAILS_DEFAULT_LOGGER.debug "vars['query'] = #{vars['query']}/query=#{query}/query_dis=#{query_dis}"

      # Remove preceding and trailing blank space
      query.strip!

      #Encode any blank spaces within the query string.  Should be done as a best practice.  
      query.gsub!(" ", "+")

      #Initialize limiter variable.  xml_vars holds the limiters which will be passed to
      # the XSLT stylesheet via XML
      xml_vars = ''

      # Add left and right parenthesis around the query string.  This will ensure the search criteria is
      # properly bounded in the query string
      

      # User has indicated, via the Search Options screen, that the search must include 
      # articles containing Full Text
      unless vars["full_text"].blank?
        # append to the query, the FT field code and set to a value of Y
        query += "+AND+(FT+Y)"
        xml_vars += "<ft ft=\"on\" />\n"
      end

      # User has indicated, via the Search Options screen, that the search must include 
      # Scholarly (Peer Reviewed) Journals
      unless vars["scholarly"].blank?
        # append to the query, the RV field code and set to a value of Y
        query += "+AND+(RV+Y)";
        xml_vars += "<sch sch=\"on\" />\n"
      end

      if (vars["pubtype"] == "all") 
          xml_vars += "<pubtype>all</pubtype>\n"
      elsif (vars["pubtype"] == "books")
          xml_vars += "<pubtype>books</pubtype>\n"
          query += "+AND+(PT+book)"
      elsif (vars["pubtype"] == "articles")
          xml_vars += "<pubtype>articles</pubtype>\n"
          query += "+AND+(ZT+article)"
      end
      
      # User has chosen to specify From and/or To dates to narrow the scope of the search.  
      if (!vars["from_year"].blank? || !vars["to_year"].blank?)
          # preface From and/or To date with DT field code
          query += "+AND+(DT+"

          if (vars["from_year"])
              # append From date to query string
              query += vars["from_year"] + vars["from_month"]
              xml_vars += "<from_year>" + vars["from_year"] + "</from_year>\n"
              xml_vars += "<from_month>" + vars["from_month"] + "</from_month>\n"
          end
          
          query += '-'

          unless vars["to_year"].blank?
              # append To date to query string
              query += vars["to_year"] + vars["to_month"]
              xml_vars += "<to_year>" + vars["to_year"] + "</to_year>\n"
              xml_vars += "<to_month>" + vars["to_month"] + "</to_month>\n"
          end
          
          # close the date parenthesis in order to properly bound the date parameters 
          query += ')'

      end
    
    end
    
    # Compose the full EBSCOhost web services API URL
    # Number of records to return is defaulted to 10.  
    # Valid values 1 to 200
    # When specifying format = Full (as opposed to Brief, Detailed), maximum records returned is capped 50
    ## eITServiceURL = BASE_URL + 
    
    #query+=')' unless query.end_with?(')')
    RAILS_DEFAULT_LOGGER.debug "befire start with query = #{query}"
    unless query.blank?
      if(vars["query"].start_with?('(') and vars["query"].end_with?(')'))
        #query = "(#{query})"
      else
        query = '('+query unless query.start_with?('(')
        query+=')' unless query.end_with?(')')
      end 
    end
    
    RAILS_DEFAULT_LOGGER.debug "before calling form_xml_vars_and_query query = #{query}"
    return_hash = form_xml_vars_and_query(vars, query)
    #query += ')' unless query.end_with?(')')
    RAILS_DEFAULT_LOGGER.debug "vars['sort'] = #{vars['sort']}"
    RAILS_DEFAULT_LOGGER.debug "return_hash = #{return_hash.inspect}"
    url_str = "&query=#{return_hash[:query]}&sort=#{vars['sort']}&startrec=#{vars[:start]}&numrec=10"
    return_hash[:url_str] = url_str
    
    #{:url_str => url_str, :query => query, :xml_vars => xml_vars, :query_disp => query_disp}
    return_hash
  end
  
  def self.form_xml_vars_and_query(vars, query)
    xml_vars = ''
    
    s1=vars["s1"]
    xml_vars += "<s1>#{s1}</s1>\n" unless s1.blank?
    
    t1=vars["t1"]
    xml_vars += "<t1>#{t1}</t1>\n" unless t1.blank?

    d1=vars["d1"]
    xml_vars += "<d1>#{d1}</d1>\n" unless d1.blank?

    s2=vars["s2"]
    xml_vars += "<s2>#{s2}</s2>\n" unless s2.blank?
    
    t2=vars["t2"]
    xml_vars += "<t2>#{t2}</t2>\n" unless t2.blank?

    d2=vars["d2"]
    xml_vars += "<d2>#{d2}</d2>\n" unless d2.blank?
    
    s3=vars["s3"]
    xml_vars += "<s3>#{s3}</s3>\n" unless s3.blank?
    
    t3=vars["t3"]
    xml_vars += "<t3>#{t3}</t3>\n" unless t3.blank?

    # Query Build Algorithm
    #if the term to be searched is not null check for the Tag of the catergory else keep it null

    s1.gsub!(" ","+")
    s1 = !s1.blank? ? ('(' + t1 + (!t1.blank? ? '+(' : '') + s1 + ')' + (!t1.blank? ? ')' : '')) : ''

    s2.gsub!(" ","+")
    s2 = !s2.blank? ? ('(' + t2 + (!t2.blank? ? '+(' : '') + s2 + ')' + (!t2.blank? ? ')' : '')) : ''

    s3.gsub!(" ","+")
    s3 = !s3.blank? ? ('(' + t3 + (!t3.blank? ? '+(' : '') + s3 + ')' + (!t3.blank? ? ')' : '')) : ''
  
    query_adv=''
    #if trem to be searched is not null append database name
    if vars["advset"].blank?

      query_adv=''

      query_adv+=s1 unless s1.blank?

      if(!s2.blank? and !query_adv.blank?) 
        query_adv+="+#{d1}+#{s2}"
      else
        query_adv+=s2
      end
      
      if(!s3.blank? and !query_adv.blank?) 
        query_adv+="+#{d2}+#{s3}"
      else
        query_adv+=s3
      end

    end
    RAILS_DEFAULT_LOGGER.debug "after calc query_adv = #{query_adv}"
    RAILS_DEFAULT_LOGGER.debug "after calc query = #{query}"
    
    if (query.blank? and s1.blank? and s2.blank? and s3.blank?)
      return nil
    end
    if (!query.blank?)
      query += "+AND+#{query_adv}" if(!query_adv.blank?)
    elsif(!query_adv.blank? and query.blank?)
            query=query_adv
            query_o=query_adv
    else 
            #die(header("Location: index.php"));
            return nil
    end
    
    rtbrac = query.count('(')
    lfbrac = query.count(')')
    if(lfbrac > rtbrac) 
      query = query.slice(0,query.length-1)
    end
    RAILS_DEFAULT_LOGGER.debug "query = #{query}"
    return_hash = {:query => query, :xml_vars => xml_vars, :query_o => query_o, :query_adv => query_adv}
    RAILS_DEFAULT_LOGGER.debug "before returning return_hash = #{return_hash.inspect}"
    
    return_hash 

  end
  
  def self.call_service(url_str)
    eds_search_url = EDS_BASE_URL.sub('ACTION',SEARCH)
    eds_search_url+=url_str
    Utilities.call_api(eds_search_url)
  end
  
  def self.form_xml(return_hash, response)
    RAILS_DEFAULT_LOGGER.debug "return_hash = #{return_hash.inspect}"
    query = return_hash[:query]
    xml = "<?xml version='1.0' encoding='UTF-8'?>\n"+
          "<?xml-stylesheet type='text/xsl' href='search_eds.xsl'?>\n"+
          "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n"+
          "<wrapper>\n"+
          "<query_req>#{query}</query_req>\n"+
          "<query_adv>#{return_hash[:query_adv]}</query_adv>\n"+
          "<query>#{query}</query>\n"+
          "<prevpage>#{return_hash[:next_page_start]}</prevpage>\n"+
          "<hits>#{return_hash[:hits]}</hits>\n"
        
    # if not hits found then specify noresults as true with value 1 or if found set to false with value 0
    unless return_hash[:hits]
        xml+= "<noresults>1</noresults>"
    else
        xml+= "<noresults>0</noresults>"
    end    

    # if number of records is greater than 10 specify the start of next page    
    if ((return_hash[:record_count]) < 10) 
        xml+= "<nextpage>0</nextpage>\n"
    else
        xml+= "<nextpage>#{return_hash[:next_page_start]}</nextpage>\n"
    end
    
    # specify total count of records found
    xml+= "<totalrecs>#{return_hash[:record_count]}</totalrecs>\n"+
    # specify start for the current page
    "<thispage>#{return_hash[:start]}</thispage>\n"+
    "<page>#{(!return_hash[:page] ? 1 : return_hash[:page])}</page>\n"+
    "<sort>#{return_hash[:sort]}</sort>\n"

    # Output the variables for the XSL stylesheet.
    xml+= return_hash[:xml_vars]

    # Output the results from the EBSCOhost Search.
    #echo str_replace('<?xml version="1.0"?>', '', $XMLdata->saveXML());
    xml+= response.sub!("<?xml version=\"1.0\"?>", "")
    xml+= return_hash[:cluster_response].sub!("<?xml version=\"1.0\"?>", "")
    #echo str_replace('<?xml version="1.0"?>', '', $XMLclust->saveXML());
    xml+= "</wrapper>\n"
  end
  
  
end