/*
 * EIT2Client.java
 *
 * Created on November 8, 2007, 3:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *
 * msanchez@ebscohost.com
 */

package com.epnet.eit2.rest.client;

import java.net.URL;
import java.net.URI;
import java.net.URLEncoder;

import java.io.InputStream;

/**
 * This class includes the definitions for the REST service.
 * Defines the service paths and implements the methods by accepting querystrings.
 *
 * @author msanchez
 */
public abstract class AbstractEIT2Client {
   
   /**The info method path*/
   protected static final String infoServicePath = "Services/SearchService.asmx/Info";
   /**The browse method path*/
   protected static final String browseServicePath = "Services/SearchService.asmx/Browse";
   /**The search method path*/
   protected static final String searchServicePath = "Services/SearchService.asmx/Search";
   
   /**
    * The base URI for all the methods
    */
   protected URI baseURI;
   
   
   /** Creates a new EIT2 REST client by defining the host.
    *@param host The EIT2 Rest host, eit.ebscohost.com
    *@throws EITClientException If URI contructed using the provided host is
    *an improper URI. Make sure the host passed is only the host name
    */
   protected AbstractEIT2Client( String host )
   throws EITClientException{
      try{
         baseURI = new URI("http://"+host+"/");
      }catch( Exception e ){
         throw new EITClientException(e); 
      }
   }
   
   
   
   /**
    * EIT2 REST info method.
    * Description: The Info method allows the Data Partner to receive a list of 
    * databases available to the given profile as well as the attributes of 
    * those databases such as the sort fields and indexes allowed by each 
    * database.
    * @param querystring The querystring prof=XXX&pwd=XXX
    * @throws EITClientException If any network errors occur with the request
    * @return InputStream to read from
    */
   protected InputStream info( String querystring )
   throws EITClientException{
      try{
         return service(infoServicePath,querystring);
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   
   
   /**
    * EIT2 REST browse method.
    * Description: The Browse method is used to view indexes such as Authors or 
    * Subject Terms on an EBSCOhost database. Note that the index availability 
    * can be different per database.
    * @param querystring prof=XXX&pwd=XXX&term=XXX&numrec=XXX&db=XXX&index=XXX. 
    * All but numrec are required fields.
    * @throws EITClientException If any network errors occur with the request
    * @return InputStream to read from
    */
   protected InputStream browse( String querystring )
   throws EITClientException{
      try{
         return service(browseServicePath,querystring);
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }
   
   
   
   /**
    * EIT2 REST search method.
    * Description: The Search method is used to perform basic searches on 
    * EBSCOhost reference system. Abstracts as well as the full text for 
    * documents and articles can be retrieved using this method. When available, 
    * full text articles can also be downloaded in pdf format.
    * @param querystring prof=X&pwd=X&query=X&startrec=X&numrec=X&sort=X&db=X&format=X&subset=X. 
    * Only prof, pws, query and db are required.
    * @throws EITClientException If any network errors occur with the request
    * @return InputStream to read from
    */
   protected InputStream search( String querystring )
   throws EITClientException{
      try{
         return service(searchServicePath,querystring);
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }
   
   
   
   /**
    * Generic method execution
    * @throws EITClientException If any network errors occur with the request
    * @return InputStream to read from
    * @param servicePath The specific method service path
    * @param querystring The specific method querystring
    */
   protected InputStream service( String servicePath, String querystring )
   throws EITClientException{
      try{
         URL info = baseURI.resolve(new URI(servicePath+"?"+querystring)).toURL();
         return info.openStream();
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }
}