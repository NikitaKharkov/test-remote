/*
 * EIT2Client.java
 *
 * Created on November 8, 2007, 3:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.eit2.rest.client;

import java.net.URL;
import java.net.URI;
import java.net.URLEncoder;

import java.io.InputStream;


/**
 * Convenient client, alternative to EIT2Client with preset profile and password.
 * All methods will internally use the prof and pwd passed through the contructor.
 * @author msanchez@ebscohost.com
 */
public class UserEIT2Client extends EIT2Client {
   
   /**
    * prof=X&pwd=X
    */
   private String authQueryString;
   
   
   /**
    * Creates a UserEIT2Client
    * @param host The EIT2 REST host
    * @param prof EIT2 profile
    * @param pwd Profile password
    * @throws EITClientException If the host generates an improper URI
    */
   public UserEIT2Client( String host, String prof, String pwd )
   throws EITClientException{
      super(host);
      if( prof==null || prof.equals("") || pwd==null || pwd.equals("") )
         throw new EITClientException("Improper values");
      authQueryString = getAuthenticationQuerystring(prof,pwd);
   }
   
   
   
   /**
    * The Info method allows the Data Partner to receive a list of databases available to the given profile as well as the attributes of those databases such as the sort fields and indexes allowed by each database.
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream info()
   throws EITClientException{
      return info(authQueryString);
   }

   
   
   /**
    * The Browse method is used to view indexes such as Authors or Subject Terms on an EBSCOhost database. Note that the index availability can be different per database.
    * This method accepts both mandatory and non-mandatory parameteers.
    * Non-mandatory parameters are marked by "_"; set to null to use default value.
    * @param term Browse terms
    * @param numrec_20 Number of records to retrieve. Use for pagination.
    * @param db DB to browse
    * @param index Index to browse
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream browse( String term, String numrec_20, String db, String index )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("term",term,true);
         params.put("numrec",numrec_20,false);
         params.put("db",db,true);
         params.put("index",index,true);
         
         return service(
               browseServicePath,
               authQueryString+"&"+params.getQueryString()
               );
         
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   /**
    * The Browse method is used to view indexes such as Authors or Subject Terms on an EBSCOhost database. Note that the index availability can be different per database.
    * This method accepts only mandatory parameters.
    * @param term Browse terms
    * @param db DB to browse
    * @param index Index to browse
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream browse( String term, String db, String index )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("term",term,true);
         params.put("db",db,true);
         params.put("index",index,true);
         
         return service(
               browseServicePath,
               authQueryString+"&"+params.getQueryString()
               );
         
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }
   
   
   
   /**
    * The Search method is used to perform basic searches on EBSCOhost reference system. Abstracts as well as the full text for documents and articles can be retrieved using this method. When available, full text articles can also be downloaded in pdf format.
    * This method accepts both mandatory and non-mandatory parameteers.
    * Non-mandatory parameters are marked by "_"; set to null to use default value.
    * @param query Search terms. Can be a bquery.
    * @param startrec_1 Start record. Use for pagination.
    * @param numrec_10 Number of records to return at a time. Use for pagination.
    * @param sort_date Sort type. Varies per database. Use infor to introspect DB.
    * @param db DB to search
    * @param format_brief Format type: brief, detailed, full.
    * @param subset_ Use info method for DB subsets
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream search( String query, String startrec_1, String numrec_10, String sort_date, String db, String format_brief, String subset_ )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("query",query,true);
         params.put("startrec",startrec_1,false);
         params.put("numrec",numrec_10,false);
         params.put("sort",sort_date,false);
         params.put("db",db,true);
         params.put("format",format_brief,false);
         params.put("subset",subset_,false);
         
         return service(
               searchServicePath,
               authQueryString+"&"+params.getQueryString()
               );
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   /**
    * The Search method is used to perform basic searches on EBSCOhost reference system. Abstracts as well as the full text for documents and articles can be retrieved using this method. When available, full text articles can also be downloaded in pdf format.
    * This method accepts only mandatory parameters.
    * @param query Search terms. Can be a bquery.
    * @param db DB to search
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream search( String query, String db )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("query",query,true);
         params.put("db",db,true);
         
         return service(
               searchServicePath,
               authQueryString+"&"+params.getQueryString()
               );
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   
   
   /**
    * Generated the auth portion of the querystrng
    * @param prof EIT profile
    * @param pwd profile password
    * @return portion of querystring prof=X&pwd=X
    */
   private String getAuthenticationQuerystring( String prof, String pwd){
      return "prof="+prof+"&pwd="+pwd;
   }
   
}