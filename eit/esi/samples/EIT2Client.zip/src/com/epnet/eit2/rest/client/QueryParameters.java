package com.epnet.eit2.rest.client;

import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Properties;

/**
 *This class helps construct a querystring from parameters provided.
 *It extends properties by adding a put method though which a parameter can 
 *be specified as mandatory and by adding a getQueryString method that combines 
 * all parameters into a string. 
 * 
 * If the parameter is specified as mandatory when put, it will throw an 
 * Exception if null or empty.
 */
class QueryParameters extends Properties{
   
   /**
    * Add new parameter
    * @param parameter http parameter
    * @param value http parameter value
    * @param mandatory true if parameter is mandatory, to verify when querystring is created. 
    * Useful if parameters are added automatically from other process, to trap bad requests before sending them out.
    * @throws java.lang.Exception If a paramter fails
    */
   protected void put(String parameter, String value, boolean mandatory) throws Exception{
      if (value!=null && !value.equals("")){
         super.put(parameter,URLEncoder.encode(value,"UTF-8"));
      }else{
         if (mandatory)
            throw new Exception("Parameter "+parameter+" is mandatory");
      }
   }
   
   /**
    * Generate the querystring from all parameters passed so far.
    * @return The querystring
    */
   protected String getQueryString(){
      if( super.isEmpty() )
         return "";
      
      StringBuffer querystring = new StringBuffer();
      Enumeration en = this.keys();
      while (en.hasMoreElements()){
         String param = (String)en.nextElement();
         querystring.append(param+"="+this.getProperty(param)+"&");
      }
      querystring.deleteCharAt(querystring.length()-1);
      return querystring.toString();
   }
}