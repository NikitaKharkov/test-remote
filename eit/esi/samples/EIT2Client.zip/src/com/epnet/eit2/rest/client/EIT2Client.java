/*
 * EIT2Client.java
 *
 * Created on November 8, 2007, 3:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.epnet.eit2.rest.client;

import java.net.URL;
import java.net.URI;
import java.net.URLEncoder;

import java.io.InputStream;

/**
 * A funtional EIT2 REST client.
 * Provides parametrized methods and internally builds the querystring. 
 * There are two versions, a mandatory-parameters version and an all-parameters one.
 * @author msanchez@ebscohost.com
 */
public class EIT2Client extends AbstractEIT2Client {

   /**
    * Creates an instance of the client
    * @param host The EIT2 REST host
    * @throws EITClientException If any network errors occur with the request
    */
   public EIT2Client( String host )
   throws EITClientException{
      super(host);
   }
   
   
   
   /**
    * The Info method allows the Data Partner to receive a list of databases available to the given profile as well as the attributes of those databases such as the sort fields and indexes allowed by each database.
    * @param prof eit profile
    * @param pwd profile password
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream info( String prof, String pwd )
   throws EITClientException{
      return info(infoServicePath,"prof="+prof+"&pwd="+pwd);
   }

   
   
   /**
    * The Browse method is used to view indexes such as Authors or Subject Terms on an EBSCOhost database. Note that the index availability can be different per database.
    * Non-mandatory parameters are marked by "_"; set to null to use default value.
    * @param prof eit profile
    * @param pwd profile password
    * @param term Search terms.
    * @param numrec_20 Number of records to return for this search
    * @param db DB to browse at a time
    * @param index The DB index to browse
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream browse( String prof, String pwd, String term, String numrec_20, String db, String index )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("prof",prof,true);
         params.put("pwd",pwd,true);
         params.put("term",term,true);
         params.put("numrec",numrec_20,false);
         params.put("db",db,true);
         params.put("index",index,true);
         
         return service(browseServicePath,params.getQueryString());
         
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   /**
    * The Browse method is used to view indexes such as Authors or Subject Terms on an EBSCOhost database. Note that the index availability can be different per database.
    * @param prof eit profile
    * @param pwd profile password
    * @param term Search terms.
    * @param db DB to browse
    * @param index DB index to browse
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream browse( String prof, String pwd, String term, String db, String index )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("prof",prof,true);
         params.put("pwd",pwd,true);
         params.put("term",term,true);
         params.put("db",db,true);
         params.put("index",index,true);
         
         return service(browseServicePath,params.getQueryString());
         
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }
   
   
   
   /**
    * The Search method is used to perform basic searches on EBSCOhost reference system. Abstracts as well as the full text for documents and articles can be retrieved using this method. When available, full text articles can also be downloaded in pdf format.
    * Non-mandatory parameters are marked by "_"; set to null to use default value.
    * @param prof eit profile
    * @param pwd profile password
    * @param query Search terms. Can be a bquery.
    * @param startrec_1 Start record. Use for pagination.
    * @param numrec_10 Number of records to return at a time. Use for pagination.
    * @param sort_date Sort type. Varies per database. Use infor to introspect DB.
    * @param db DB to search
    * @param format_brief Format type: brief, detailed, full.
    * @param subset_ Use info method for DB subsets
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream search( String prof, String pwd, String query, String startrec_1, String numrec_10, String sort_date, String db, String format_brief, String subset_ )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("prof",prof,true);
         params.put("pwd",pwd,true);
         params.put("query",query,true);
         params.put("startrec",startrec_1,false);
         params.put("numrec",numrec_10,false);
         params.put("sort",sort_date,false);
         params.put("db",db,true);
         params.put("format",format_brief,false);
         params.put("subset",subset_,false);
         
         return service(searchServicePath,params.getQueryString());
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

   /**
    * The Search method is used to perform basic searches on EBSCOhost reference system. Abstracts as well as the full text for documents and articles can be retrieved using this method. When available, full text articles can also be downloaded in pdf format.
    * @param prof eit profile
    * @param pwd profile password
    * @param query Search terms. Can be a bquery.
    * @param db DB to search
    * @return InputStream to read from
    * @throws EITClientException If any network errors occur with the request
    */
   public InputStream search( String prof, String pwd, String query, String db )
   throws EITClientException{
      try{
         QueryParameters params = new QueryParameters();
         params.put("prof",prof,true);
         params.put("pwd",pwd,true);
         params.put("query",query,true);
         params.put("db",db,true);
         
         return service(searchServicePath,params.getQueryString());
      }catch( Exception e ){
         throw new EITClientException(e);
      }
   }

}