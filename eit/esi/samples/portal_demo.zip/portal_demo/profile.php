<?php

// Enter your profile information for
// connecting to the EBSCOhost database
// here.

$profile 		= "";
$password		= "";

// This is the default database which the search
// interface will use.  It must be a database available
// to your profile.  See README.html for more info.
$database		= "";


/* Ignore Code Below */
if( !$profile || !$password || !$database )
	die( "There is no profile information defined in 'profile.php'.  Please refer to README.html, which came packaged with this software, for instructions on setup." );
?>