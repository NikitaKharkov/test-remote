<?php
// This file will simply retrieve the RSS reed in $url, and will display it
// using XSLT

require( "functions.php" );

xml_header( "rss.xsl" );

$url = "http://rss.ebscohost.com/AlertSyndicationService/Syndication.asmx/GetFeed?guid=2574264";

$xml = curl_get ( $url );

$xml = str_replace ('<?xml version="1.0" encoding="utf-8"?>', '', $xml );
$xml = preg_replace ('/<rss(.*?)>/', '<ep_feed>', $xml );
$xml = preg_replace ('/<\/rss>/', '</ep_feed>', $xml );
$xml = preg_replace ('/<description>(.*?)<\/description>/', '<description></description>', $xml );

echo $xml;


?>
