<?php

// Declaring XML header information
function xml_header( $skin = 'index.xsl' )
{
    header('Content-type: text/xml');
    
    echo "<?xml version='1.0' encoding='UTF-8'?>\n";
    echo "<?xml-stylesheet type='text/xsl' href='$skin'?>\n";
    echo "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n";
}

// This function uses cURL to retrieve data from an online document.  cURL is 
// standard in most PHP installations.  file_get_contents() may also be a substitute
// for this function.
function curl_get( $url )
{
	$rest_con = curl_init();	
				
	curl_setopt ($rest_con, CURLOPT_URL, $url );
	curl_setopt ($rest_con, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($rest_con, CURLOPT_CONNECTTIMEOUT, 0);
	
	$result = curl_exec($rest_con);
	curl_close($rest_con); 
	
	return $result;
}

// This function will retrieve the subjects associated with a search
// and return the 10 most common subjects in a sorted array.  It does this
// by retrieving the 50 records closest to the current start record.
// 		$exclude is an associative array of items to not include in the
//		   returned subjects.  For any given $subject, if $exclude[ $subject ] is 
//		   set, then it, then it will not display that particular subject.
function subject_clusters( $query, $start, $exclude, $profile, $pwd, $db )
{
	$start_record = $start - 25;
	$start_record = ( $start_record < 1 ) ? ( 24 - ( 25 - $start ) ) : ( 25 );
	
	// Force a full-text only search result.
	if( !preg_match('/ AND FT Y/', $query ) )
		$query .= ' AND FT Y';
	
	$query = str_replace( ' ', '+', $query );
	
	// Retrieve the XML search file from the EIT Search Service.  See 'function curl_get()'
	// below for more details.
	$xml = curl_get( "http://eit.ebscohost.com/Services/SearchService.asmx/Search?prof="
				. $profile . "&pwd=" . $pwd . "&db=" . $db . "&query=" . $query
				. "&startrec=" . ( $start - $start_record ) . "&numrec=50" );
				
	$subject_clusters = preg_match_all('/<subj type="thes">(.+?)<\/subj>/', $xml, $subjects );
	
	foreach( $subjects[1] as $subject )
	{
		if( !isset( $count[ $subject ]) )
			$count[ $subject ] = 0;
		
		// Set the subject to -1 if it is in the exclude list.  Otherwise, increment.
		if( !isset( $exclude[ $subject ] ) && !isset( $exclude[ strtolower( $subject) ] ) )
			$count[ $subject ]++;
		else
			$count[ $subject ] = -1;
	}
	
	arsort( $count );
	
	$i = 0;
	foreach( $count as $subject => $number )
	{
		if( $i >= 10 )
			break;
		
		$i++;
		
		// Trim any extra information off of the end of the subject, and replace
		// any ampersands with &amp;
		$subject = explode( '(', $subject );
		$subject_trimmed = $subject[0];
		
		// Trim any ampersands out of subjects, these cause problems with the HTML 
		$subject_trimmed = str_replace( '&amp;', '', $subject_trimmed);
		
		$return_ar[ $i ] = $subject_trimmed;
	}
	
	return $return_ar;
}

// This function creates an array of breadcrumbs using the formatted query
// string.  This function simply splits the query string using )+AND+(SU+ as
// a delimiter, which separates the terms by subject.
//		["breadcrumb name"] = "query string";
// where "query string" is the query relevant to that breadcrumb.
function breadcrumbs( $query )
{
	// Output the breadcrumbs
	$breadcrumbs = explode( ')+AND+(SU+', $query );
	
	// Number of breadcrumbs total
	$bc_count = count( $breadcrumbs );
	
	// Counter to keep track of which breadcrumb is being processed.
	$item = 0;
	
	foreach( $breadcrumbs as $breadcrumb )
	{
		$item++;
		
		// Make Breadcrumbs Readable
		$breadcrumb = str_replace( '+', ' ', $breadcrumb );
		$breadcrumb = str_replace( '(', '', $breadcrumb );
		$breadcrumb = str_replace( ')', '', $breadcrumb );
		$breadcrumb = str_replace( '+AND+FT+Y', '', $breadcrumb );
		$breadcrumb = str_replace( ' AND FT Y', '', $breadcrumb );
		
		// This is the query string.  Each breadcrumb will have its own
		// query string.
		$temp_query = '';
		
		// This loop builds the query up.  For the first breadcrumb, it will
		// only include the first query.  For the second breadcrumb, it will
		// include the first and second, etc.
		for( $i = 0; $i < $item; $i++ )
		{
			$temp_query .= $breadcrumbs[$i];
			
			if( $i != ($item - 1) )
				$temp_query .= ')+AND+(SU+';
				
		}
		// If the last character is not a parenthesis, append one
		// onto the query.
		
		if( $temp_query[ strlen( $temp_query) - 1 ] != ')' )
			$temp_query .= ')';

		$return_ar[ $breadcrumb ] = $temp_query;
	}
	
	return $return_ar;
}
