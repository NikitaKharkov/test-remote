<?php

include( 'profile.php' );

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>The University Collection - Search using EBSCOhost</title>
<link rel='stylesheet' href='eds.css' type='text/css' />

<script language="javascript">

function toggle_search()
{
	toggle_display( "search_opt_on" );
	toggle_display( "search_opt_off" );
}

function toggle_display( id ) {
	
	obj = document.getElementById( id );
	
	if ( obj )
		obj.style.display = ( obj.style.display == "none" ) ? "block" : "none";
}

</script>

</head>
<body>

<div id="container">
	<div id="header">
		<div class="top">
			<a href="#">New Search</a>
		</div>
		<div class="middle">
			<img src="images/logo_main_png.gif" style="float:left" alt="" />
			<img src="images/logo_right.png" style="float:right" alt="" />
			<table>
				<tr>
					<td>
						<div class="inactive_button" style="margin-left: 50px;">
							Home
						</div>
					</td>
					<td>
						<div class="active_button">
							Search
						</div>
					</td>
					<td>
						<div class="inactive_button">
							Subject Guides
						</div>
					</td>
					<td>
						<div class="inactive_button">
							A-Z Publications
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div class="bottom"></div>
	</div>
	<form action="search.php" method="get">
	<div id="content">
		<div class="box">
			Searching: <b>University Library Collection</b>
			<br/>
			
			<p>
				<input type="text" name="query" style="width: 350px;" /> <input type="submit" value="Search" />
			</p>
			<div id="search_opt_off" style="display: block">
				<p>
					<span class="search_options_off"><a href="javascript:toggle_search();">Search Options</a></span>
				</p>
			</div>
			<div id="search_opt_on" style="display: none">
				<p>
					<span class="search_options_on"><a href="javascript:toggle_search();"><b>Search Options</b></a></span>
				</p>
				<div class="search_options_box">
					<div style="float: left">
						<div style="width: 180px; float: left;">
							<input type="checkbox" name="ft" style="" />Full Text Only <br />
							<input type="checkbox" name="sch" style="" />Peer Reviewed Journals <br />
						</div>
						<table style="float: left">
							<tr>
								<td>
									<input type="radio" name="pubtype" value="all" />
								</td>
								<td>
									All
								</td>
							</tr>
							<tr>
								<td>
									<input type="radio" name="pubtype" value="articles" />
								</td>
								<td>
									Articles
								</td>
							</tr>
							<tr>
								<td>
									<input type="radio" name="pubtype" value="books" />
								</td>
								<td>
									Books
								</td>
							</tr>
						</table>
						<br/>
						<table>
							<tr>
								<td colspan="2">
									<b>Article Information</b>
								</td>
							</tr>
							<tr>
								<td style="text-align: right">
									Journal Name: 
								</td>
								<td>
									<input name="journal_name" type="text" style="width: 150px" />
								</td>
							</tr>
							<tr>
								<td style="text-align: right">
									Author: 
								</td>
								<td>
									<input name="journal_author" type="text" style="width: 150px" />
								</td>
							</tr>
							<tr>
								<td style="text-align: right">
									Title: 
								</td>
								<td>
									<input name="journal_title" type="text" style="width: 150px" />
								</td>
							</tr>
						</table>
					</div>
					<div style="float: right; text-align: right;">
						Sort by: <select name="sort">
							<option value="relevance" selected>Relevance</option>
							<option value="date">Date</option>
						</select>
						<br />
						<br />
						<br />
						<table>
							<tr>
								<td colspan="3" style="text-align: left">
									<b>Publication Date:</b>
								</td>
							</tr>
							<tr>
								<td>
									From:
								</td>
								<td>
									<select name="from_month">
										<option value="01">January</option>
										<option value="02">February</option>
										<option value="03">March</option>
										<option value="04">April</option>
										<option value="05">May</option>
										<option value="06">June</option>
										<option value="07">July</option>
										<option value="08">August</option>
										<option value="09">September</option>
										<option value="10">October</option>
										<option value="11">November</option>
										<option value="12">December</option>
									</select>
								</td>
								<td>
									of <input name="from_year" type="text" style="width: 50px" />
								</td>
							</tr>
							<tr>
								<td>
									to
								</td>
								<td>
									<select name="to_month">
										<option value="01">January</option>
										<option value="02">February</option>
										<option value="03">March</option>
										<option value="04">April</option>
										<option value="05">May</option>
										<option value="06">June</option>
										<option value="07">July</option>
										<option value="08">August</option>
										<option value="09">September</option>
										<option value="10">October</option>
										<option value="11">November</option>
										<option value="12">December</option>
									</select>
								</td>
								<td>
									of <input name="to_year" type="text" style="width: 50px" />
								</td>
							</tr>
						</table>
					</div>
					<div style="clear:both"></div>
					<br />
					<br />
					<br />
				</div>
			</div>
		</div>
	</div>
	</form>
	<div id="footer">
		<a href="http://support.ebscohost.com/eit/">Back to EBSCOhost Integration Toolkit Home</a>
	</div>
</div>

</body>
</html>