<?php

//
// Enter your profile information for connecting to the EBSCOhost database here.
//

// Web services account ID and password.  Account will be used to authenticate each request to the web services API.  
// Accounts are created and maintained in ESBCOadmin.  If you do not have a web services account, 
// Contact your EBSCO Account Manager who can create one for you. 
$profile = "";
$pwd = "";


// Or maybe you want to consume profile and password from a form and store in a cookie
// Sample code...
/*
  if( !isset( $_COOKIE["profile"]) || !isset( $_COOKIE["password"] ))
	die(
		$profile 		= $_COOKIE["profile"];
		$password		= $_COOKIE["password"];
		setcookie( "profile", $_POST["prof"], 0, '/' );
		setcookie( "password", $_POST["pwd"], 0, '/' );
		header( "Location: " . $fwd );
	)
*/

?>