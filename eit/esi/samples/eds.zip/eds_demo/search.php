<?php

include( 'profile.php' );

// Retrieve the sort option from the form POST request after the user clicks the Search button
$vars["sort"]		= getVar( "sort", "get" );

// Retrieve the search limiters from the form POST request after the user clicks the Search button
// These limiters are made available to the user via the Search Options screen accessible under
// the main search box.
$vars["query"] 		= getVar( "query", "get" );
$vars["full_text"] 	= getVar( "ft", "get" );
$vars["scholarly"]	= getVar( "sch", "get" );
$vars["j_title"]	= getVar( "journal_title", "get" );
$vars["j_author"]	= getVar( "journal_author", "get" );
$vars["j_name"]		= getVar( "journal_name", "get" );
$vars["from_year"]	= getVar( "from_year", "get" );
$vars["from_month"]	= getVar( "from_month", "get" );
$vars["to_year"]	= getVar( "to_year", "get" );
$vars["to_month"]	= getVar( "to_month", "get" );
$vars["pubtype"]	= getVar( "pubtype", "get" );

// Initialize the starting position of the records in the XML returned from the web services API.
// If the starting position parameter doesn't exist, set it to 1
// $start will be referenced on line 163 below
if( !isset($_GET['start']) )
	$start = 1;
else
	$start = $_GET['start'];


// Format the Query using the limiters above.
$query = $vars["query"];
$query_o = $vars["query"];

// Remove preceding and trailing blank space
$query = trim( $query );

// Encode any blank spaces within the query string.  Should be done as a best practice.  
$query = str_replace( " ", "+", $query );

// Initialize limiter variable.  xml_vars holds the limiters which will be passed to
// the XSLT stylesheet via XML
$xml_vars = '';

// Add left and right parenthesis around the query string.  This will ensure the search criteria is
// properly bounded in the query string
if( $query[0] != '(' )
	$query = '(' . $query;

// Once the search criteria is added to the query string, append any limiters that were selected via the UI
// to the query string.  
if( $query[ ( strlen( $query ) - 1 ) ] )
	$query .= ')';

// User has indicated, via the Search Options screen, that the search must include 
// articles containing Full Text
if( $vars["full_text"] )
{
	// append to the query, the FT field code and set to a value of Y
	$query .= "+AND+(FT+Y)";
	$xml_vars .= "<ft ft=\"on\" />\n";
}

// User has indicated, via the Search Options screen, that the search must include 
// Scholarly (Peer Reviewed) Journals
if( $vars["scholarly"] )
{
	// append to the query, the RV field code and set to a value of Y
	$query .= "+AND+(RV+Y)";
	$xml_vars .= "<sch sch=\"on\" />\n";
}

// User has specified a Journal Name via the Search Options screen
if( $vars["j_name"] )
{
	// encode any blank spaces within the query string with + signs
	$j_name = str_replace( " ", "+", $vars["j_name"] );
	// preface journal name with the SO field code.  this will greatly help narrow the scope of the search
	$query .= ( "+AND+(SO+" . $j_name . ")" );
	$xml_vars .= "<jname>" . $vars["j_name"] . "</jname>\n";
}

// User has specified an article title via the Search Options screen
if( $vars["j_title"] )
{
	// encode any blank spaces within the query string with + signs
	$j_title = str_replace( " ", "+", $vars["j_title"] );
	// preface article title with the TI field code.  this will greatly help narrow the scope of the search
	$query .= "+AND+(TI+" . $j_title . ")";
	$xml_vars .= "<jtitle>" . $vars["j_title"] . "</jtitle>\n";
}

// User has specified an author's name via the Search Options screen
if( $vars["j_author"] )
{
	// encode any blank spaces within the query string with + signs
	$j_author = str_replace( " ", "+", $vars["j_author"] );
	// preface author's name with the AU field code.  this will greatly help narrow the scope of the search
	$query .= "+AND+(AU+" . $j_author . ")";
	$xml_vars .= "<jauthor>" . $vars["j_author"] . "</jauthor>\n";
}

if( $vars["pubtype"] == "all" )
{
	$xml_vars .= "<pubtype>all</pubtype>\n";
} else if( $vars["pubtype"] == "books" )
{
	$xml_vars .= "<pubtype>books</pubtype>\n";
	$query .= "+AND+(PT+book)";
} else if( $vars["pubtype"] == "articles" )
{
	$xml_vars .= "<pubtype>articles</pubtype>\n";
	$query .= "+AND+(ZT+article)";
}

// User has chosen to specify From and/or To dates to narrow the scope of the search.  
if( $vars["from_year"] || $vars["to_year"] )
{
	// preface From and/or To date with DT field code
	$query .= "+AND+(DT+";
	
	if( $vars["from_year"] )
	{
		// append From date to query string
		$query .= $vars["from_year"] . $vars["from_month"];
		$xml_vars .= "<from_year>" . $vars["from_year"] . "</from_year>\n";
		$xml_vars .= "<from_month>" . $vars["from_month"] . "</from_month>\n";
	}
	
	$query .= '-';
	
	if( $vars["to_year"] )
	{
		// append To date to query string
		$query .= $vars["to_year"] . $vars["to_month"];
		$xml_vars .= "<to_year>" . $vars["to_year"] . "</to_year>\n";
		$xml_vars .= "<to_month>" . $vars["to_month"] . "</to_month>\n";
	}
	// close the date parenthesis in order to properly bound the date parameters 
	$query .= ')';
}

// Compose the full EBSCOhost web services API URL
// Number of records to return is defaulted to 10.  
// Valid values 1 to 200
// When specifying format = Full (as opposed to Brief, Detailed), maximum records returned is capped 50
$EITServiceURL = "http://eit.ebscohost.com/Services/SearchService.asmx/Search?prof=" . $profile . "&pwd=" . $pwd . "&query=" . $query . "&sort=" . $vars["sort"] . "&startrec=" . $start . "&numrec=10";



// Make the request to the web services API by issuing a curl Get request
$data = curl_get( $EITServiceURL );

// Load the XML result received from the web services API into a local document 
// object so that it can be parsed 
$XMLdata = new DOMDocument();
$XMLdata->loadXML( $data);

// Get the total number of records returned from the search.
$Statistics = $XMLdata->getElementsByTagName( "Statistics" );
$XMLhits = $Statistics->item(0)->getElementsByTagName( "Hits" );
$hits = 0;
foreach( $XMLhits as $hitcount )
	$hits += $hitcount->nodeValue;

// Get the RecordCount for this page.  This represents the number of
// records returned on this page.
$XMLrecords = $XMLdata->getElementsByTagName( "rec" );
$RecordCount = 0;
foreach( $XMLrecords as $rec )
	$RecordCount++;

	
// Next Page record number and Previous Page record number
$NextPageStart = $start + 10;
$PrevPageStart = $start - 10;

// Begin: generate wrapper XML that will be used by to build the search results web page
// search.xsl, located in the same directory as search.php, will translate this XML into HTML
header('Content-type: text/xml');
    
echo "<?xml version='1.0' encoding='UTF-8'?>\n";
echo "<?xml-stylesheet type='text/xsl' href='search.xsl'?>\n";
echo "<!-- Copyright 2010 EBSCO Industries, Inc.  All rights reserved. -->\n";
echo "<wrapper>\n";
echo "<query>" . 	$query_o . "</query>\n";
echo "<prevpage>" . $PrevPageStart . "</prevpage>\n";
echo "<hits>" . 	$hits . "</hits>\n";

if( !$hits )
	echo "<noresults>1</noresults>";
else
	echo "<noresults>0</noresults>";
	
if( ( $RecordCount ) < 10 )
	echo "<nextpage>0</nextpage>\n";
else
	echo "<nextpage>" . $NextPageStart . "</nextpage>\n";

echo "<totalrecs>" . $RecordCount . "</totalrecs>\n";
echo "<thispage>" . $start . "</thispage>\n";
echo "<page>" . ( !isset( $_GET['page']) ? 1 : $_GET['page'] ) . "</page>\n";
echo "<sort>" . $vars["sort"] . "</sort>\n";

// Output the variables for the XSL stylesheet.
echo $xml_vars;


// Output the results from the EBSCOhost Search.
echo str_replace( '<?xml version="1.0"?>', '', $XMLdata->saveXML() );

echo "</wrapper>\n";

// End: generate wrapper XML 

function getVar( $var_name, $method = "post" )
{
	switch( $method )
	{
		case "post":
			return ( !isset( $_POST[ $var_name ] ) ? null : $_POST[ $var_name ] );
		case "get":
			return ( !isset( $_GET[ $var_name ] ) ? null : $_GET[ $var_name ] );
		case "cookie":
			return ( !isset( $_COOKIE[ $var_name ] ) ? null : $_COOKIE[ $var_name ] );
		default:
			return null;
			
	}
}

// Function, which gets the contents of a webpage.  In this case, it's the
// contents of the EBSCOhost Web Service.
function curl_get( $url )
{
	$rest_con = curl_init();	
				
	curl_setopt ($rest_con, CURLOPT_URL, $url );
	curl_setopt ($rest_con, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($rest_con, CURLOPT_CONNECTTIMEOUT, 0);
	
	$result = curl_exec($rest_con);
	curl_close($rest_con); 
	
	return $result;
}