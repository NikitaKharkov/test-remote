<?php
// This class is a SOAP Implementation of the web service
// available at http://eit.ebscohost.com/Services/SearchService.asmx.
//
// This class is based off of the WSDL file:
// 		http://eit.ebscohost.com/Services/SearchService.asmx?WSDL
//


class SOAPservice
{
	// SOAP Authentication Information
	private $profile;
	private $password;
	
	// SOAP Service URL
	private $host;
	private $path;
	
	public function SOAPservice( $host, $path, $profile, $password )
	{
		$this->host 	= $host;
		$this->path		= $path;
		$this->profile 	= $profile;
		$this->password = $password;
	}
	
	// Returns the database information for a profile in XML format.
	public function Info()
	{
		// This SOAP message requests database information from
		// the service.
		$soap_message = 
			'<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" soap:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" >
				<soap:Header>
					<auth:AuthorizationHeader soap:mustUnderstand="1" xmlns:auth="http://epnet.com/webservices/SearchService/2007/07/">
						<auth:Profile>' . $this->profile . '</auth:Profile>
						<auth:Password>' . $this->password . '</auth:Password>
					</auth:AuthorizationHeader>
				</soap:Header>
				<soap:Body>
					<eit:Info xmlns:eit="http://epnet.com/webservices/SearchService/2007/07/" />
				</soap:Body>
			</soap:Envelope>';
		
		// Send the SOAP message to the service, and return the data
		// inside of the SOAP return message.
		return $this->send( $soap_message );
	}
	
	public function Search( $query, $database, $startRec = 1, $numRec = 10, $sort = "date" )
	{
		// This message will request a Search from the SOAP service.
		$soap_message = 
			'<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" soap:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" >
				<soap:Header>
					<auth:AuthorizationHeader soap:mustUnderstand="1" xmlns:auth="http://epnet.com/webservices/SearchService/2007/07/">
						<auth:Profile>' . $this->profile . '</auth:Profile>
						<auth:Password>' . $this->password . '</auth:Password>
					</auth:AuthorizationHeader>
				</soap:Header>
				<soap:Body>
					<eit:Search xmlns:eit="http://epnet.com/webservices/SearchService/2007/07/">
						<eit:searchRequest>
							<eit:Query>' . $query . '</eit:Query>
							<eit:Databases>' . $database . '</eit:Databases>
							<eit:StartingRecordNumber>' . $startRec . '</eit:StartingRecordNumber>
							<eit:NumberRecordsReturned>' . $numRec . '</eit:NumberRecordsReturned>
							<eit:Sort>' . $sort . '</eit:Sort>
						</eit:searchRequest>
					</eit:Search>
				</soap:Body>
			</soap:Envelope>';
		
		// Send the SOAP message to the service.  The data returned from
		// the send function is the entire SOAP message.  We just want to
		// get the information inside
		return $this->send( $soap_message );
	}
	
	public function Browse( $db, $index, $term )
	{
		// This message will request a Browse from the SOAP service.
		$soap_message = 
			'<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" soap:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" >
				<soap:Header>
					<auth:AuthorizationHeader soap:mustUnderstand="1" xmlns:auth="http://epnet.com/webservices/SearchService/2007/07/">
						<auth:Profile>' . $this->profile . '</auth:Profile>
						<auth:Password>' . $this->password . '</auth:Password>
					</auth:AuthorizationHeader>
				</soap:Header>
				<soap:Body>
					<eit:Browse xmlns:eit="http://epnet.com/webservices/SearchService/2007/07/">
						<eit:browseRequest>
							<eit:Term>' . $term . '</eit:Term>
							<eit:Index>' . $index . '</eit:Index>
							<eit:Databases>' . $db . '</eit:Databases>
						</eit:browseRequest>
					</eit:Browse>
				</soap:Body>
			</soap:Envelope>';
		
		return $this->send( $soap_message );
	}
	
	// This function uses cURL to send data to the SOAP service.
	private function send( $message )
	{
		/* Set the HTTP Headers */
		$http_header[] = 'POST ' . $this->path . ' HTTP/1.1';
		$http_header[] = 'Host: ' . $this->host;
		$http_header[] = 'Content-Type: text/xml; charset="utf-8"';
		$http_header[] = 'Content-Length: ' . strlen( $message );
		
		/* POST the SOAP message to the server, and echo the response. */
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, "http://eit.ebscohost.com/Services/SearchService.asmx" );
		curl_setopt( $ch, CURLOPT_POST, TRUE );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
		curl_setopt( $ch, CURLOPT_HTTPHEADER, $http_header );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, $message );
		
		return curl_exec( $ch );
	}
}