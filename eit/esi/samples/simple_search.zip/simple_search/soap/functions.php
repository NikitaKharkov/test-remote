<?php

function xml_header( $skin )
{
	// Initialize XML headers
	header( "Content-type: text/xml" );
	echo '<?xml version="1.0" encoding="UTF-8"?>';
	echo '<?xml-stylesheet type="text/xsl" href="' . $skin . '"?>';
}

?>