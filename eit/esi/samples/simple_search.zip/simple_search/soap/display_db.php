<?php

require( "../profile.php" );
require( "../soap.php" );
require( "functions.php" );

// Setup profile parameters
$soap = new SOAPservice( "eit.ebscohost.com", "/Services/SearchService.asmx", $profile, $password );

$xml = $soap->Info();
$xml = str_replace( '<?xml version="1.0" encoding="utf-8"?>', '', $xml );

// Display XML header with XSL stylesheet information
xml_header( "display_db.xsl" );
echo $xml;

?>