<?php

require( "../profile.php" );
require( "../soap.php" );
require( "functions.php" );

// Execute search query and return results.

// Search Terms
$s1 = $_GET["s1"];
$s2 = $_GET["s2"];
$s3 = $_GET["s3"];
$s4 = $_GET["s4"]; 

// Delimiters
$d1 = $_GET["d1"];
$d2 = $_GET["d2"];
$d3 = $_GET["d3"];

// Tags
$t1 = $_GET["t1"];
$t2 = $_GET["t2"];
$t3 = $_GET["t3"];
$t4 = $_GET["t4"];

// Other
$db = $_GET["db"];
$sort = $_GET["sort"];
$start = ( isset( $_GET["start"] ) ? $_GET["start"] : 1 );
$ft = isset( $_GET["ft"] ) ? true : false;

// No search terms, go back to select DB
if( !$s1 && !$s2 && !$s3 && !$s4
	|| !$db )
	die( header( "Location: search.php?db=a9h" . $db ) );

// The link for 'next' and 'previous' pages
$link = 'results.php?db=' . $db . '&amp;sort=' . $sort . '&amp;s1='
		. $s1 . '&amp;s2=' . $s2 . '&amp;s3=' . $s3 . '&amp;s4=' . $s4 . '&amp;t1=' 
		. $t1 . '&amp;t2=' . $t2 . '&amp;t3=' . $t3 . '&amp;t4=' . $t4 . '&amp;d1=' 
		. $d1 . '&amp;d2=' . $d2 . '&amp;d3=' . $d3 . '&amp;ft=' . $ft;
	
		
// Query Build Algorithm
$s1 = ( $s1 != null ) ? ( '(' . $t1 . ( $t1 != '' ? ' (' : '' ) . $s1 . ')' . ( $t1 != '' ? ')' : '') ) : null;

$s2 = ( $s2 != null ) ? ( '(' . $t2 . ( $t2 != '' ? ' (' : '' ) . $s2 . ')' . ( $t2 != '' ? ')' : '') ) : null;

$s3 = ( $s3 != null ) ? ( '(' . $t3 . ( $t3 != '' ? ' (' : '' ) . $s3 . ')' . ( $t3 != '' ? ')' : '') ) : null;

$s4 = ( $s4 != null ) ? ( '(' . $t4 . ( $t4 != '' ? ' (' : '' ) . $s4 . ')' . ( $t4 != '' ? ')' : '') ) : null;
		

$q = $s1 . ( ( $s2 != '' ) ? (' ' . $d1 . ' ') : null ) . 
	 $s2 . ( ( $s3 != '' ) ? (' ' . $d2 . ' ') : null ) .
	 $s3 . ( ( $s4 != '' ) ? (' ' . $d3 . ' ') : null ) .
	 $s4;
	 
// The query to be sent to the EIT is formatted in $q

// Append the full text modifier if the user has selected fulltext
if( !preg_match( '/\ AND\ FT\ Y/', $q ) && isset( $_GET['ft'] ) )
	$q .= ' AND FT Y';	 
	 

$soap = new SOAPservice( "eit.ebscohost.com", "/Services/SearchService.asmx", $profile, $password );
$xml = $soap->Search( $q, $db, $start, 10, $sort );
$xml = str_replace( '<?xml version="1.0" encoding="utf-8"?>', '', $xml );

xml_header( "results.xsl" );

// Output information about the search query.
echo "\n<wrapper>\n";
echo "<start_record>" . $start . "</start_record>\n";
echo "<query>" . $q . "</query>\n";
echo "<prev_page>" . $link . '&amp;start=' . ( $start - 10 ) . "</prev_page>\n";
echo "<next_page>" . $link . '&amp;start=' . ( $start + 10 ) . "</next_page>\n";

// Output Search Results
echo $xml;
echo "\n</wrapper>";

?>