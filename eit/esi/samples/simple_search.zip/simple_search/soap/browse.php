<?php

require( "../profile.php" );
require( "../soap.php" );
require( "functions.php" );

if( !isset( $_GET['db']) || !isset( $_GET['index']) || !isset( $_GET['browse']) )
	die( header( "Location: display_db.php" ) );

// Request Database Information
$soap = new SOAPservice( "eit.ebscohost.com", "/Services/SearchService.asmx", $profile, $password );

$xml = $soap->Browse( $_GET['db'], $_GET['index'], str_replace( ' ', '+', $_GET['browse'] ) );
$xml = str_replace( '<?xml version="1.0" encoding="utf-8"?>', '', $xml );

// Display XML header with XSL stylesheet information
xml_header( "browse.xsl" );

// This wrapper enables the script to insert our own information
// in to the XML document.  We are passing the selected database
// to the document.
echo "<wrapper>\n";
echo "	<dbSelect>" . $_GET["db"] . "</dbSelect>\n";
echo "  <index>" . $_GET["index"] . "</index>\n" . $xml;
echo "\n</wrapper>";