<?php

die( header( "Location: display_db.php") );

?>