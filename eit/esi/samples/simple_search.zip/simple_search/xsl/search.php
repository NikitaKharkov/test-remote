<?php

require( "../profile.php" );
require( "../rest.php" );
require( "functions.php" );

// Setup profile parameters
$params = array(
	"prof" => $profile,
	"pwd"  => $password 
); 
// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );
$xmlDoc->send( "Info", $params );

$xml = $xmlDoc->recieve();
$xml = str_replace( '<?xml version="1.0"?>', '', $xml );

// Display XML header with XSL stylesheet information
xml_header( "search.xsl" );

// This wrapper enables the script to insert our own information
// in to the XML document.  We are passing the selected database
// to the document.
echo "<wrapper>\n";
echo "	<dbSelect>" . $_GET["db"] . "</dbSelect>\n" . $xml;
echo "\n</wrapper>";