<?php

require( "../profile.php" );
require( "../rest.php" );
require( "functions.php" );

if( !isset( $_GET['db']) || !isset( $_GET['index']) || !isset( $_GET['browse']) )
	die( header( "Location: display_db.php" ) );

// Setup profile parameters
$params = array(
	"prof" => $profile,
	"pwd"  => $password,
	"index" => $_GET['index'],
	"term" => str_replace( " ", "+", $_GET['browse'] ),
	"db" => $_GET['db']
);

// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );
$xmlDoc->send( "Browse", $params );

$xml = $xmlDoc->recieve();
$xml = str_replace( '<?xml version="1.0"?>', '', $xml );

// Display XML header with XSL stylesheet information
xml_header( "browse.xsl" );

// This wrapper enables the script to insert our own information
// in to the XML document.  We are passing the selected database
// to the document.
echo "<wrapper>\n";
echo "	<dbSelect>" . $_GET["db"] . "</dbSelect>\n";
echo "  <index>" . $_GET["index"] . "</index>\n" . $xml;
echo "\n</wrapper>";