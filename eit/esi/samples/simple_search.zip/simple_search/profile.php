<?php

// Enter your profile information for
// connecting to the EBSCOhost database
// here.

$profile 		= "";
$password		= "";



/* Ignore Code Below */
if( !$profile || !$password )
	die( "There is no profile information defined in 'profile.php'.  Please refer to README.html, which came packaged with this software, for instructions on setup." );
?>

?>