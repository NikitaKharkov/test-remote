<?php
// This file will give a list of databases which the current profile can
// use, and allows the user to select a database.  The list of databases can
// be retrieved by using the Info method of the SearchService

// The DataService interface uses cURL to connect to the EIT and request
// the XML file.  See 'service.php'.

// Error reporting to all
error_reporting( E_ALL );

require( "../profile.php" );	// Profile Information
require( "../rest.php" );	// DataService Class
require( "functions.php" );		// Misc. Functions

// Display HTML Information
eit_header();

echo "Please choose a database:<br/>\n";

// Setup profile parameters
$params = array(
	"prof" => $profile,
	"pwd"  => $password 
); 

// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );
$xmlDoc->send( "Info", $params );

$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML( $xml );

// Get all elements with tag "db"
$databases = $xmlObj->getElementsByTagName( "db" );

echo "<p>\n";

// Display each database
foreach( $databases as $database )
{
	// Only display databases that aren't authority databases.  Authority
	// databases have an 'xsi:type' attribute to identify them.
	if( $database->getAttribute( "xsi:type" ) != "DatabaseWithAuth" )
		print( "	<a href=\"search.php?db=" . $database->getAttribute("shortName") . "\">"
			   . $database->getAttribute("longName") . "</a><br>\n" );
	
}

echo "</p>\n";

eit_footer();

?>