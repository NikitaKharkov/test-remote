<?php
// This file will display a search screen for a specific database.  Each database
// has different indexes and tags, which can be found by using the Info method of
// the SearchService.

// The DataService interface uses cURL to connect to the EIT and request
// the XML file.  See 'service.php'.

// Error reporting to all
error_reporting( E_ALL );

require( "../profile.php" );
require( "../rest.php" );
require( "functions.php" );

// Setup profile parameters
$params = array(
	"prof" => $profile,
	"pwd"  => $password 
); 
// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );
$xmlDoc->send( "Info", $params );

$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML( $xml );

// Get all 'db' elements from the XML document.
$databases = $xmlObj->getElementsByTagName( "db" );

if( !isset( $_GET["db"]) )
	die( header( "Location: index.php" ) );

$db_found = false;

// Cycle through the databases available until
// we've found the one the user requested.
foreach( $databases as $database )
{		
	if( $database->getAttribute("shortName") == $_GET["db"] )
	{
		// Correct database.
		$db_found = true;
		$db_name = $database->getAttribute("longName");
		$db_short = $_GET["db"];
		
		// Here we are going to build the select boxes with the tag and
		// index options.  Note: the authorities (xsi:type="Authority") also
		// have tags and indices. In order to avoid listing those, we are only
		// going to list the first appearence of tags and indices.
		
		$index_options = '';
		$tag_options = '';
		$sort_options = '';
		
		// Get all of the indices
		$dbIndex = $database->getElementsByTagName( "dbIndices" );
		
		// Only use the first set of indices, as all others belong to authority databases.
		$dbIndex = $dbIndex->item(0);
		$dbIndex = $dbIndex->getElementsByTagName( "dbIndex" );
		foreach( $dbIndex as $index )
		{
			$index_options .= '<option value="' . $index->getAttribute("name")
				. '">' . $index->getAttribute("description") . '</option>';
		}
		
		// Tags
		
		$dbTag = $database->getElementsByTagName( "dbTags" );
		$dbTag = $dbTag->item(0);
		$dbTag = $dbTag->getElementsByTagName( "dbTag" );
		foreach( $dbTag as $tag )
		{
			$tag_options .= '<option value="' . $tag->getAttribute("name")
				. '">' . $tag->getAttribute("description") . '</option>';
		}
		
		// Sorting
		
		$sortOption = $database->getElementsByTagName( "sortOptions" );
		$sortOption = $sortOption->item(0);
		$sortOption = $sortOption->getElementsByTagName( "sort" );
		foreach( $sortOption as $sort )
		{
			$sort_options .= '<option value="' . $sort->getAttribute("id")
				. '">' . $sort->getAttribute("name") . '</option>';
		}
		
		// We have the all the database information necessary to render
		// the search interface.
	}
}

// If there was no DB found, go back to the index.
if( !$db_found )
	die( header( "Location: index.php" ) );

// Output HTML Headers
eit_header();

// Display the Database Select Page
echo '
<a href="index.php">Database:</a> ' . $db_name . '
<hr align="left" width="500px"/>
Index Browse
<form action="browse.php" method="get">
<input type="hidden" name="db" value="' . $_GET["db"] . '" />
<table>
<tr>
	<td>
		Index:
	</td>
	<td>
		<select name="index">
			' . $index_options . '</select>
	</td>
</tr>
<tr>
	<td>
		Browse for:
	</td>
	<td>
		<input type="text" name="browse"/><br/>
	</td>
</tr>
</table>
<input type="submit" value="Browse"/>
</form>
<hr align="left" width="500px"/>
Standard Search:<br/>

<form action="results.php" method="GET" name="search">
<input type="hidden" name="db" value="' . $db_short . '"/>
<table>
	<tr>
		<td>
			Find:
		</td>
		<td>
			<input type="text" name="s1">
		</td>
		<td>
			in <select name="t1"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
		</td>
	</tr>
	<tr>
		<td>
			<select name="d1">
				<option value="AND">AND</option>
				<option value="OR">OR</option>
				<option value="NOT">NOT</option>
			</select>
		</td>
		<td>
			<input type="text" name="s2">
		</td>
		<td>
			in <select name="t2"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
		</td>
	</tr>
	<tr>
		<td>
			<select name="d2">
				<option value="AND">AND</option>
				<option value="OR">OR</option>
				<option value="NOT">NOT</option>
			</select>
		</td>
		<td>
			<input type="text" name="s3">
		</td>
		<td>
			in  <select name="t3"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
		</td>
	</tr>
	<tr>
		<td>
			<select name="d3">
				<option value="AND">AND</option>
				<option value="OR">OR</option>
				<option value="NOT">NOT</option>
			</select>
		</td>
		<td>
			<input type="text" name="s4">
		</td>
		<td>
			in  <select name="t4"><option value="">Select a Field (optional)</option>' . $tag_options . '</select>
		</td>
	</tr>
	<tr>
		<td>
			Sort By:
		</td>
		<td align="left">
			 <select name="sort">' . $sort_options . '</select>
		</td>
		<td>
			Full Text <input type="checkbox" name="ft" value="1" checked="true" />
		</td>
	</tr>
	<tr>
		<td colspan="3" align="center">
			<input type="submit" value="Search"/>
		</td>
	</tr>
</table>
';

eit_footer();