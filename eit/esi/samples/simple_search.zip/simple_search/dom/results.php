<?php
// This file will display the results of a search.

// The DataService interface uses cURL to connect to the EIT and request
// the XML file.  See 'service.php'.

// Error reporting to all
error_reporting( E_ALL );

require( "../profile.php" );
require( "../rest.php" );
require( "functions.php" );


// Execute search query and return results.

// Search Terms
$s1 = $_GET["s1"];
$s2 = $_GET["s2"];
$s3 = $_GET["s3"];
$s4 = $_GET["s4"]; 

// Delimiters
$d1 = $_GET["d1"];
$d2 = $_GET["d2"];
$d3 = $_GET["d3"];

// Tags
$t1 = $_GET["t1"];
$t2 = $_GET["t2"];
$t3 = $_GET["t3"];
$t4 = $_GET["t4"];

// Other
$db = $_GET["db"];
$sort = $_GET["sort"];
$start = ( isset( $_GET["start"] ) ? $_GET["start"] : 1 );
$ft = isset( $_GET["ft"] ) ? true : false;

// No search terms, go back to select DB
if( !$s1 && !$s2 && !$s3 && !$s4
	|| !$db )
	die( header( "Location: index.php") );

// The link for 'next' and 'previous' pages
$link = 'results.php?db=' . $db . '&sort=' . $sort . '&s1='
		. $s1 . '&s2' . $s2 . '&s3=' . $s3 . '&s4=' . $s4 . '&t1=' 
		. $t1 . '&t2=' . $t2 . '&t3=' . $t3 . '&t4=' . $t4 . '&d1=' 
		. $d1 . '&d2=' . $d2 . '&d3=' . $d3 . '&ft=' . $ft;
	
	
// Query Build Algorithm
$s1 = str_replace( " ", "+", $s1 );
$s1 = ( $s1 != null ) ? ( '(' . $t1 . ( $t1 != '' ? '+(' : '' ) . $s1 . ')' . ( $t1 != '' ? ')' : '') ) : null;

$s2 = str_replace( " ", "+", $s2 );
$s2 = ( $s2 != null ) ? ( '(' . $t2 . ( $t2 != '' ? '+(' : '' ) . $s2 . ')' . ( $t2 != '' ? ')' : '') ) : null;

$s3 = str_replace( " ", "+", $s3 );
$s3 = ( $s3 != null ) ? ( '(' . $t3 . ( $t3 != '' ? '+(' : '' ) . $s3 . ')' . ( $t3 != '' ? ')' : '') ) : null;

$s4 = str_replace( " ", "+", $s4 );
$s4 = ( $s4 != null ) ? ( '(' . $t4 . ( $t4 != '' ? '+(' : '' ) . $s4 . ')' . ( $t4 != '' ? ')' : '') ) : null;
		

$q = $s1 . ( ( $s2 != '' ) ? ('+' . $d1 . '+') : null ) . 
	 $s2 . ( ( $s3 != '' ) ? ('+' . $d2 . '+') : null ) .
	 $s3 . ( ( $s4 != '' ) ? ('+' . $d3 . '+') : null ) .
	 $s4;
	 
$q = str_replace( ")(", ")+AND+(", $q );
if( !preg_match( '/\+AND\+FT\+Y/', $q ) && $ft )
	$q .= '+AND+FT+Y';
// The query to be sent to the EIT is formatted in $q

// Display HTML header
eit_header();	

$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );

// Build Parameters
$params = array(
	"prof" 		=> $profile,
	"pwd"		=> $password,
	"query" 	=> $q,
	"startrec" 	=> $start,
	"db" 		=> $db,
	"sort" 		=> $sort
);

$xmlDoc->send( "Search", $params );
$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML( $xml );

// Get all of the XML elements by tag name "rec".  These are all of the
// result records.
$records = $xmlObj->getElementsByTagName( "rec" );

// Returns the number of search hits
$hits = $xmlObj->getElementsByTagName( "Statistics" )
		 	   ->item(0)->getElementsByTagName( "Hits" )
		 	   ->item(0)->nodeValue;

// Top result is the highest result on the current page.
$top_result = $start + 9;
if( $top_result > $hits )
	$top_result = $hits;		 	   
		 	   
// Building the next and previous page controls
$page_controls = '';

if( $start > 1 )
{
	$page_controls .= ' <a href="' . $link . '&start='
		. ($start - 10) . '">Prev</a> ';
} else
{
	$page_controls .= ' Prev ';
}

$page_controls .= ' | ';

if( $start < ( $hits - 9 ) )
{
	$page_controls .= ' <a href="' . $link . '&start='
		. ($start + 10) . '">Next</a> ';
} else
{
	$page_controls .= ' Next ';
}

// Output the page controls
echo '
<a href="search.php?db=' . $db . '">New Search</a>
<table border="1" width="600px">
<tr>
	<th>
		<h3>Search Results for: ' . $q . '</h3>
		Results ' . $start . ' - ' . $top_result . ' of '
		 . $hits . ' Total Results<br/>' . $page_controls . '
	</th>
</tr>

';

// Display each record
foreach( $records as $record )
{
	// info_str is the string of author/journal information.
	$info_str = '';
	
	// List each author, if there are any.
	$authors = $record->getElementsByTagName( "au" );
	if( isset( $authors->item(0)->nodeValue ) )
	{
		$info_str .= "By: ";
		foreach( $authors as $author )
		{
			$info_str .= $author->nodeValue . '; ';
		}
	}
	
	// Append Journal Title and Date
	$info_str .= $record->getElementsByTagName( "jtl" )->item(0)->nodeValue . ', ';
	$info_str .= $record->getElementsByTagName( "dt" )->item(0)->nodeValue . ', ';
	
	// Output all of this information into a row.
	echo '<tr><td><font style="font-weight: bold;"><a href="'
	  . $record->getElementsByTagName( "plink" )->item(0)->nodeValue . '">'
	  . $record->getElementsByTagName( "atl" )->item(0)->nodeValue
	  . '</a></font><br/><i>' . $info_str . '</i>';
	
	// Retrieve the subjects
	$subjects = $record->getElementsByTagName( "su" );
	
	// Only display the subjects if there are any.
	if( isset( $subjects->item(0)->nodeValue ) )
	{
		echo '<br/><br/>Subjects: <br/>';
		
		foreach( $subjects as $subject )
		{
			echo $subject->nodeValue . ', ';
		}
	}
	echo '<br /><br />';
	echo "</td></tr>\n";
}	

eit_footer();	  