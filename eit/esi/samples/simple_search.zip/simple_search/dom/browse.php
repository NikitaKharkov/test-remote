<?php

require( "../profile.php" );
require( "../rest.php" );
require( "functions.php" );

if( !isset( $_GET['db']) || !isset( $_GET['index']) || !isset( $_GET['browse']) )
	die( header( "Location: display_db.php" ) );

// Setup profile parameters
$params = array(
	"prof" => $profile,
	"pwd"  => $password,
	"index" => $_GET['index'],
	"term" => str_replace( " ", "+", $_GET['browse'] ),
	"db" => $_GET['db']
);

// Request Database Information
$xmlDoc = new DataService;
$xmlDoc->connect( "http://eit.ebscohost.com/Services/SearchService.asmx/" );
$xmlDoc->send( "Browse", $params );

$xml = $xmlDoc->recieve();

// Create a DOMDocument to parse the XML file
$xmlObj = new DOMDocument();
$xmlObj->loadXML( $xml );

// Get all 'rec' elements from the XML document.
$records = $xmlObj->getElementsByTagName( "rec" );

$table = "<table><tr><th>Name</th><th>Records Count</th></tr>\n";

foreach( $records as $record )
{
	$table .= "<tr>\n";
	
	$browseTerm = $record->getElementsByTagName( "browseTerms" )->item(0);
	
	$table .= "<td>\n<a href='browse.php?db=" . $_GET['db'] . "&index=" . $_GET['index']
		   . "&browse=" . str_replace( " ", "+", $browseTerm->getAttribute( "searchKey" ) )
		   . "'>" . $browseTerm->getAttribute( "searchKey" ) . "</a>\n</td>\n";
		   
	$table .= "<td>\n<a href='browse.php?db=" . $_GET['db'] . "&index=" . $_GET['index']
		   . "&browse=" . str_replace( " ", "+", $browseTerm->getAttribute( "searchKey" ) )
		   . "'>" . $browseTerm->getAttribute( "count" ) . "</a>\n</td>\n";
		   
	$table .= "</tr>\n";
}

$table .= "</table>";

echo "<html>\n";
echo "<head>\n";
echo "<title>Browse Indices</title>\n";
echo "</head>\n";
echo "<body>\n";
echo "<a href='search.php?db=" . $_GET['db'] . "'>New Search</a>\n";
echo $table;
echo "</body>\n";
echo "</html>\n";

?>
