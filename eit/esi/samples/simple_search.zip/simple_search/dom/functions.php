<?php 

// Output an HTML header
function eit_header()
{
	echo "<html>\n";
	echo "<head>\n";
	echo "	<title>Search EBSCOhost</title>\n";
	echo "</head>\n";
	echo "<body>\n";
}

// Output an HTML footer
function eit_footer()
{
	echo "</body>\n";
	echo "</html>\n";
}

?>