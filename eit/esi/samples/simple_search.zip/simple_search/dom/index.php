<?php

// Redirect
die( header( "Location: select_db.php") );

?>